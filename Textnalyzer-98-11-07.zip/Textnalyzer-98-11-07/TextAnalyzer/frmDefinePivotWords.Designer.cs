﻿namespace TextAnalyzer
{
    partial class frmDefinePivotWords
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDefinePivotWords));
            this.lblSelectedRelation = new System.Windows.Forms.Label();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.txtWord = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.lvPivotWords = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvPotentialSemiRegexes = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label3 = new System.Windows.Forms.Label();
            this.txtSemiRegex = new System.Windows.Forms.TextBox();
            this.btnAddSentence = new System.Windows.Forms.Button();
            this.btnRemoveSentence = new System.Windows.Forms.Button();
            this.gbPivotWords = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.chkConvertSpaceToBss = new System.Windows.Forms.CheckBox();
            this.lblRoot = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtWordToStem = new System.Windows.Forms.TextBox();
            this.btnSynonyms = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gbPivotWords.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSelectedRelation
            // 
            this.lblSelectedRelation.AutoSize = true;
            this.lblSelectedRelation.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblSelectedRelation.Location = new System.Drawing.Point(12, 9);
            this.lblSelectedRelation.Name = "lblSelectedRelation";
            this.lblSelectedRelation.Size = new System.Drawing.Size(106, 13);
            this.lblSelectedRelation.TabIndex = 0;
            this.lblSelectedRelation.Text = "Selected Relation";
            // 
            // txtWeight
            // 
            this.txtWeight.Enabled = false;
            this.txtWeight.Location = new System.Drawing.Point(55, 56);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(35, 21);
            this.txtWeight.TabIndex = 1;
            this.txtWeight.Text = "1.0";
            // 
            // txtWord
            // 
            this.txtWord.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtWord.Location = new System.Drawing.Point(7, 30);
            this.txtWord.Name = "txtWord";
            this.txtWord.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtWord.Size = new System.Drawing.Size(497, 21);
            this.txtWord.TabIndex = 1;
            this.txtWord.TextChanged += new System.EventHandler(this.txtWord_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Weight";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 15);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Word (or Regex)";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(284, 52);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(152, 30);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Add to List";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnClose.Location = new System.Drawing.Point(126, 584);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(172, 33);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Okay";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Enabled = false;
            this.btnRemove.Location = new System.Drawing.Point(442, 52);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(62, 29);
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // lvPivotWords
            // 
            this.lvPivotWords.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvPivotWords.Location = new System.Drawing.Point(6, 119);
            this.lvPivotWords.MultiSelect = false;
            this.lvPivotWords.Name = "lvPivotWords";
            this.lvPivotWords.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lvPivotWords.RightToLeftLayout = true;
            this.lvPivotWords.Size = new System.Drawing.Size(504, 107);
            this.lvPivotWords.TabIndex = 5;
            this.lvPivotWords.UseCompatibleStateImageBehavior = false;
            this.lvPivotWords.View = System.Windows.Forms.View.Details;
            this.lvPivotWords.SelectedIndexChanged += new System.EventHandler(this.lvPivotWords_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Pivot Term or Regex";
            this.columnHeader1.Width = 420;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Weight";
            this.columnHeader2.Width = 50;
            // 
            // lvPotentialSemiRegexes
            // 
            this.lvPotentialSemiRegexes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3});
            this.lvPotentialSemiRegexes.Location = new System.Drawing.Point(6, 60);
            this.lvPotentialSemiRegexes.Name = "lvPotentialSemiRegexes";
            this.lvPotentialSemiRegexes.Size = new System.Drawing.Size(504, 250);
            this.lvPotentialSemiRegexes.TabIndex = 5;
            this.lvPotentialSemiRegexes.UseCompatibleStateImageBehavior = false;
            this.lvPotentialSemiRegexes.View = System.Windows.Forms.View.Details;
            this.lvPotentialSemiRegexes.SelectedIndexChanged += new System.EventHandler(this.lvPotentialSemiRegexes_SelectedIndexChanged);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Potential Sentence Name";
            this.columnHeader3.Width = 220;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Name of Sentence for Regex Generation:";
            // 
            // txtSemiRegex
            // 
            this.txtSemiRegex.Location = new System.Drawing.Point(6, 33);
            this.txtSemiRegex.Name = "txtSemiRegex";
            this.txtSemiRegex.Size = new System.Drawing.Size(168, 21);
            this.txtSemiRegex.TabIndex = 1;
            this.txtSemiRegex.Text = "Sentence 1";
            // 
            // btnAddSentence
            // 
            this.btnAddSentence.Location = new System.Drawing.Point(180, 32);
            this.btnAddSentence.Name = "btnAddSentence";
            this.btnAddSentence.Size = new System.Drawing.Size(262, 23);
            this.btnAddSentence.TabIndex = 3;
            this.btnAddSentence.Text = "Add to List";
            this.btnAddSentence.UseVisualStyleBackColor = true;
            this.btnAddSentence.Click += new System.EventHandler(this.btnAddSentence_Click);
            // 
            // btnRemoveSentence
            // 
            this.btnRemoveSentence.Enabled = false;
            this.btnRemoveSentence.Location = new System.Drawing.Point(448, 32);
            this.btnRemoveSentence.Name = "btnRemoveSentence";
            this.btnRemoveSentence.Size = new System.Drawing.Size(62, 23);
            this.btnRemoveSentence.TabIndex = 3;
            this.btnRemoveSentence.Text = "Remove";
            this.btnRemoveSentence.UseVisualStyleBackColor = true;
            this.btnRemoveSentence.Click += new System.EventHandler(this.btnRemoveSentence_Click);
            // 
            // gbPivotWords
            // 
            this.gbPivotWords.Controls.Add(this.comboBox1);
            this.gbPivotWords.Controls.Add(this.chkConvertSpaceToBss);
            this.gbPivotWords.Controls.Add(this.lblRoot);
            this.gbPivotWords.Controls.Add(this.label4);
            this.gbPivotWords.Controls.Add(this.label2);
            this.gbPivotWords.Controls.Add(this.label1);
            this.gbPivotWords.Controls.Add(this.lvPivotWords);
            this.gbPivotWords.Controls.Add(this.txtWeight);
            this.gbPivotWords.Controls.Add(this.txtWordToStem);
            this.gbPivotWords.Controls.Add(this.txtWord);
            this.gbPivotWords.Controls.Add(this.btnSynonyms);
            this.gbPivotWords.Controls.Add(this.btnAdd);
            this.gbPivotWords.Controls.Add(this.btnRemove);
            this.gbPivotWords.Enabled = false;
            this.gbPivotWords.Location = new System.Drawing.Point(4, 347);
            this.gbPivotWords.Name = "gbPivotWords";
            this.gbPivotWords.Size = new System.Drawing.Size(516, 235);
            this.gbPivotWords.TabIndex = 6;
            this.gbPivotWords.TabStop = false;
            this.gbPivotWords.Text = "Pivot Word(s) fore Selected Potential Sentence:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Persian"});
            this.comboBox1.Location = new System.Drawing.Point(153, 91);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(93, 21);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.Text = "Persian";
            // 
            // chkConvertSpaceToBss
            // 
            this.chkConvertSpaceToBss.AutoSize = true;
            this.chkConvertSpaceToBss.Checked = true;
            this.chkConvertSpaceToBss.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkConvertSpaceToBss.Location = new System.Drawing.Point(107, 57);
            this.chkConvertSpaceToBss.Name = "chkConvertSpaceToBss";
            this.chkConvertSpaceToBss.Size = new System.Drawing.Size(160, 17);
            this.chkConvertSpaceToBss.TabIndex = 6;
            this.chkConvertSpaceToBss.Text = "Convert Empty Spaces to \\s";
            this.chkConvertSpaceToBss.UseVisualStyleBackColor = true;
            // 
            // lblRoot
            // 
            this.lblRoot.AutoSize = true;
            this.lblRoot.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblRoot.Location = new System.Drawing.Point(384, 94);
            this.lblRoot.Name = "lblRoot";
            this.lblRoot.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblRoot.Size = new System.Drawing.Size(0, 13);
            this.lblRoot.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 94);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(141, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Checkout Word Root Utility:";
            // 
            // txtWordToStem
            // 
            this.txtWordToStem.Location = new System.Drawing.Point(252, 91);
            this.txtWordToStem.Name = "txtWordToStem";
            this.txtWordToStem.Size = new System.Drawing.Size(127, 21);
            this.txtWordToStem.TabIndex = 1;
            this.txtWordToStem.TextChanged += new System.EventHandler(this.txtWordToStem_TextChanged);
            // 
            // btnSynonyms
            // 
            this.btnSynonyms.Location = new System.Drawing.Point(368, 6);
            this.btnSynonyms.Name = "btnSynonyms";
            this.btnSynonyms.Size = new System.Drawing.Size(77, 23);
            this.btnSynonyms.TabIndex = 3;
            this.btnSynonyms.Text = "Synonyms...";
            this.btnSynonyms.UseVisualStyleBackColor = true;
            this.btnSynonyms.Visible = false;
            this.btnSynonyms.Click += new System.EventHandler(this.btnSynonyms_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtSemiRegex);
            this.groupBox2.Controls.Add(this.lvPotentialSemiRegexes);
            this.groupBox2.Controls.Add(this.btnAddSentence);
            this.groupBox2.Controls.Add(this.btnRemoveSentence);
            this.groupBox2.Location = new System.Drawing.Point(4, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(516, 316);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Potential Sentences for Regex Generation";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(16, 584);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(103, 33);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmDefinePivotWords
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 622);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gbPivotWords);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblSelectedRelation);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDefinePivotWords";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowInTaskbar = false;
            this.Text = "Define Pivot Words";
            this.Load += new System.EventHandler(this.frmDefinePivotWords_Load);
            this.gbPivotWords.ResumeLayout(false);
            this.gbPivotWords.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSelectedRelation;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.TextBox txtWord;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.ListView lvPivotWords;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ListView lvPotentialSemiRegexes;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSemiRegex;
        private System.Windows.Forms.Button btnAddSentence;
        private System.Windows.Forms.Button btnRemoveSentence;
        private System.Windows.Forms.GroupBox gbPivotWords;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSynonyms;
        private System.Windows.Forms.CheckBox chkConvertSpaceToBss;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lblRoot;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtWordToStem;
    }
}