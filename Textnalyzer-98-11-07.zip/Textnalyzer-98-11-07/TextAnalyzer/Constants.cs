﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TextAnalyzer.Models; 


namespace TextAnalyzer
{
    public class Constants
    {
        public static string[] prepositions = { " و ", " یا ", "and", "or", "the", "a", "as", "an", "this", "their", "it", "on", "for" };
 
        public static string[] ponctuation = { "؛", "،",":",".",",",";" };
        public static char[] wordSeparators = { '؛', '،', ':', '.', ',','٬', ';',' ','"','\'' };
        public static string[] extraPonctuations =  { "(", ")", "[", "]", "{", "}", "\"", "'" };
        public static decimal MIN_REPEAT_TRESHOULD = 30;
        public static decimal MAX_REPEAT_TRESHOULD = 10000;
        public static List<PivotWord> pivotWords = new List<PivotWord>();
        public static int MIN_SIMILARITY_PERCENT = 75;
        public static int MAX_SENTENCE_LENGTH_DIFFRENCE_PERCENT = 20;
        public static int SENTENCE_LENGTH_QUALIFIED_SCORE = 23;
        public static int MAX_SENTENCE_WORD_COUNT_DIFFRENCE = 4;
        public static int SENTENCE_WORD_COUNT_QUALIFIED_SCORE = 25;
        public static int MIN_COMMON_WORDS_PERCENT = 65;
        public static int COMMON_WORDS_SCORE = 26;
        public static int MAX_NON_SAME_WORDS_PERCENT = 18;
        public static int NON_SAME_WORDS_QUALIFIED_SCORE = 28;
        public static string CURRENT_LANGUAGE = "fa";
        public static bool STEM_WORDS = false;
        public static bool IGNORE_PREPOSITIONS = true;
        public static int MAX_SYNONYMS_COUNT = 3;
        public static bool RIGHT_TO_LEFT_LAYOUT = false;

        public static bool USE_SYSNONYMS = true;
        public static int MIN_FREQUENCY_FOR_REGEX_APPEARE_PERCENT = 45;
        public static int MIN_FREQUENCY_FOR_APPEARE_IN_LOW_FREQ_REGEX_PERCENT = 40;
        public static bool LEARN_ENTITIES_ITSELF_AS_REGEX = true;
        public static string LOG = "";
        public static bool CONSIDER_E1_E2_AS_E2_E1 = true;
        public static bool GENERATE_LOW_FREQUENCY_REGEXES = false;
        public static bool GENERATE_REGEXES_FOR_EXACT_PIVOTS = true;
        public static bool IGNORE_NON_REACH_REGEXES = true;

    }
}
