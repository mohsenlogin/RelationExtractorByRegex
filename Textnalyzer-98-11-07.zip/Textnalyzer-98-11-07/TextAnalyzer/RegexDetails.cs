﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TextAnalyzer.Controllers;
using TextAnalyzer.Models;
using Re2.Net;

namespace TextAnalyzer
{
    public partial class frmRegexDetails : Form
    {
        private TextAnalyzer.Models.RegularExpression currentUpdatedRegex;
        private RegexContainer regex;
        public frmRegexDetails()
        {
            InitializeComponent();
            if (Constants.RIGHT_TO_LEFT_LAYOUT)
            {
                this.RightToLeftLayout = true;       
                this.RightToLeft = RightToLeft.Yes;
                lbCoveringSentences.RightToLeft = RightToLeft.Yes;
                txtRegex.RightToLeft = RightToLeft.Yes;
                txtTestRegex.RightToLeft = RightToLeft.Yes;
            }
            else
            {
                this.RightToLeftLayout = false;
                this.RightToLeft = RightToLeft.No;
                lbCoveringSentences.RightToLeft = RightToLeft.No;
                txtRegex.RightToLeft = RightToLeft.No;
                txtTestRegex.RightToLeft = RightToLeft.No;
            }
        }
        public void showDialog(RegexContainer regex)
        {
            if (regex != null)
            {
                this.regex = regex;
                this.currentUpdatedRegex = regex.regex;
                txtRegex.Text = regex.regex.ToString();
                if (regex.regex.coveringSentences != null)
                {
                    lbCoveringSentences.Items.AddRange(regex.regex.coveringSentences.ToArray());
                }
            }
            this.ShowDialog();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTestRegex.Text) && !string.IsNullOrEmpty(txtRegex.Text))
            {
                Parser parser = new Parser();
                string[] words = parser.tokenizeSentence(sentence: txtTestRegex.Text, ignorePrepositions: true);
                string simplifiedSentence = string.Empty;
                foreach(string w in words)
                {
                    simplifiedSentence += w + " ";
                }
                try
                {
                    if (Regex.IsMatch(simplifiedSentence.Trim(), currentUpdatedRegex.ToString(simplifiedVersion: false)))
                    {
                        txtTestRegex.BackColor = Color.Green;
                    }                
                    else
                    {
                        txtTestRegex.BackColor = Color.Red;
                        //lblMessage.Text = "";
                        //lblMessage.BackColor = Color.Red;
                        //Dictionary<int,string> errorLocations = Models.Regex.findRegexErrorInfo(simplifiedSentence.Trim(), currentUpdatedRegex.ToString());
                        //foreach(var errorLoc in errorLocations)
                        //{
                        //    lblMessage.Text += errorLoc.Key + ":" + errorLoc.Value + "-";
                        //}
                    }
                }
                catch(ArgumentException ae)
                {
                    txtRegex.BackColor = Color.Red;
                    lblMessage.Text = ae.Message;
                }
            }
        }

        private void chkSimpleRegexView_CheckedChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtRegex.Text))
            {
                if (chkSimpleRegexView.Checked)
                {
                    txtRegex.Text = txtRegex.Text.Replace(RegularExpression.WORD_REGEX, "w");
                }
                else
                {
                    txtRegex.Text = regex.regex.ToString();
                }
            }
        }

        private void txtTestRegex_TextChanged(object sender, EventArgs e)
        {
            btnTest_Click(sender, e);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblClearTestSentence_Click(object sender, EventArgs e)
        {
            txtTestRegex.Text = "";
        }

        private void txtRegex_TextChanged(object sender, EventArgs e)
        {
            if (chkSimpleRegexView.Checked)
            {
                currentUpdatedRegex = new Models.RegularExpression( txtRegex.Text.Replace("w", Models.RegularExpression.WORD_REGEX));                
            }
            else
            {
                currentUpdatedRegex = new Models.RegularExpression(txtRegex.Text);
            }
            if (Models.RegularExpression.IsValidRegex(currentUpdatedRegex.ToString()))
            {
                txtRegex.BackColor = Color.Red;                
            }
            else
            {
                txtRegex.BackColor = Color.Green;
            }
        }
        
    }
}
