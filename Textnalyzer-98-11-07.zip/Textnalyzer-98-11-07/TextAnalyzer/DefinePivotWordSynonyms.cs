﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TextAnalyzer.Models;

namespace TextAnalyzer
{
    public partial class DefinePivotWordSynonyms : Form
    {
        private PivotWordItem selectedPivotWordItem;
        public DefinePivotWordSynonyms()
        {
            InitializeComponent();
        }
        public void showDialog(ref PivotWordItem pivotWordItem)
        {
            this.selectedPivotWordItem = pivotWordItem;
            lblSelectedPivotWord.Text += pivotWordItem.word;
            this.Text += pivotWordItem.word;
            ShowDialog();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (selectedPivotWordItem != null && !string.IsNullOrEmpty(txtSynonyms.Text))
            {
                if(selectedPivotWordItem.synonyms != null)
                {
                    selectedPivotWordItem.synonyms = txtSynonyms.Text.Split('\n', '\r').Except(selectedPivotWordItem.synonyms).ToList();
                }
                else
                {
                    selectedPivotWordItem.synonyms = txtSynonyms.Text.Split('\n', '\r').ToList();
                }
                
            }
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
