﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TextAnalyzer.Models;
using Stemming.Persian;
using Iveonik.Stemmers;
using Lemmatizer;
using System.IO;

namespace TextAnalyzer.Controllers
{
    public class Parser
    {
        private static EnglishStemmer stemmer = new EnglishStemmer();
        private static StemmingTools persianStemmer = new StemmingTools();
        public List<TripleEntry> parse(string filePath, bool isKnowledgeGraphFormat, out List<TripleEntry> testEntries, long cuttoff = -1)
        {
            List<TripleEntry> trainEntries = new List<TripleEntry>();
            testEntries = new List<TripleEntry>();
            TripleEntry entry;
            string currentLine = string.Empty;    
            char[] separators = new char[] {' ',',','"','[',']' };
            using (FileStream fileStream = new FileStream(filePath,FileMode.Open,FileAccess.Read))
            using (StreamReader streamReader = new StreamReader(fileStream))            
            {                            
                for (long i = 0;(currentLine = streamReader.ReadLine()) != null && (i != -1 || i < cuttoff) ; i++ )
                {                    
                    entry = new TripleEntry();
                    if(i % 4 != 0)
                    {
                        // store as train entry
                        
                        if(currentLine.Contains("\"predicate\" : "))
                        {                            
                            entry.relationType = currentLine.Replace("\"predicate\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];

                            while (!(currentLine = streamReader.ReadLine()).Contains("\"subject\" : ") || currentLine == null)
                                ;

                            if (currentLine != null )
                            {
                                entry.entity1 = currentLine.Replace("\"subject\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];
                                entry.entity1 = entry.entity1.Replace("_", " ").Replace("-", " ").Substring(entry.entity1.LastIndexOf('/') + 1);
                                while (!(currentLine = streamReader.ReadLine()).Contains("\"object\" : ")  || currentLine == null)
                                    ;
                                if (currentLine  != null )
                                {
                                    entry.entity2 = currentLine.Replace("\"object\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];
                                    entry.entity2 = entry.entity2.Replace("_", " ").Replace("-", " ").Substring(entry.entity2.LastIndexOf('/') + 1);

                                    while (!(currentLine = streamReader.ReadLine()).Contains("\"subjectClasses\" : ") || currentLine == null)
                                        ;
                                    if (currentLine != null)
                                    {
                                        entry.entity1Types = currentLine.Replace("\"subjectClasses\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                        while (!(currentLine = streamReader.ReadLine()).Contains("\"objectClasses\" : ")  || currentLine == null)
                                            ;
                                        if (currentLine != null)
                                        {
                                            entry.entity2Types = currentLine.Replace("\"objectClasses\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                            while (!(currentLine = streamReader.ReadLine()).Contains("\"semEvalFormat\" : ")  || currentLine == null)
                                                ;
                                            if (currentLine != null)
                                            {
                                                entry.sentence = currentLine.Trim().Replace("\"semEvalFormat\" : ", "").Replace("\"", "");                                                trainEntries.Add(entry);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        // store as Test enty
                        if (currentLine.Contains("\"predicate\" : "))
                        {
                            entry.relationType = currentLine.Replace("\"predicate\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];

                            while (!(currentLine = streamReader.ReadLine()).Contains("\"subject\" : ") || currentLine == null)
                                ;

                            if (currentLine != null)
                            {
                                entry.entity1 = currentLine.Replace("\"subject\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];
                                entry.entity1 = entry.entity1.Replace("_"," ").Replace("-"," ").Substring(entry.entity1.LastIndexOf('/') + 1);
                                while (!(currentLine = streamReader.ReadLine()).Contains("\"object\" : ") || currentLine == null)
                                    ;
                                if (currentLine != null)
                                {
                                    entry.entity2 = currentLine.Replace("\"object\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];
                                    entry.entity2 = entry.entity2.Replace("_", " ").Replace("-", " ").Substring(entry.entity2.LastIndexOf('/') + 1);
                                    while (!(currentLine = streamReader.ReadLine()).Contains("\"subjectClasses\" : ") || currentLine == null)
                                        ;
                                    if (currentLine != null)
                                    {
                                        entry.entity1Types = currentLine.Replace("\"subjectClasses\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                        while (!(currentLine = streamReader.ReadLine()).Contains("\"objectClasses\" : ") || currentLine == null)
                                            ;
                                        if (currentLine != null)
                                        {
                                            entry.entity2Types = currentLine.Replace("\"objectClasses\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                            while (!(currentLine = streamReader.ReadLine()).Contains("\"semEvalFormat\" : ") || currentLine == null)
                                                ;
                                            if (currentLine != null)
                                            {
                                                entry.sentence = currentLine.Trim().Replace("\"semEvalFormat\" : ", "").Replace("\"", "");
                                                testEntries.Add(entry);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }              
                }
            }
            return trainEntries;
        }
        public List<TripleEntry> parse(string filePath, bool isKnowledgeGraphFormat, long cuttoff = -1)
        {
            List<TripleEntry> trainEntries = new List<TripleEntry>();
            
            TripleEntry entry;
            string currentLine = string.Empty;
            char[] separators = new char[] { ' ', ',', '"', '[', ']' };
            using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            using (StreamReader streamReader = new StreamReader(fileStream))
            {
                for (long i = 0; (currentLine = streamReader.ReadLine()) != null && (i != -1 || i < cuttoff); i++)
                {
                    entry = new TripleEntry();
                    
                    // store as train entry

                    if (currentLine.Contains("\"predicate\" : "))
                    {
                        entry.relationType = currentLine.Replace("\"predicate\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];

                        while (!(currentLine = streamReader.ReadLine()).Contains("\"subject\" : ") || currentLine == null)
                            ;

                        if (currentLine != null)
                        {
                            entry.entity1 = currentLine.Replace("\"subject\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];
                            entry.entity1 = entry.entity1.Replace("_", " ").Replace("-", " ").Substring(entry.entity1.LastIndexOf('/') + 1);
                            while (!(currentLine = streamReader.ReadLine()).Contains("\"object\" : ") || currentLine == null)
                                ;
                            if (currentLine != null)
                            {
                                entry.entity2 = currentLine.Replace("\"object\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries)[0];
                                entry.entity2 = entry.entity2.Replace("_", " ").Replace("-", " ").Substring(entry.entity2.LastIndexOf('/') + 1);

                                while (!(currentLine = streamReader.ReadLine()).Contains("\"subjectClasses\" : ") || currentLine == null)
                                    ;
                                if (currentLine != null)
                                {
                                    entry.entity1Types = currentLine.Replace("\"subjectClasses\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                    while (!(currentLine = streamReader.ReadLine()).Contains("\"objectClasses\" : ") || currentLine == null)
                                        ;
                                    if (currentLine != null)
                                    {
                                        entry.entity2Types = currentLine.Replace("\"objectClasses\" : ", "").Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                        while (!(currentLine = streamReader.ReadLine()).Contains("\"semEvalFormat\" : ") || currentLine == null)
                                            ;
                                        if (currentLine != null)
                                        {
                                            entry.sentence = currentLine.Trim().Replace("\"semEvalFormat\" : ", "").Replace("\"", ""); trainEntries.Add(entry);
                                        }
                                    }
                                }
                            }
                        }
                    }                    
                }
            }
            return trainEntries;
        }
        public List<TripleEntry> parse(string trainContent, string sep =   "\r\n\r\n")
        {
            List<TripleEntry> trainEntries = null;
            if (!string.IsNullOrEmpty(trainContent))
            {
                trainEntries = new List<TripleEntry>();
                //try
                {
                    string[] separator = new string[] { sep };
                    string[] trainEntriesText = trainContent.Split(separator, StringSplitOptions.None);
                    foreach (string entry in trainEntriesText)
                    {
                        try
                        {
                            string[] entryContents = entry.Split('\n');
                            if (string.IsNullOrEmpty(entry))
                                continue;
                            int firstQutaionIndex = entryContents[0].IndexOf('"');
                            int lastQoutationIndex = entryContents[0].LastIndexOf('"');
                            string sentence = entryContents[0].Substring(firstQutaionIndex + 1, lastQoutationIndex - 2 - firstQutaionIndex).Trim();
                            TripleEntry trainEntry = new TripleEntry();
                            trainEntry.entity1 = sentence.Substring(sentence.IndexOf("<e1>") + 4, sentence.IndexOf("</e1>") - sentence.IndexOf("<e1>") - 4);
                            trainEntry.entity2 = sentence.Substring(sentence.IndexOf("<e2>") + 4, sentence.IndexOf("</e2>") - sentence.IndexOf("<e2>") - 4);
                            trainEntry.sentence = sentence.Trim().Replace(sentence.Substring(sentence.IndexOf("<e1>"), sentence.IndexOf("</e1>") + 5 - sentence.IndexOf("<e1>")), " <e1> ");
                            trainEntry.sentence = trainEntry.sentence.Trim().Replace(sentence.Substring(sentence.IndexOf("<e2>"), sentence.IndexOf("</e2>") + 5 - sentence.IndexOf("<e2>")), " <e2> ");
                            // entity tags may be mis-placed in input train text, so remove misplace <e> tags
                            trainEntry.entity1 = removePonctuation( trainEntry.entity1.Replace("<e1>", "").Replace("<e2>", "").Replace("</e1>", "").Replace("</e2>", "")).Trim();
                            trainEntry.entity2 = removePonctuation( trainEntry.entity2.Replace("<e1>", "").Replace("<e2>", "").Replace("</e1>", "").Replace("</e2>", "")).Trim();
                            trainEntry.relationType = entryContents[1].Trim().ToLower();
                            if (Constants.STEM_WORDS)
                            {
                                trainEntry.stemmedWords = stemWords(sentence, Constants.CURRENT_LANGUAGE);
                            }
                            trainEntry.comment = entryContents[2].Substring(entryContents[2].IndexOf("comment:") + 9).Trim();
                            trainEntries.Add(trainEntry);
                        }
                        catch(ArgumentOutOfRangeException aoore)
                        {
                            // log input error, ignore this entry simply
                        }
                    }                    
                }
                //catch(Exception ex)
                {
                   // throw;
                }
            }
            return trainEntries;
        }
        public List<string> stemWords(string sentence, string language)
        {
            string[] stemmedWordsArray = sentence.Split(' ', ',', ';', '،', '؛');
            List<string> stemmedWords = new List<string>();
            string stemmedWord;
            EnglishStemmer stemmer = new EnglishStemmer();
            for(int currentWord = 0; currentWord < stemmedWordsArray.Length; currentWord++)
            {
                
                    if (language.Equals("fa"))
                {
                    
                    try
                    {
                        //stemmedWord = persianStemmer.run(stemmedWordsArray[currentWord]);
                        stemmedWord = persianStemmer.LemmatizeText(stemmedWordsArray[currentWord], LevelOfLemmatizer.First, false);
                    }
                    catch (NullReferenceException nre)
                    {
                        stemmedWord = stemmedWordsArray[currentWord]; // ignore exception and don not stem
                    }
                    catch(Exception e)
                    {
                        stemmedWord = stemmedWordsArray[currentWord];
                    }
                }
                else if (Constants.CURRENT_LANGUAGE.ToLower().Equals("en"))
                {
                    stemmedWord = stemmer.Stem(stemmedWordsArray[currentWord]).ToLower() ;
                }
                else
                {
                    stemmedWord = stemmedWordsArray[currentWord].ToLower();
                }
                stemmedWords.Add(stemmedWord);
            }
            return stemmedWords;
        }
        public string[] tokenizeSentence(string sentence, bool ignorePrepositions)
        {
            List<string> tokens = removeEntityTag(removePonctuation((ignorePrepositions ? removePrepositions(sentence) : sentence))).Split(new string[]{ " "},StringSplitOptions.RemoveEmptyEntries).ToList();
            tokens.RemoveAll(t => string.IsNullOrEmpty(t));
            return tokens.ToArray();
        }
        public string untokenizeSentence(List<string> words)
        {
            StringBuilder sentence = new StringBuilder( string.Empty);

            foreach (string word in words)
            {
                sentence .Append(word).Append(" ");
            }
            return sentence.ToString().Trim();
        }
        public string removePrepositions(string text)
        {
            string cleanedText = "";
            text = text.ToLower();
            string[] words = text.Split(Constants.wordSeparators);
            //foreach (string preposition in Constants.prepositions)
            //{
                
                foreach(string word in words)
                {
                    if (!Constants.prepositions.Contains(word.Trim()))
                    {
                        cleanedText = String.Join(" ", new string[] { cleanedText, word /*word.Replace(preposition, "")*/ });// cleanedText += word.Replace(preposition, "")+" ";
                    }
                }
            //}
            return cleanedText.Trim();
        }
        public string removePonctuation(string text)
        {
            //string cleanedText = "";
            foreach (string ponctuation in Constants.ponctuation)
            {
                text = text.Replace(ponctuation, " ");
            }
            return text.Trim();
        }
        public string removeEntityTag(string text)
        {
            string cleanedText = "";

            cleanedText = text.Replace("<e1>", "");
            cleanedText = text.Replace("</e1>", "");
            cleanedText = text.Replace("<e2>", "");
            cleanedText = text.Replace("</e2>", "");

            return cleanedText.Trim();
        }
        public bool isLetter(string token)
        {
            if (!string.IsNullOrEmpty(token))
            {
                foreach(char letter in token)
                {
                    if (!char.IsLetter(letter))
                    {
                        return false;
                    }
                }
                return true;
            }
            else return false;
        }
        public string XXdoStemming(string word, string language)
        {
            string stemmedWord = word;
            EnglishStemmer stemmer = new EnglishStemmer();
            if (Constants.CURRENT_LANGUAGE.ToLower().Equals("fa"))
            {
                try
                {
                    stemmedWord = new Stemmer().run(word) ;
                }
                catch (NullReferenceException nre)
                {
                    stemmedWord = word;
                }
                catch (Exception e)
                {
                    stemmedWord = word;
                }
            }
            else if (Constants.CURRENT_LANGUAGE.ToLower().Equals("en"))
            {
                try
                {
                    stemmedWord = (Constants.STEM_WORDS ? stemmer.Stem(word).ToLower() : word.ToLower());
                }
                catch (NullReferenceException nre)
                {
                    stemmedWord = word;
                }
                catch (Exception e)
                {
                    stemmedWord = word;
                }
            }
            else
            {
                stemmedWord = word.ToLower();
            }
            return stemmedWord;
        }
        public string doStemming(string word, string language)
        {
            string stemmedWord = word;
           
            if (Constants.CURRENT_LANGUAGE.ToLower().Equals("fa"))
            {
                try
                {
                    stemmedWord = persianStemmer.LemmatizeText(word, LevelOfLemmatizer.First, false);
                }
                catch (NullReferenceException nre)
                {
                    stemmedWord = word;
                }
                catch (Exception e)
                {
                    stemmedWord = word;
                }
            }
            else if (Constants.CURRENT_LANGUAGE.ToLower().Equals("en"))
            {
                try
                {
                    stemmedWord = (Constants.STEM_WORDS ? stemmer.Stem(word).ToLower() : word.ToLower());
                }
                catch (NullReferenceException nre)
                {
                    stemmedWord = word;
                }
                catch (Exception e)
                {
                    stemmedWord = word;
                }
            }
            else
            {
                stemmedWord = word.ToLower();
            }
            return stemmedWord;
        }
        public string simplifyText(string text)
        {
            if (text.Contains("/"))
            {
                text = text.Substring(text.LastIndexOf("/") + 1);
            }
            else if (text.Contains(":"))
            {
                text = text.Substring(text.LastIndexOf(":") + 1);
            }
            return text.Trim().Replace("_", " ").ToLower();
        }
    }
}
