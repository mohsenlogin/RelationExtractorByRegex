﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TextAnalyzer.Models;
using Iveonik.Stemmers;
using Stemming.Persian;
using Re2.Net;

namespace TextAnalyzer.Controllers
{
    public class Analyzer
    {
        Parser parser = new Parser();
        private int minOccouranceThreshold = 10;
        private List<TripleEntry> similarSentences = null, unsimilarSentences = new List<TripleEntry>();
        private List<List<RelationStatistics>> relationStatList = null;
        private static Database synonymsDb;
        public List<List<RelationStatistics>> analyze(List<TripleEntry> trainEntries, bool stemWords, bool ignorePrepositions, ref List<RegexContainer> regexes)
        {
            RelationStatistics relationStatistics;            
            List<List<RelationStatistics>> relationStatisticsList = new List<List<RelationStatistics>>();

            List<List<TripleEntry>> entriesGroupByRelation = trainEntries.GroupBy(te => te.relationType).Select(x => x.ToList()).ToList();
            int currentRelationIndex = 0;
            foreach (List<TripleEntry> group in entriesGroupByRelation)
            {
                if (group[0].relationType.ToLower().Equals("other"))
                    continue;
                PivotWord pivotWordsList = null;
                for (int i = 0; i < group.Count; i++)
                {
                    PivotWord pw = Constants.pivotWords.Where(p => p.relation == group[i].relationType).SingleOrDefault();
                    if (pw != null && pw.relation == group[i].relationType)
                    {
                        pivotWordsList = pw;
                        break;
                    }
                }
                //if (pivotWordsList != null)
                {
                    List<TripleEntry> pivotlessSentences;
                    List<SentencesWithCommonPivotWords> similarSeparatedGroups = groupSentencesByCommonPivot(group, pivotWordsList, out pivotlessSentences);
                    relationStatisticsList.Add(new List<RelationStatistics>());
                    foreach (SentencesWithCommonPivotWords similarGroup in similarSeparatedGroups)
                    {
                        relationStatistics = analyzeSentence(similarGroup, stemWords, ignorePrepositions, ref regexes);
                        relationStatisticsList[currentRelationIndex].Add(relationStatistics);
                    }
                    relationStatistics = analyzeSentence(new SentencesWithCommonPivotWords(pivotlessSentences,pivotWordItems:null), stemWords, ignorePrepositions,
                        ref regexes,relationStatisticsList[currentRelationIndex], true);
                    relationStatisticsList[currentRelationIndex].Add(relationStatistics);                    
                    ++currentRelationIndex;
                }
            }
            if (Constants.USE_SYSNONYMS)
            {
                synonymsDb = Database.Instance();
            }
            /*
            List<RegexContainer> distinctRegexes = new List<RegexContainer>();
            foreach(RegexContainer r in regexes)
            {
                if (distinctRegexes.Where(dr=>dr.regex.ToString().Equals(r.regex.ToString())).Count() == 0)
                {
                    distinctRegexes.Add(r);
                }
            }
            regexes = distinctRegexes;
              */
                    
            return relationStatList = relationStatisticsList;
        }
        public RelationStatistics analyzeSentence(SentencesWithCommonPivotWords interrelatedTrainSets, bool stemWords, bool ignorePrepositions, ref List<RegexContainer> regexes,List<RelationStatistics> allWithPivotTrainSetStats = null, bool isPivotlessTrainsets = false)
        {
            RelationStatistics relationStatistics = new RelationStatistics();
            relationStatistics.wordFrequencies = new List<List<WordFrequencyStatistics>>();
            relationStatistics.relation = interrelatedTrainSets.trainEntries.Select(t => t.relationType).First();
            List<WordFrequencyStatistics> similarSentencesWordStats = null;
            if (!isPivotlessTrainsets)
            {
                // separate similar and unsimilar sentences and calculate word frequencies of each distinct group separatly
                // check similarity of sentences with same pivot words, NOTE that they may not be similar                
                similarSentences = separateSimilarUnsimilarSentences(interrelatedTrainSets, ref unsimilarSentences);
                relationStatistics.similarTrainEntries = similarSentences;
                similarSentencesWordStats = calculateStatistics(similarSentences, stemWords, ignorePrepositions);
                relationStatistics.wordFrequencies.Add(similarSentencesWordStats);

            }
            else
            {
                similarSentences = null;
                unsimilarSentences = interrelatedTrainSets.trainEntries;
            }
            relationStatistics.unsimilarTrainEntries = unsimilarSentences;
            
            List<WordFrequencyStatistics> unSimilarSentencesWordStats = calculateStatistics(unsimilarSentences, stemWords, ignorePrepositions);
            
            relationStatistics.wordFrequencies.Add(unSimilarSentencesWordStats);
            List<RegexContainer> sentenceRegexes = reduceSimilarSentences(new SentencesWithCommonPivotWords(similarSentences,interrelatedTrainSets.pivotWords), similarSentencesWordStats, unsimilarSentences, unSimilarSentencesWordStats,allWithPivotTrainSetStats);
            if (sentenceRegexes != null)
            {
                regexes.AddRange(sentenceRegexes);
            }
            
            return relationStatistics;
        }
        public List<WordFrequencyStatistics> calculateStatistics(List<TripleEntry> sentences, bool stemWords, bool ignorePrepositions)
        {
            List<WordFrequencyStatistics> wordFrequencyStats = new List<WordFrequencyStatistics>();
            EnglishStemmer stemmer = new EnglishStemmer();
            foreach (TripleEntry trainCase in sentences)
            {
                // compare sentences of each group of a relation for finding most frequent word (or substring)
                string[] words = parser.tokenizeSentence(trainCase.sentence, ignorePrepositions);
                foreach (string word in words)
                {
                    if (word == " " || string.IsNullOrEmpty(word))
                    {
                        break;
                    }
                    string stemmedWord;
                    if (stemWords)
                    {
                        stemmedWord = parser.doStemming(word, Constants.CURRENT_LANGUAGE);
                    }
                    else
                    {
                        stemmedWord = word;
                    }
                //    if (Constants.CURRENT_LANGUAGE.ToLower().Equals("fa"))
                //    {
                        
                //        try
                //        {
                //            stemmedWord = (stemWords ? new Stemmer().run(word) : word);
                //        }
                //        catch(NullReferenceException nre)
                //        {
                //            stemmedWord = word;
                //        }
                //        catch(Exception e)
                //        {
                //            stemmedWord = word;
                //        }
                //    }
                //    else if (Constants.CURRENT_LANGUAGE.ToLower().Equals("en"))
                //    {
                //        try
                //        {
                //            stemmedWord = (stemWords ? stemmer.Stem(word).ToLower() : word.ToLower());
                //        }                        
                //        catch (NullReferenceException nre)
                //        {
                //            stemmedWord = word;
                //        }
                //        catch (Exception e)
                //        {
                //            stemmedWord = word;
                //        }
                //}
                //    else
                //    {
                //        stemmedWord = word.ToLower();
                //    }
                    // if word statistics not already exist in the wordFrequency list
                    if (wordFrequencyStats.Where(w => w.word == stemmedWord).Count() == 0 && stemmedWord.Length > 1)
                    {
                        WordFrequencyStatistics wordStatistics = new WordFrequencyStatistics();
                        wordStatistics.word = stemmedWord;
                        wordStatistics.frequency = sentences.Where(t => t.sentence.Contains(stemmedWord) /*parser.tokenizeSentence(t.sentence).Contains(word)*/).Count(); //

                        wordFrequencyStats.Add(wordStatistics);
                    }
                }
            }
            return wordFrequencyStats;
        }
        public List<SentencesWithCommonPivotWords> groupSentencesByCommonPivot(List<TripleEntry> trainSentences, PivotWord pivotWords,out List<TripleEntry> pivotlessSentences,
            float minSimilarityThreshould = 1)
        {
            List<SentencesWithCommonPivotWords> sentencesGroupBySimilarity = new List<SentencesWithCommonPivotWords>();
            if (pivotWords != null)
            {
                for (int currentSet = 0; currentSet < pivotWords.pivotWordItems.Count; currentSet++)
                {
                    List<TripleEntry> similarSentences = trainSentences;
                    int commonPivotWordCount = 0;
                    foreach (PivotWordItem pivotWord in pivotWords.pivotWordItems[currentSet])
                    {
                        try
                        {
                            similarSentences = similarSentences.Where(s => Regex.IsMatch(
                                parser.untokenizeSentence(parser.tokenizeSentence(s.sentence, ignorePrepositions: false).ToList()),
                                pivotWord.word.Replace("w", RegularExpression.WORD_REGEX)) && !s.isAlreadyGrouped).ToList();
                            //similarSentences = similarSentences.Where(t => (t.sentence.Contains(" " + pivotWord.word.Trim() + " ") ||
                            //t.sentence.Contains(" " + pivotWord.word.Trim() + ".") || t.sentence.Contains(" " + pivotWord.word.Trim() + ",") ||
                            //t.sentence.Contains("," + pivotWord.word.Trim() + " ") || t.sentence.Contains(" " + pivotWord.word.Trim() + ";") ||
                            //t.sentence.Contains(";" + pivotWord.word.Trim() + " ") || t.sentence.Contains("." + pivotWord.word.Trim() + " ")) &&
                            //!t.isAlreadyGrouped).ToList();
                            foreach (TripleEntry t in similarSentences)
                            {
                                // prevent grouping sentences having more than one group of pivot words in common to be grouped more than once
                                t.isAlreadyGrouped = true;
                            }
                            if (similarSentences.Count > 1)
                            {
                                ++commonPivotWordCount;
                            }
                        }
                        catch(ArgumentException ae)
                        {
                            // ignore current erroor in regex syntax and ignore current pivot word, just log and inform user to edit this regex
                            Constants.LOG += "\nError in regex (ignored):\n" + pivotWord.word + "\nConsider Editing it\nDetailed Error:\n"+ae.Message;
                            continue;
                        }
                    }
                    // if all pivot words match in some sentences       
                    if (commonPivotWordCount > 0 && commonPivotWordCount == pivotWords.pivotWordItems[currentSet].Count)
                    {
                        sentencesGroupBySimilarity.Add(new SentencesWithCommonPivotWords(similarSentences, pivotWords.pivotWordItems[currentSet]));
                    }
                }
            }
            //TODO: check bellow may cause a regex misgrouping problem
            // if there is train entries that does not fall in a group ('cause havent any pivot word), group them in misclaneus group
            
            List<TripleEntry> ungroupedSentences = trainSentences.Where(t => !t.isAlreadyGrouped).ToList();
            if (ungroupedSentences != null && ungroupedSentences.Count > 0)
            {
                pivotlessSentences = ungroupedSentences;
            }
            else
            {
                pivotlessSentences = null;
            }
            
            return sentencesGroupBySimilarity;
        }
        public List<SentencesWithCommonPivotWords> groupSentencesBySimilarity(List<TripleEntry> trainSentences, PivotWord pivotWords,
            float minSimilarityThreshould = 1, bool groupMisclaneusSentences = true)
        {
            List<SentencesWithCommonPivotWords> sentencesGroupBySimilarity = new List<SentencesWithCommonPivotWords>();
            if (pivotWords != null)
            {
                for (int currentSet = 0; currentSet < pivotWords.pivotWordItems.Count; currentSet++)
                {
                    List<TripleEntry> similarSentences  = trainSentences;
                    int commonPivotWordCount = 0;
                    foreach (PivotWordItem pivotWord in pivotWords.pivotWordItems[currentSet])
                    {
                        similarSentences = similarSentences.Where(t => (t.sentence.Contains(" " + pivotWord.word.Trim() + " ") ||
                        t.sentence.Contains(" " + pivotWord.word.Trim() + ".") || t.sentence.Contains(" " + pivotWord.word.Trim() + ",") ||
                        t.sentence.Contains("," + pivotWord.word.Trim() + " ") || t.sentence.Contains(" " + pivotWord.word.Trim() + ";") ||
                        t.sentence.Contains(";" + pivotWord.word.Trim() + " ") || t.sentence.Contains("." + pivotWord.word.Trim() + " ")) &&
                        !t.isAlreadyGrouped).ToList();
                        foreach (TripleEntry t in similarSentences)
                        {
                            // prevent grouping sentences having more than one group of pivot words in common to be grouped more than once
                            t.isAlreadyGrouped = true;
                        }
                        if (similarSentences.Count > 1)
                        {
                            ++commonPivotWordCount;
                        }
                    }
                    // if all pivot words match in some sentences       
                    if (commonPivotWordCount == pivotWords.pivotWordItems[currentSet].Count)
                    {
                        sentencesGroupBySimilarity.Add(new SentencesWithCommonPivotWords(similarSentences,pivotWords.pivotWordItems[currentSet]));
                    }
                }
            }
            //TODO: check bellow may cause a regex misgrouping problem
            // if there is train entries that does not fall in a group ('cause havent any pivot word), group them in misclaneus group
            if (groupMisclaneusSentences)
            {
                List<TripleEntry> ungroupedSentences = trainSentences.Where(t => !t.isAlreadyGrouped).ToList();
                if (ungroupedSentences != null && ungroupedSentences.Count > 0)
                {
                    sentencesGroupBySimilarity.Add(new SentencesWithCommonPivotWords(ungroupedSentences,null));
                }
            }
            return sentencesGroupBySimilarity;
        }
        public List<RegexContainer> reduceSimilarSentences(SentencesWithCommonPivotWords similarSentences, List<WordFrequencyStatistics> similarSentencesStats,
            List<TripleEntry> unsimilarSentences, List<WordFrequencyStatistics> unsimilarSentenceStats, List<RelationStatistics> allWithPivotRelationStats = null)
        {

            List<RegexContainer> regularExpressions = new List<RegexContainer>();
            //foreach (List<TrainEntry> samePivotWordSentence in sentencesGroupedByPivotWord)
            //{
            // similar sentences whould collapse and reduce to one regex, each but unsimilar ones whould produce a separate regex
            if (similarSentences != null && similarSentences.trainEntries != null && similarSentences.trainEntries.Count > 0)
            {
                List<RegexContainer> similarSentencesRegex = regularExpressionGeneratorX(similarSentences, similarSentencesStats);

                if (similarSentencesRegex != null && similarSentencesRegex.Count > 0 && !string.IsNullOrEmpty(similarSentencesRegex[0].regex.ToString()))
                {
                    foreach(RegexContainer r in similarSentencesRegex)
                    {
                        r.relation += "#";
                    }                    
                    
                    regularExpressions.AddRange(similarSentencesRegex);
                }
            }
            if (Constants.GENERATE_LOW_FREQUENCY_REGEXES && unsimilarSentences != null && unsimilarSentences.Count > 0)
            {
                foreach (TripleEntry unsimilarSentence in unsimilarSentences)
                {
                    List<RegexContainer> unsimilarSentenceRegex = regularExpressionGenerator(unsimilarSentence, unsimilarSentenceStats,regularExpressions, allWithPivotRelationStats);
                    
                    if (unsimilarSentenceRegex != null && unsimilarSentenceRegex.Count > 0 && !string.IsNullOrEmpty(unsimilarSentenceRegex[0].regex.ToString()))
                    {
                        int duplicateCount = regularExpressions.Where(r => r.regex.ToString().Equals(unsimilarSentenceRegex[0].regex.ToString())).Count();
                        if (duplicateCount == 0)
                        {
                            regularExpressions.AddRange(unsimilarSentenceRegex);
                        }
                    }
                }
            }
            if (Constants.GENERATE_REGEXES_FOR_EXACT_PIVOTS)
            {                
                foreach(PivotWord p in Constants.pivotWords)
                {
                    RegexContainer pivotwordRegex = new RegexContainer();
                    pivotwordRegex.relation = p.relation;
                    foreach (List<PivotWordItem> item in p.pivotWordItems)
                    {
                        if (item.Count > 0)
                        {
                            pivotwordRegex.regex = new RegularExpression(item[0].word);
                        }
                    }
                    if ( pivotwordRegex.regex != null && regularExpressions.Where(r => r.regex.ToString().Equals(pivotwordRegex.regex.ToString())).Count() == 0)
                    {
                        regularExpressions.Add(pivotwordRegex);
                    }
                }
            }
            //}
            return regularExpressions;
        }
        
        public List<TripleEntry> separateSimilarUnsimilarSentences(SentencesWithCommonPivotWords sentences, ref List<TripleEntry> unsimilarSentences)
        {
            List<TripleEntry> similarSentences = new List<TripleEntry>();
            unsimilarSentences.Clear();
            // calculate statistics of words of current relation to be used by getSimilarityPercent method
            List<WordFrequencyStatistics> relationWordStats = calculateStatistics(sentences.trainEntries, Constants.STEM_WORDS, Constants.IGNORE_PREPOSITIONS);
            for (int currentSentence = 0; currentSentence < sentences.trainEntries.Count - 1; currentSentence++)
            {
                for (int j = currentSentence + 1; j < sentences.trainEntries.Count; j++)
                {
                    if (getSimilarityPercent(sentences.trainEntries[currentSentence], sentences.trainEntries[j], relationWordStats, sentences.trainEntries.Count) >= Constants.MIN_SIMILARITY_PERCENT)
                    {
                        if (!similarSentences.Contains(sentences.trainEntries[currentSentence]))
                        {
                            similarSentences.Add(sentences.trainEntries[currentSentence]);
                        }
                        if (!similarSentences.Contains(sentences.trainEntries[j]))
                        {
                            similarSentences.Add(sentences.trainEntries[j]);
                        }
                    }
                    //else
                    //{
                    //    if (!similarSentences.Contains(sentences[currentSentence]) && !unsimilarSentences.Contains(sentences[currentSentence]))
                    //    {
                    //        unsimilarSentences.Add(sentences[currentSentence]);
                    //    }
                    //    if (!unsimilarSentences.Contains(sentences[j]))
                    //    {
                    //        unsimilarSentences.Add(sentences[j]);
                    //    }
                    //}
                }
            }
            unsimilarSentences = sentences.trainEntries.Except(similarSentences).ToList();
            return similarSentences;
        }
        /// <summary>
        /// Compares two entry (Containing sentences) with diffrent metrics
        /// </summary>
        /// <param name="entry1"></param>
        /// <param name="entry2"></param>
        /// <returns>Percent of Similarity as Integer</returns>
        public int getSimilarityPercent(TripleEntry entry1, TripleEntry entry2, List<WordFrequencyStatistics> relationWordStats, int currentRelationSentenceCount)
        {
            int similarityScore = 0;
            string[] sentence1Words = (Constants.STEM_WORDS && entry1.stemmedWords != null ? entry1.stemmedWords.ToArray():parser.tokenizeSentence(entry1.sentence,Constants.IGNORE_PREPOSITIONS)),
                sentence2Words = (Constants.STEM_WORDS && entry2.stemmedWords != null ? entry2.stemmedWords.ToArray(): parser.tokenizeSentence(entry2.sentence, Constants.IGNORE_PREPOSITIONS));
            sentence1Words = sentence1Words.Where(w => !string.IsNullOrEmpty(w) && !w.ToLower().Equals("e1") && !w.ToLower().Equals("e2") && parser.isLetter(w)).ToArray();
            sentence2Words = sentence2Words.Where(w => !string.IsNullOrEmpty(w) && !w.ToLower().Equals("e1") && !w.ToLower().Equals("e2") && parser.isLetter(w)).ToArray();
            //analyze by comparing length of two sentence
            int sentenceLenghtAverage = (entry1.sentence.Length + entry2.sentence.Length) / 2;
            if (((entry1.sentence.Length - entry2.sentence.Length) / sentenceLenghtAverage) * 100
                <= Constants.MAX_SENTENCE_LENGTH_DIFFRENCE_PERCENT)
            {
                similarityScore += Constants.SENTENCE_LENGTH_QUALIFIED_SCORE;
            }
            // analyze by comparing word count of two sentence
            if (sentence1Words.Length - sentence2Words.Length <= Constants.MAX_SENTENCE_WORD_COUNT_DIFFRENCE)
            {
                similarityScore += Constants.SENTENCE_WORD_COUNT_QUALIFIED_SCORE;
            }
            // analyze by comparing common words of two sentence, Note: ignore prepositions here
            int sameWordsInCommon = 0;
            int averageWordCount = (sentence1Words.Length + sentence2Words.Length) / 2;
            foreach (string word in sentence1Words.Except(sentence1Words.Except(Constants.prepositions)))
            {
                if (sentence2Words.Contains(word.ToLower()))
                {
                    ++sameWordsInCommon;
                }
            }
            if (sameWordsInCommon / averageWordCount * 100 >= Constants.MIN_COMMON_WORDS_PERCENT)
            {
                similarityScore += Constants.COMMON_WORDS_SCORE;
            }
            // analyze by comparing non-same words of two sentence
            string[] sentence1ImportantWords = sentence1Words.Except(Constants.extraPonctuations).ToArray();
            string[] sentence2ImportantWords = sentence2Words.Except(Constants.extraPonctuations).ToArray();
            int sentence1NonSameWords = 0;
            foreach(string word in sentence1ImportantWords)
            {
                if (!sentence2ImportantWords.Contains(word) &&
                    relationWordStats.Where(s=>s.word.Equals(word) && s.frequency*100/currentRelationSentenceCount > Constants.MIN_FREQUENCY_FOR_REGEX_APPEARE_PERCENT).SingleOrDefault() != null)
                {
                    ++sentence1NonSameWords;
                }
            }
            int sentence2NonSameWords = 0;
            foreach (string word in sentence2ImportantWords)
            {
                if (!sentence1ImportantWords.Contains(word) &&
                    relationWordStats.Where(s => s.word.Equals(word) && s.frequency * 100 / currentRelationSentenceCount > Constants.MIN_FREQUENCY_FOR_REGEX_APPEARE_PERCENT).SingleOrDefault() != null)
                {
                    ++sentence2NonSameWords;
                }
            }
            int nonSameWords = Math.Max(sentence1NonSameWords, sentence2NonSameWords);
            int wordCount;
            if(sentence1NonSameWords > sentence2NonSameWords)
            {
                wordCount = sentence1ImportantWords.Count();
            }
            else
            {
                wordCount = sentence2ImportantWords.Count();
            }

            //int nonSameWords = (sentence1Words.Length > sentence2Words.Length ? sentence1Words.Length : sentence2Words.Length) - sameWordsInCommon;
            if (nonSameWords * 100 / wordCount  <= Constants.MAX_NON_SAME_WORDS_PERCENT)
            {
                similarityScore += Constants.NON_SAME_WORDS_QUALIFIED_SCORE;
            }

            return (similarityScore <= 100 ? similarityScore : 100);
        }
     
        public int getWordIndexOf(string source, string[] substring, out int endIndex)
        {

            int firstStartIndex = -1;
            bool isAnyNoMatch = false;
            try
            {
                string[] sourceWords = parser.tokenizeSentence(source, ignorePrepositions:false);
                do
                {
                    for (int counter = firstStartIndex + 1; counter < sourceWords.Length; counter++)
                    {
                        if (sourceWords[counter].Equals(substring[0]))
                        {
                            firstStartIndex = counter;
                            break;
                        }
                    }
                    isAnyNoMatch = false;
                    for (int index = 1; index < substring.Length; index++)
                    {
                        if (!sourceWords[firstStartIndex + index].Equals(substring[index]))
                        {
                            isAnyNoMatch = true;
                            break;
                        }
                    }
                    endIndex = firstStartIndex + substring.Length - 1;
                    return firstStartIndex;
                } while (isAnyNoMatch || firstStartIndex < 0);
            }
            catch(IndexOutOfRangeException ioore)
            {
                firstStartIndex = endIndex = -1;
                return firstStartIndex;
                ;
            }

        }
        public List<RegexContainer> regularExpressionGeneratorX(SentencesWithCommonPivotWords sentences, List<WordFrequencyStatistics> wordFrequencyStats)
        {
            PivotWord pivotWordsList = null;
            List<RegexContainer> regexList = new List<RegexContainer>();
            pivotWordsList = Constants.pivotWords.Where(p => p.relation == sentences.trainEntries[0].relationType).SingleOrDefault();

            //string regex = "";
            RegularExpression finalRegex = new RegularExpression();
            List<RegularExpression> regexes = new List<RegularExpression>();
            RegularExpression entityRegex;
            if (sentences.trainEntries != null && sentences.trainEntries.Count > 0)
            {
                foreach (TripleEntry sentence in sentences.trainEntries)
                {
                    RegularExpression regex = new RegularExpression();
                    entityRegex = new RegularExpression();
                    entityRegex.regexParts.Add(RegularExpression.WORD_REGEX + "*");
                    List<string> words = (Constants.STEM_WORDS && sentence.stemmedWords != null ? sentence.stemmedWords :parser.tokenizeSentence( sentence.sentence,ignorePrepositions:false).ToList());
                    // if current sentence matches current pivot regex (generic form of word), store 
                    // current pivot regex start and and (word) index, plus currentPivotRegex itself in a place
                    string pureSentence = parser.untokenizeSentence(words);
                    List<PivotRegexLocation> pivotRegexLocs = new List<PivotRegexLocation>();
                    PivotRegexLocation pivotRegexLoc = new PivotRegexLocation();
                    bool ignoreE1Tag = false, ignoreE2Tag = false;
                    if (pivotWordsList != null && pivotWordsList.pivotWordItems.Count > 0)
                    {                        
                        foreach(PivotWordItem pivotWord in sentences.pivotWords)
                        {
                            Match regexMatch = Regex.Match(pureSentence, pivotWord.word.Replace("w", RegularExpression.WORD_REGEX));
                            if (regexMatch.Success)
                            {
                                pivotRegexLoc.pivot = pivotWord.word;
                                int endWordIndex;
                                pivotRegexLoc.startWordIndex = getWordIndexOf(pureSentence,parser.tokenizeSentence( regexMatch.Value,ignorePrepositions:false), out endWordIndex);
                                pivotRegexLoc.endWordIndex  = endWordIndex ;
                                // if <e1> tag is contained in pivot as a regex, don't process it further separatly
                                if (pivotWord.word.Contains("<e1>"))
                                {
                                    ignoreE1Tag = true;
                                }
                                if (pivotWord.word.Contains("<e2>"))
                                {
                                    ignoreE2Tag = true;
                                }
                            }
                        }
                        pivotRegexLocs.Add(pivotRegexLoc);
                    }
                    if (pivotRegexLocs == null || pivotRegexLocs.Count == 0 || pivotRegexLocs[0].startWordIndex == -1 || pivotRegexLocs[0].endWordIndex == -1)
                        continue; // ignore this sentence and throw it away 'cause it's pivot maybe is not separatable from other words
                    ////////
                    for (int wordIndex = 0; wordIndex < words.Count; wordIndex++)
                    {
                        bool wasProccessed = false;
                        WordFrequencyStatistics wordStatistics = wordFrequencyStats.Where(s => s.word.ToLower().Equals(words[wordIndex])).SingleOrDefault();
                        //////
                        // if word is a pivot one
                        // if current word is beginning of a pivot (regex), ignore current for-loop and from current word to end of pivot and consider these words as pivot
                        PivotRegexLocation pivotLocation = pivotRegexLocs.Where(l => l.startWordIndex == wordIndex).SingleOrDefault();
                        if (sentences.trainEntries[0].relationType.Equals("component-whole(e1,e2)"))
                        {
                            ;// todo: temporary just to trap a specia case to debug
                        }
                        if(pivotLocation != null && !regex.regexParts.Contains(pivotLocation.pivot))
                        {
                            regex.regexParts.Add("\\s"+pivotLocation.pivot+"\\s");
                            regex.pivotIndices.Add(pivotLocation.startWordIndex);
                            wasProccessed = true;
                            // jump to end of pivot word(s) end
                            wordIndex = pivotLocation.endWordIndex;
                            continue;
                        }

                        //////
                        if(words[wordIndex].Equals("<e1>") && !ignoreE1Tag  )
                        {
                            if(regex.regexParts.Count > 0)
                            {
                                if(!regex.regexParts[regex.regexParts.Count - 1].Equals(RegularExpression.WORD_REGEX + "+"))
                                {
                                    // merge sequential w+w* forms
                                    if (regex.regexParts[regex.regexParts.Count - 1].Equals(RegularExpression.WORD_REGEX + "*"))
                                    {
                                        regex.regexParts[regex.regexParts.Count - 1] = RegularExpression.WORD_REGEX + "+";                                        
                                    }
                                    else
                                    {
                                        regex.regexParts.Add(RegularExpression.WORD_REGEX + "+");// ("("+sentence.entity1+"|Regex.WORD_REGEX + "+")");                                        
                                    }
                                    wasProccessed = true;
                                }                               
                                
                            }
                            else
                            {
                                regex.regexParts.Add(RegularExpression.WORD_REGEX + "+");// ("("+sentence.entity1+"|Regex.WORD_REGEX + "+")");
                                wasProccessed = true;
                            }
                            if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX)
                            {
                                entityRegex.regexParts.Add((Constants.STEM_WORDS ? parser.doStemming(sentence.entity1.Trim(), Constants.CURRENT_LANGUAGE) :
                                    sentence.entity1.Trim()).Replace(" ", "\\s") + RegularExpression.WORD_REGEX + "*");
                            }
                        }
                        else if (words[wordIndex].Equals("<e2>") && !ignoreE2Tag )
                        {
                            if(regex.regexParts.Count > 0)
                            {
                                // merge sequential w*w+ forms to w+
                                if(!regex.regexParts[regex.regexParts.Count - 1].Equals(RegularExpression.WORD_REGEX + "+"))
                                {                                    
                                    if (regex.regexParts[regex.regexParts.Count - 1].Equals(RegularExpression.WORD_REGEX + "*"))
                                    {
                                        regex.regexParts[regex.regexParts.Count - 1] = RegularExpression.WORD_REGEX + "+";                                        
                                    }
                                    else
                                    {
                                        regex.regexParts.Add(RegularExpression.WORD_REGEX + "+");// ("(" + sentence.entity2 + "|Regex.WORD_REGEX + "+")");
                                    }
                                    wasProccessed = true;
                                }                                 
                            }
                            else
                            {
                                regex.regexParts.Add(RegularExpression.WORD_REGEX + "+");// ("("+sentence.entity1+"|Regex.WORD_REGEX + "+")");
                                wasProccessed = true;
                            }
                            if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX)
                            {
                                entityRegex.regexParts.Add((Constants.STEM_WORDS ? parser.doStemming(sentence.entity2.Trim(), Constants.CURRENT_LANGUAGE) :
                                    sentence.entity2.Trim()).Replace(" ", "\\s") + RegularExpression.WORD_REGEX + "*");
                            }
                        }
                        else if (words[wordIndex].ToLower().Contains("<e1>"))
                        {
                            regex.regexParts.Add(/*"(" + sentence.entity1.Replace(" ", "\\s") + "|" +*/ RegularExpression.WORD_REGEX + "+");// + ")";
                            if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX)
                            {
                                entityRegex.regexParts.Add((Constants.STEM_WORDS ? parser.doStemming(sentence.entity1.Trim(), Constants.CURRENT_LANGUAGE) : sentence.entity1.Trim()).Replace(" ", "\\s") + RegularExpression.WORD_REGEX + "*");
                            }
                            words[wordIndex] = words[wordIndex].Replace("<e1>", "");
                        }
                        else if (words[wordIndex].ToLower().Contains("<e2>"))
                        {
                            regex.regexParts.Add(/*"(" + sentence.entity2.Replace(" ", "\\s") + "|" + */RegularExpression.WORD_REGEX + "+");// + ")";
                            if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX)
                            {
                                entityRegex.regexParts.Add((Constants.STEM_WORDS ? parser.doStemming(sentence.entity2.Trim(), Constants.CURRENT_LANGUAGE) : sentence.entity2.Trim()).Replace(" ", "\\s") + RegularExpression.WORD_REGEX + "*");
                            }
                            words[wordIndex] = words[wordIndex].Replace("<e2>", "");
                        }
                        if (words[wordIndex].ToLower().Contains("</e1>"))
                        {
                            words[wordIndex] = words[wordIndex].Replace("</e1>", "");
                        }
                        if (words[wordIndex].ToLower().Contains("</e2>"))
                        {
                            words[wordIndex] = words[wordIndex].Replace("</e2>", "");
                        }
                        if (!wasProccessed)
                        {
                            if (wordStatistics != null && wordStatistics.frequency * 100 / sentences.trainEntries.Count >= Constants.MIN_FREQUENCY_FOR_REGEX_APPEARE_PERCENT
                                && Constants.prepositions != null && !Constants.prepositions.Contains(words[wordIndex]))
                            {
                                if(wordIndex > 0 && (!words[wordIndex].Equals(words[wordIndex - 1]) || words[wordIndex].Equals("تک") || !words[wordIndex].Equals("یک")))
                                {
                                    string whitespace = string.Empty;    
                                    if(regex.regexParts.Count > 0 && char.IsLetter(regex.regexParts[regex.regexParts.Count-1].Last()))
                                    {
                                        whitespace = "\\s";
                                    }                           
                                    regex.regexParts.Add(whitespace+ words[wordIndex]);
                                }                                
                            }
                            else 
                            {
                                if(regex.regexParts.Count > 0)
                                {
                                    // merge sequential w+w* forms 
                                    if (!regex.regexParts[regex.regexParts.Count - 1].Equals(RegularExpression.WORD_REGEX + "*") ||
                                        !regex.regexParts[regex.regexParts.Count - 1].Equals(RegularExpression.WORD_REGEX + "+"))
                                    {                                                                               
                                        regex.regexParts.Add(RegularExpression.WORD_REGEX + "*");                                        
                                    }                                    
                                }
                                else
                                {
                                    regex.regexParts.Add(RegularExpression.WORD_REGEX + "*");
                                }                                
                            }
                        }                        
                    }
                    regexes.Add(regex);
                    // add entity regex of this sentence to final list
                    if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX && (!entityRegex.ToString().Equals("^w*$") && !entityRegex.ToString().Equals("^w+$")))
                    {
                        regexList.Add(new RegexContainer((sentences.trainEntries.Count > 0 ? sentences.trainEntries[0].relationType : string.Empty), entityRegex));
                    }
                }
                //todo: simplify regexes: w+w* and similar expression with simplified one

                ///
                int maxPivotIndex = regexes.Max(r => r.pivotIndices.Count > 0 ? r.pivotIndices[0] : 0);
                int maxRegexLen = regexes.Max(r => r.regexParts.Count);

                List<RegularExpression> AllOrClauses = new List<RegularExpression>();

                foreach (RegularExpression r in regexes)
                {
                    RegularExpression orClauses = new RegularExpression();
                    for (int i = 0; i < r.regexParts.Count; i++)
                    {
                        if (r.pivotIndices.Count == 0)
                            continue;
                        if (r.pivotIndices[0] + i - maxPivotIndex < 0 )
                        {
                            if(orClauses.regexParts.Count > 0 )
                            {
                                if(!orClauses.regexParts[orClauses.regexParts.Count - 1].Equals(RegularExpression.WORD_REGEX + "*"))
                                {
                                    orClauses.regexParts.Add(RegularExpression.WORD_REGEX + "*");
                                }
                            }
                            else
                            {
                                orClauses.regexParts.Add(RegularExpression.WORD_REGEX + "*");
                            }
                            
                        }
                        else if (r.pivotIndices[0] + i - maxPivotIndex > r.regexParts.Count)
                        {
                            orClauses.regexParts.Add("");
                        }
                        else
                        {
                            orClauses.regexParts.Add(r.regexParts[r.pivotIndices[0] + i - maxPivotIndex]);
                        }
                    }
                    AllOrClauses.Add(orClauses);
                }
                try
                {
                    // add new algorithm here for making all regexes with same width
                    RegularExpression mostLengthyRegex = regexes.Where(r => r.regexParts.Count == maxRegexLen).First();
                    List<RegularExpression> sameWidthRegexes = new List<RegularExpression>();
                    foreach (RegularExpression regex in regexes)
                    {
                        RegularExpression enlargedRegex = new RegularExpression();
                        enlargedRegex.regexParts.AddRange(new string[maxRegexLen]);
                        foreach (string regexPart in regex.regexParts)
                        {
                            if (regexPart != null && mostLengthyRegex.regexParts.Contains(regexPart))
                            {
                                // if regex part is not exist in mostLengthyRegex append it to previus box
                                if (mostLengthyRegex.regexParts.IndexOf(regexPart, enlargedRegex.regexParts.LastIndexOf(regexPart) + 1) == -1)
                                {
                                    enlargedRegex.regexParts[regex.regexParts.IndexOf(regexPart, regex.regexParts.LastIndexOf(regexPart) - 1)] += regexPart;
                                }
                                else
                                {
                                    enlargedRegex.regexParts[mostLengthyRegex.regexParts.IndexOf(regexPart, enlargedRegex.regexParts.LastIndexOf(regexPart) + 1)] = regexPart;
                                }

                            }
                        }
                        for (int i = 0; i < regex.regexParts.Count; i++)
                        {
                            if (!mostLengthyRegex.regexParts.Contains(regex.regexParts[i]))
                            {
                                if (string.IsNullOrEmpty(enlargedRegex.regexParts[i]))
                                {
                                    enlargedRegex.regexParts[i] = regex.regexParts[i];
                                }
                                else if (i > 0)
                                {
                                    if (enlargedRegex.regexParts[i - 1] != null && char.IsLetter(enlargedRegex.regexParts[i - 1].Last()))
                                    {
                                        enlargedRegex.regexParts[i - 1] += "\\s" + regex.regexParts[i];
                                    }
                                    else
                                    {
                                        enlargedRegex.regexParts[i - 1] += regex.regexParts[i];
                                    }
                                }
                                else
                                {
                                    enlargedRegex.regexParts[i] += regex.regexParts[i];
                                }
                            }
                        }
                        sameWidthRegexes.Add(enlargedRegex);
                    }
                    finalRegex = finalRegex.makeOrClause(sameWidthRegexes, pivotWordsList, sentences.trainEntries);
                }
                catch(IndexOutOfRangeException ioore)
                {
                    ;
                }
            }
            
            if (!finalRegex.ToString().Equals("^w*$") && !finalRegex.ToString().Equals("^w+$"))
            {
                List<RegexContainer> duplicatedRegexes;
                RegexContainer finalRegexContainer = new RegexContainer((sentences.trainEntries.Count > 0 ? sentences.trainEntries[0].relationType : string.Empty), finalRegex);
                if ((duplicatedRegexes = regexList.Where(r => r.regex.Equals(finalRegex)).ToList()).Count() == 0)
                {
                    regexList.Add(finalRegexContainer);
                }
                else
                {
                    Constants.LOG += "\nWARINING: "+finalRegexContainer.regex +" Relation: "+finalRegexContainer.relation + "Is DUPLICATED\n";
                }
            }
            
            return regexList;
        }
        public List<RegexContainer> regularExpressionGenerator(TripleEntry sentence, List<WordFrequencyStatistics> unsimilarSentencesStats, List<RegexContainer> currentRegexes,
            List<RelationStatistics> allWithPivotRelationStats = null)
        {            
            RegularExpression regex = new RegularExpression();
            RegularExpression entityRegex = new RegularExpression();
            entityRegex.regexParts.Add( RegularExpression.WORD_REGEX + "*");
            if (sentence != null && !string.IsNullOrEmpty(sentence.sentence))
            {
                List<string> words = parser.tokenizeSentence(sentence.sentence,Constants.IGNORE_PREPOSITIONS).ToList();
                foreach (string word in words)
                {
                    /*if (statistics.frequency < Constants.MIN_FREQUENCY_FOR_REGEX_APPEARE_PERCENT)
                    {
                        regex += Regex.WORD_REGEX + "+";
                    }
                    else if (statistics.frequency >= Constants.MIN_FREQUENCY_FOR_REGEX_APPEARE_PERCENT)*/
                    string w = word;
                    if (w.ToLower().Equals("<e1>"))
                    {
                        regex.regexParts.Add ( /*"("+sentence.entity1.Trim().Replace(" ","\\s") + "|" +*/ RegularExpression.WORD_REGEX + "+");// + ")";
                        if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX)
                        {
                            entityRegex.regexParts.Add((Constants.STEM_WORDS? parser.doStemming(sentence.entity1.Trim(), Constants.CURRENT_LANGUAGE):
                                sentence.entity1.Trim()).Replace(" ", "\\s") + RegularExpression.WORD_REGEX + "*");
                        }
                        continue; // ignore entity tag, may want to replace with real entity with a user option
                    }
                    else if (w.ToLower().Equals("<e2>"))
                    {
                        regex.regexParts.Add( /*"(" + sentence.entity2.Trim().Replace(" ", "\\s") + "|"+*/ RegularExpression.WORD_REGEX + "+");// + ")";
                        if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX)
                        {
                            entityRegex.regexParts.Add((Constants.STEM_WORDS ? parser.doStemming(sentence.entity2.Trim(), Constants.CURRENT_LANGUAGE) : sentence.entity2.Trim()).Replace(" ", "\\s") + RegularExpression.WORD_REGEX + "*");
                        }
                        continue;
                    }
                    if (w.ToLower().Contains("<e1>"))
                    {
                        regex.regexParts.Add(/*"(" + sentence.entity1.Replace(" ", "\\s") + "|" +*/ RegularExpression.WORD_REGEX + "+");// + ")";
                        if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX)
                        {
                            entityRegex.regexParts.Add((Constants.STEM_WORDS ? parser.doStemming(sentence.entity1.Trim(), Constants.CURRENT_LANGUAGE) : sentence.entity1.Trim()).Replace(" ", "\\s") + RegularExpression.WORD_REGEX + "*");
                        }
                        w = w.Replace("<e1>","");
                    }
                    if (w.ToLower().Contains("<e2>"))
                    {
                        regex.regexParts.Add(/*"(" + sentence.entity2.Replace(" ", "\\s") + "|" + */RegularExpression.WORD_REGEX + "+");// + ")";
                        if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX)
                        {
                            entityRegex.regexParts.Add( (Constants.STEM_WORDS ? parser.doStemming(sentence.entity2.Trim(), Constants.CURRENT_LANGUAGE) : sentence.entity2.Trim()).Replace(" ", "\\s") + RegularExpression.WORD_REGEX + "*");
                        }
                        w = w.Replace("<e2>","");
                    }
                    if (w.ToLower().Contains("</e1>"))
                    {
                        w = w.Replace("</e1>","");
                    }
                    if (w.ToLower().Contains("</e2>"))
                    {
                        w = w.Replace("</e2>","");
                    }
                    
                    //WordFrequencyStatistics wordStatsInSimilarSentences = null;
                    WordFrequencyStatistics wordStatsInUnSimilarSentences = null;
                    if (unsimilarSentencesStats != null)
                    {
                        wordStatsInUnSimilarSentences = unsimilarSentencesStats.Where(s => s.word.ToLower().Equals(w.ToLower())).SingleOrDefault();
                    }

                    //if (similarSentencesStats != null)
                    //{
                    //    wordStatsInSimilarSentences = similarSentencesStats.Where(s => s.word.ToLower().Equals(w.ToLower())).SingleOrDefault();
                    //}
                    int wordFreqInAllWithPivotSentences = 0;
                    if(allWithPivotRelationStats != null)
                    {
                        foreach (RelationStatistics relStats in allWithPivotRelationStats)
                        {
                            foreach (var wordFrequency in relStats.wordFrequencies)
                            {
                                WordFrequencyStatistics frequency = wordFrequency.Where(wf => wf.word.ToLower().Equals(w)).SingleOrDefault();
                                if (frequency != null)
                                {
                                    if (wordFreqInAllWithPivotSentences != 0)
                                    {
                                        wordFreqInAllWithPivotSentences = wordFreqInAllWithPivotSentences * frequency.frequency / 2;
                                    }
                                    else
                                    {
                                        wordFreqInAllWithPivotSentences = frequency.frequency;
                                    }
                                }
                            }
                        }
                        
                    }
                    int wordFrequencyStatistics = 0;
                    int allWithPivotRelationSentenceCount = 0;
                    if (allWithPivotRelationStats != null && allWithPivotRelationStats.Count > 0 && allWithPivotRelationStats[0].similarTrainEntries != null && 
                        allWithPivotRelationStats[0].similarTrainEntries.Count > 0)
                    {
                        allWithPivotRelationSentenceCount = allWithPivotRelationStats.Sum(a => a.similarTrainEntries.Count);
                    }
                   
                    if (wordStatsInUnSimilarSentences != null)
                    {
                        wordFrequencyStatistics = wordStatsInUnSimilarSentences.frequency * 100 / unsimilarSentencesStats.Count ;                        
                    }
                    if(wordFreqInAllWithPivotSentences != 0)
                    {
                        if(wordFrequencyStatistics != 0)
                        {
                            wordFrequencyStatistics =(allWithPivotRelationSentenceCount == 0 ? 0: (wordFrequencyStatistics + (wordFreqInAllWithPivotSentences * 100 / allWithPivotRelationSentenceCount)) / 2);
                        }
                        else
                        {
                            wordFrequencyStatistics =(allWithPivotRelationSentenceCount==0?0: wordFreqInAllWithPivotSentences * 100 / allWithPivotRelationSentenceCount);
                        }
                    }
                    
                    string stemmedWord = (Constants.STEM_WORDS ? parser.doStemming(w , Constants.CURRENT_LANGUAGE) : w);
                    if (wordFrequencyStatistics >= Constants.MIN_FREQUENCY_FOR_APPEARE_IN_LOW_FREQ_REGEX_PERCENT)
                    {
                        if (Constants.USE_SYSNONYMS && (synonymsDb = Database.Instance()) != null && !Constants.STEM_WORDS && !w.Equals("می") &&
                                !w.Equals("در") && !w.Equals("بر") && !w.Equals("ده" ) && !w.Equals("کند")
                                && !w.Equals("اند"))
                        {
                            Word myWord = synonymsDb.MotaradefMotazadList.Where(s => s.Name.ToLower().Equals(w)).FirstOrDefault();
                        
                            if (myWord != null && myWord.MeaningGroups.Count > 0)
                            {
                                List<string> synonyms = myWord.MeaningGroups[0].Syns.Take(Constants.MAX_SYNONYMS_COUNT).ToList();
                                if (synonyms.Count > 0)
                                {
                                    regex.regexParts.Add( "(" + stemmedWord);

                                    foreach (string syn in synonyms)
                                    {
                                        regex .regexParts.Add( "|" + (Constants.STEM_WORDS ? parser.doStemming(syn, Constants.CURRENT_LANGUAGE) : syn));
                                    }
                                    regex.regexParts.Add( ")");
                                }
                            }
                            else
                            {
                                regex.regexParts.Add( stemmedWord);
                            }                       
                        }
                        else
                        {
                            regex.regexParts.Add(stemmedWord);
                        }
                    }
                    
                    else if(string.IsNullOrEmpty(regex.ToString()) || regex.ToString().Length < (RegularExpression.WORD_REGEX + "*").Length || !regex.ToString().Substring(regex.ToString().Length-(RegularExpression.WORD_REGEX+"*").Length).Equals(RegularExpression.WORD_REGEX+"*"))
                    {
                        regex.regexParts.Add( RegularExpression.WORD_REGEX + "*");
                    }
                    //if (regex.EndsWith(")") || regex.EndsWith("+") || regex.EndsWith("*") || regex.EndsWith("|") || regex.EndsWith("^"))
                    string currentRegex = regex.ToString();
                    if (!string.IsNullOrEmpty(currentRegex) && currentRegex.Length > 1 && char.IsLetter(char.Parse(currentRegex.Substring(currentRegex.Length-2,1))))
                    {
                        regex.regexParts.Add("\\s");
                    }
                }
            }
            List<RegexContainer> regexes = new List<RegexContainer>();
            List<RegexContainer> duplicatedRegexes;
            StringBuilder reg = new StringBuilder(regex.ToString());
            if (!reg.Equals("^w*$") && !reg.Equals("^w+$") && !reg.Equals("^$") &&
                (Constants.IGNORE_NON_REACH_REGEXES && reg.Replace("^", "").Replace("$", "").Replace("w+", "").Replace("w*", "").Replace("\\s", "").Replace(" ", "").Replace("(", "").Replace(")", "").Length > 3))
            {
                RegexContainer regexContainer = new RegexContainer(sentence.relationType, regex);
                if (currentRegexes == null || (duplicatedRegexes = currentRegexes.Where(r => r.regex.Equals(regex)).ToList()).Count() == 0)
                {
                    regexes.Add(regexContainer);
                }
                else //if(duplicatedRegexes.Where(r=>!r.relation.Equals(sentence.relationType))
                {
                    Constants.LOG += "\nWARINING: " + regexContainer.regex + " Relation: " + regexContainer.relation + " is DUPLICATED\n";
                }
            }
            else
                ;
            if (Constants.LEARN_ENTITIES_ITSELF_AS_REGEX && !(entityRegex.ToString().Equals("^w*$") && entityRegex.ToString().Equals("^w+$")))
            {
                RegexContainer entityRegexContainer = new RegexContainer(sentence.relationType, entityRegex);
                if (currentRegexes == null || (duplicatedRegexes = currentRegexes.Where(r => r.regex.Equals(entityRegex)).ToList()).Count() == 0)
                {
                    regexes.Add(entityRegexContainer);
                }
                else
                {
                    Constants.LOG += "\nWARINING: " + entityRegexContainer.regex + " Relation: " + entityRegexContainer.relation + " is DUPLICATED\n";
                }
                
                if (!entityRegexContainer.regex.ToString().Equals("^w*$") && !entityRegexContainer.ToString().Equals("^w+$") && !entityRegexContainer.ToString().Equals("^$")
                    && !(entityRegexContainer.regex.regexParts.Count == 1 && entityRegexContainer.regex.regexParts[0].Equals(RegularExpression.WORD_REGEX)))
                {
                    regexes.Add(entityRegexContainer);
                }
            }
            return regexes; 
        }
    }
}
