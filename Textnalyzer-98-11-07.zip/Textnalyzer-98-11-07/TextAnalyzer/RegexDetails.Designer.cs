﻿namespace TextAnalyzer
{
    partial class frmRegexDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegexDetails));
            this.txtSupervisorName = new System.Windows.Forms.TextBox();
            this.txtRegex = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbCoveringSentences = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnRecover = new System.Windows.Forms.Button();
            this.lbVersionHistory = new System.Windows.Forms.ListBox();
            this.btnOkay = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtTestRegex = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnConfirmEdit = new System.Windows.Forms.Button();
            this.chkSimpleRegexView = new System.Windows.Forms.CheckBox();
            this.lblClearTestSentence = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSupervisorName
            // 
            this.txtSupervisorName.Location = new System.Drawing.Point(16, 37);
            this.txtSupervisorName.Name = "txtSupervisorName";
            this.txtSupervisorName.Size = new System.Drawing.Size(703, 21);
            this.txtSupervisorName.TabIndex = 0;
            this.txtSupervisorName.Text = "Default Supervisor";
            // 
            // txtRegex
            // 
            this.txtRegex.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtRegex.Location = new System.Drawing.Point(16, 79);
            this.txtRegex.Name = "txtRegex";
            this.txtRegex.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtRegex.Size = new System.Drawing.Size(703, 31);
            this.txtRegex.TabIndex = 0;
            this.txtRegex.TextChanged += new System.EventHandler(this.txtRegex_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Supervisor Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Regex:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbCoveringSentences);
            this.groupBox1.Location = new System.Drawing.Point(16, 179);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(817, 323);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Covering Sentences";
            // 
            // lbCoveringSentences
            // 
            this.lbCoveringSentences.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbCoveringSentences.FormattingEnabled = true;
            this.lbCoveringSentences.ItemHeight = 24;
            this.lbCoveringSentences.Location = new System.Drawing.Point(12, 24);
            this.lbCoveringSentences.Name = "lbCoveringSentences";
            this.lbCoveringSentences.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbCoveringSentences.Size = new System.Drawing.Size(799, 268);
            this.lbCoveringSentences.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnRecover);
            this.groupBox2.Controls.Add(this.lbVersionHistory);
            this.groupBox2.Location = new System.Drawing.Point(839, 26);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(254, 476);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Regex Version History";
            // 
            // btnRecover
            // 
            this.btnRecover.Location = new System.Drawing.Point(7, 24);
            this.btnRecover.Name = "btnRecover";
            this.btnRecover.Size = new System.Drawing.Size(114, 23);
            this.btnRecover.TabIndex = 3;
            this.btnRecover.Text = "< Recover";
            this.btnRecover.UseVisualStyleBackColor = true;
            // 
            // lbVersionHistory
            // 
            this.lbVersionHistory.FormattingEnabled = true;
            this.lbVersionHistory.Location = new System.Drawing.Point(6, 57);
            this.lbVersionHistory.Name = "lbVersionHistory";
            this.lbVersionHistory.Size = new System.Drawing.Size(242, 407);
            this.lbVersionHistory.TabIndex = 0;
            // 
            // btnOkay
            // 
            this.btnOkay.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnOkay.Location = new System.Drawing.Point(839, 512);
            this.btnOkay.Name = "btnOkay";
            this.btnOkay.Size = new System.Drawing.Size(254, 30);
            this.btnOkay.TabIndex = 3;
            this.btnOkay.Text = "Okay";
            this.btnOkay.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(661, 512);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(114, 30);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtTestRegex
            // 
            this.txtTestRegex.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtTestRegex.Location = new System.Drawing.Point(16, 136);
            this.txtTestRegex.Name = "txtTestRegex";
            this.txtTestRegex.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtTestRegex.Size = new System.Drawing.Size(703, 31);
            this.txtTestRegex.TabIndex = 0;
            this.txtTestRegex.TextChanged += new System.EventHandler(this.txtTestRegex_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(172, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Test Regex by Entering Sentence:";
            // 
            // btnConfirmEdit
            // 
            this.btnConfirmEdit.Location = new System.Drawing.Point(725, 77);
            this.btnConfirmEdit.Name = "btnConfirmEdit";
            this.btnConfirmEdit.Size = new System.Drawing.Size(108, 37);
            this.btnConfirmEdit.TabIndex = 3;
            this.btnConfirmEdit.Text = "Confirm Edit >";
            this.btnConfirmEdit.UseVisualStyleBackColor = true;
            // 
            // chkSimpleRegexView
            // 
            this.chkSimpleRegexView.AutoSize = true;
            this.chkSimpleRegexView.Location = new System.Drawing.Point(724, 41);
            this.chkSimpleRegexView.Name = "chkSimpleRegexView";
            this.chkSimpleRegexView.Size = new System.Drawing.Size(115, 17);
            this.chkSimpleRegexView.TabIndex = 4;
            this.chkSimpleRegexView.Text = "Simple Regex View";
            this.chkSimpleRegexView.UseVisualStyleBackColor = true;
            this.chkSimpleRegexView.CheckedChanged += new System.EventHandler(this.chkSimpleRegexView_CheckedChanged);
            // 
            // lblClearTestSentence
            // 
            this.lblClearTestSentence.AutoSize = true;
            this.lblClearTestSentence.BackColor = System.Drawing.Color.Transparent;
            this.lblClearTestSentence.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblClearTestSentence.Location = new System.Drawing.Point(695, 140);
            this.lblClearTestSentence.Name = "lblClearTestSentence";
            this.lblClearTestSentence.Size = new System.Drawing.Size(20, 22);
            this.lblClearTestSentence.TabIndex = 1;
            this.lblClearTestSentence.Text = "X";
            this.lblClearTestSentence.Click += new System.EventHandler(this.lblClearTestSentence_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(61, 61);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 13);
            this.lblMessage.TabIndex = 1;
            // 
            // frmRegexDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1105, 556);
            this.Controls.Add(this.chkSimpleRegexView);
            this.Controls.Add(this.btnConfirmEdit);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOkay);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblClearTestSentence);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTestRegex);
            this.Controls.Add(this.txtRegex);
            this.Controls.Add(this.txtSupervisorName);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRegexDetails";
            this.ShowInTaskbar = false;
            this.Text = "Regex Details";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSupervisorName;
        private System.Windows.Forms.TextBox txtRegex;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnOkay;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ListBox lbCoveringSentences;
        private System.Windows.Forms.ListBox lbVersionHistory;
        private System.Windows.Forms.TextBox txtTestRegex;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnRecover;
        private System.Windows.Forms.Button btnConfirmEdit;
        private System.Windows.Forms.CheckBox chkSimpleRegexView;
        private System.Windows.Forms.Label lblClearTestSentence;
        private System.Windows.Forms.Label lblMessage;
    }
}