﻿using System;
using System.Collections.Generic;
using System.Linq;
using Re2.Net;
using System.IO;
using System.Windows;
namespace TextAnalyzer
{
    public sealed class Database
    {
        private static Database _instance = null;
        public static Database Instance()
        {
            if (_instance == null)
                return _instance = new Database();
            else
                return _instance;
        }

        public List<Word> MotaradefMotazadList { get; }
        public List<Word> TeyfiList { get; }

        private Database()
        {
            
            string dict_Teyfi;// = Properties.Resources.Teyfi;
            //string data = dict_motaradef_Motazad + Environment.NewLine + dict_Teyfi;
            
            dict_Teyfi = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Teyfi.txt"));

            

            string[] _lines2 = dict_Teyfi.Split(new[] { '\n' },
                StringSplitOptions.RemoveEmptyEntries);

            MotaradefMotazadList = loadSynonymsLibrary();
            TeyfiList = GetWords(_lines2);
        }
        public List<Word> loadSynonymsLibrary()
        {
            string dict_motaradef_Motazad;// = Properties.Resources.Motaradef_Motazad;
            dict_motaradef_Motazad = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Farhang_Motaradef-Motazad.txt"));
            string[] _lines1 = dict_motaradef_Motazad.Split(new[] { '\n' },
                StringSplitOptions.RemoveEmptyEntries);
             return GetWordsMoteradefMotezad(_lines1);

        }
        private List<Word> GetWordsMoteradefMotezad(string[] lines)
        {
            List<Word> words = new List<Word>();
            Word word = new Word();
            MeaningGroup group = new MeaningGroup();

            foreach (var line in lines)
            {
                word = new Word();

                //if (!line.Contains('1'))
                //{
                //    word.Name = line;
                //    word.MeaningGroups = new List<MeaningGroup>();
                //    continue;
                //}

                string[] split1 = line.Split('&')[0].Split(new char[]{ '1', '2', '3', '4', '5', '6', '7', '8', '9'},StringSplitOptions.RemoveEmptyEntries);

                word.Name = split1[0].Split('،')[0].Trim();

                List<string> split2 = split1[(split1.Length > 2 ? 1 : 0)].Split(new char[] { '،' },Constants.MAX_SYNONYMS_COUNT,StringSplitOptions.RemoveEmptyEntries).ToList();
                if(split1.Length == 1)
                {
                    split2.RemoveAt(0);
                }
                foreach (var part in split2)
                {
                    group = new MeaningGroup();
                    //if (!part.Contains("≠"))
                    //{
                        group.Syns.Add(part.Trim());// = part.Split('،').ToList();
                        group.Acros = new List<string>();
                    //}
                    //else
                    //{
                    //    group.Syns = part.Split('≠')[0].Split('،').ToList();
                    //    group.Acros = part.Split('≠')[1].Split('،').ToList();
                    //}

                    word.MeaningGroups.Add(group);
                }

                words.Add(word);
            }

            return words;
        }
        private List<Word> GetWords(string[] lines)
        {
            List<Word> words=new List<Word>();
            Word word = new Word();
            MeaningGroup group = new MeaningGroup();

            foreach (var line in lines)
            {
                word = new Word();
                if (!line.Contains('؛'))
                {
                    word.Name = line;
                    word.MeaningGroups = new List<MeaningGroup>();
                    continue;
                }

                string[] split1 = line.Split('؛');

                word.Name = split1[0];

                List<string> split2 = split1[1].Split('|').ToList();

                foreach (var part in split2)
                {
                    group = new MeaningGroup();
                    if (!part.Contains("≠"))
                    {
                        group.Syns = part.Split('،').ToList();
                        group.Acros = new List<string>();
                    }
                    else
                    {
                        group.Syns = part.Split('≠')[0].Split('،').ToList();
                        group.Acros = part.Split('≠')[1].Split('،').ToList();
                    }

                    word.MeaningGroups.Add(group);
                }

                words.Add(word);
            }

            return words;
        }


        public int GetCount()
        {
            int count = 0;
            foreach (var word in MotaradefMotazadList)
            {
                foreach (var group in word.MeaningGroups)
                {
                    count += group.Syns.Count + group.Acros.Count;
                }
            }

            foreach (var word in TeyfiList)
            {
                foreach (var group in word.MeaningGroups)
                {
                    count += group.Syns.Count + group.Acros.Count;
                }
            }
            return count;
        }
    }
}
