﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TextAnalyzer.Models
{
    public class TripleEntry
    {
        public TripleEntry()
        {
            this.isAlreadyGrouped = false;
            this.stemmedWords = null;
        }
        public TripleEntry(string entity1, string entity2, string relationType, bool isAlreadyGrouped = false)
        {
            this.entity1 = entity1;
            this.entity2 = entity2;
            this.relationType = relationType;
            this.isAlreadyGrouped = isAlreadyGrouped;
        }
        public string sentence
        {
            get;
            set;
        }
        public string relationType
        {
            get;
            set;
        }
        public string comment
        {
            get;
            set;
        }

        public string entity1
        {
            get;
            set;
        }
        public string entity2
        {
            get;
            set;
        }
        public bool isAlreadyGrouped
        {
            get;
            set;
        }
        public List<string> stemmedWords
        {
            get;
            set;
        }
        public string[] entity1Types
        {
            get;
            set;
        }
        public string[] entity2Types
        {
            get;
            set;
        }
        public override string ToString()
        {
            return sentence;
        }
    }
}
