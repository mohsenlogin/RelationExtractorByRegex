﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAnalyzer.Models
{
    public class PivotRegexLocation
    {
        public int startWordIndex
        {
            get;
            set;
        }
        public int endWordIndex
        {
            get;
            set;
        }
        public string pivot
        {
            get;
            set;
        }
    }
}
