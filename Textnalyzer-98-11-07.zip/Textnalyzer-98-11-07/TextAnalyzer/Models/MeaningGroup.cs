﻿using System.Collections.Generic;

namespace TextAnalyzer
{
    public class MeaningGroup
    {
        public List<string> Syns { get; set; } = new List<string>();
        public List<string> Acros { get; set; } = new List<string>();
    }
}