﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAnalyzer.Models
{
    public class RegexMatchResult
    {
        public RegexMatchResult()
        {
            regexes = new List<RegexContainer>();
        }
        public RegexTestResult TestResult
        {
            get;
            set;
        }
        public List<RegexContainer> regexes
        {
            get;
            set;
        }
        public TripleEntry entry
        {
            get;
            set;
        }
        public RegexTestResult calculateTestResult()
        {            
            if(regexes != null)
            {
                if (regexes.Count == 1)
                {
                    if (entry.relationType.Equals(regexes[0].relation.Replace("#", "")))
                    {                        
                        return TestResult = RegexTestResult.CORRECT;
                    }
                    else if(Constants.CONSIDER_E1_E2_AS_E2_E1 &&
                        regexes[0].relation.Replace("#", "").Substring(0, regexes[0].relation.Replace("#", "").IndexOf('(')).Equals(entry.relationType.Substring(0, entry.relationType.IndexOf('('))))
                    {
                        return TestResult = RegexTestResult.CORRECT;
                    }
                    else
                    {
                        return TestResult = RegexTestResult.MISMATCH;
                    }
                }
                else if(regexes.Count == 0)
                {
                    return TestResult = RegexTestResult.NO_MATCH;
                }
                else
                {
                    
                    List<RegexContainer> regexesWithDiffrentRelation = regexes.Where(r => !r.relation.Replace("#", "").Equals(entry.relationType)).ToList();
                    if (Constants.CONSIDER_E1_E2_AS_E2_E1)
                    {
                        regexesWithDiffrentRelation = regexesWithDiffrentRelation.Where(r => !r.relation.Replace("#", "").Substring(0,r.relation.Replace("#","").IndexOf('(')).Equals(entry.relationType.Substring(0,entry.relationType.IndexOf('(')))).ToList();
                    }
                    // if all match regexes have diffrent relation with sentence
                    if(regexesWithDiffrentRelation.Count() == regexes.Count)
                    {
                        return TestResult = RegexTestResult.MISMATCH;
                    }
                    
                    // else if at least one relation match between sentence and regexes exists
                    else if(regexesWithDiffrentRelation.Count() > 0)
                    {
                        return TestResult = RegexTestResult.MULTIPLE_MATCH;
                    }
                    // else there is no diffrence between match regexes and sentence relation, so all match regexes correspond to our sentence relation
                    else
                    {
                        return TestResult = RegexTestResult.CORRECT;
                    }
                }
            }
            return TestResult = RegexTestResult.NOT_AVAILABLE;
           
        }
        public override string ToString()
        {
            StringBuilder output =  new StringBuilder( string.Empty);
            if(regexes.Count == 1)
            {
                output.Append( (entry.relationType.Equals(regexes[0].relation.Replace("#","")) ? "CORRECT!" : "MIS DETECTED: "));
                output.Append(entry.sentence.Replace("<e1>","<e1:"+ entry.entity1+">").Replace("<e2>", "<e2:" + entry.entity1 + ">") +" TYPE<" +entry.relationType+ "> Detected as: " +regexes[0].relation + " Regex: "+ regexes[0].regex.ToString());
            }
            else if (regexes.Count == 0)
            {
                output.Append( "NO MATCH " +(entry != null ? entry.sentence.Replace("<e1>", "<e1:" + entry.entity1 + ">").Replace("<e2>", "<e2:" + entry.entity1 + ">") + " TYPE:<"+ entry.relationType+">" : string.Empty));
            }
            else
            {
                //output .Append( "Multiple MATCH: ");
                output .Append(entry.sentence.Replace("<e1>", "<e1:" + entry.entity1 + ">").Replace("<e2>", "<e2:" + entry.entity1 + ">") + " TYPE: <"+entry.relationType+"> Detected as following: ") ;
                foreach(RegexContainer r in regexes)
                {
                    output .Append( r.relation + " Regex: ");
                    output .Append( r.regex.ToString());
                }
            }
            return output.ToString();
        }
    }
    public enum RegexTestResult
    {
        CORRECT,
        MULTIPLE_MATCH,
        NO_MATCH,
        MISMATCH,
        NOT_AVAILABLE
    }
}
