﻿using System.Collections.Generic;

namespace TextAnalyzer.Models
{
    public class RelationStatistics
    {
        public string relation
        {
            get;
            set;
        }
        /// <summary>
        /// statistic of word frequencies for each group of similar sentences
        /// </summary>
        public List<List<WordFrequencyStatistics>> wordFrequencies
        {
            get;
            set;
        }
        // add list of trainEntry to preserve sentence info here for further analyze
        public List<TripleEntry> similarTrainEntries
        {
            get;
            set;
        }
        public List<TripleEntry> unsimilarTrainEntries
        {
            get;
            set;
        }
    }
}
