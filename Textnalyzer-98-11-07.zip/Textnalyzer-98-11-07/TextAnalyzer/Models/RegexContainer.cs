﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAnalyzer.Models
{
    public class RegexContainer:IEqualityComparer<RegexContainer>
    {
        public RegexContainer(string relation, RegularExpression regex)
        {
            if(!string.IsNullOrEmpty(relation) && !string.IsNullOrEmpty(regex.ToString()))
            {
                this.relation = relation;
                this.regex = regex;
            }            
        }
        public RegexContainer()
        {
                     
        }
        public string relation
        {
            get;
            set;
        }
        public RegularExpression regex
        {
            get;
            set;
        }
        public override string ToString()
        {
            return regex.ToString() + "-->" + relation;
        }
        public bool Equals(RegexContainer other)
        {
            return regex == other.regex;
        }
        public bool Equals(RegexContainer me,RegexContainer other)
        {
            return me.regex == other.regex;
        }
        public int GetHashCode(RegexContainer obj)
        {
            return obj.regex.GetHashCode();
        }
    }
}
