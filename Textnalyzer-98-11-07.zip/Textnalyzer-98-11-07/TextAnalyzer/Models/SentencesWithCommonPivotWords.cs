﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAnalyzer.Models
{
    public class SentencesWithCommonPivotWords
    {
        public SentencesWithCommonPivotWords()
        {
            this.trainEntries = new List<TripleEntry>();
            this.pivotWords = new List<PivotWordItem>();
        }
        public SentencesWithCommonPivotWords(List<TripleEntry> trainEntries, List<PivotWordItem> pivotWordItems)
        {
            this.trainEntries = trainEntries;
            this.pivotWords = pivotWordItems;
        }
        public List<TripleEntry> trainEntries
        {
            get;
            set;
        }
        public List<PivotWordItem> pivotWords
        {
            get;
            set;
        }
    }
}
