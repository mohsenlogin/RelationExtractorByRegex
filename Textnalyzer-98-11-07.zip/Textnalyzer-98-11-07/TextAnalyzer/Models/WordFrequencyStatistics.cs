﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TextAnalyzer.Models
{
    public class WordFrequencyStatistics
    {        
        public string word
        {
            get;
            set;
        }
        public int frequency
        {
            get;
            set;
        }

    }
}
