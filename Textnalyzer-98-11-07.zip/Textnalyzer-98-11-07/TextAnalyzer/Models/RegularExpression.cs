﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Re2.Net;

namespace TextAnalyzer.Models
{
    public class RegularExpression
    {
        public static string WORD_REGEX = "[آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی۰۱۲۳۴۵۶۷۸۹ ‬ًّ ‬َ ‬ِ ‬ُ ‬ْ A-Za-z0-9/<>]";
        public static string SPACE_REGEX = "\\s";
        public static string PUNCTUATIONS_REGEX = "[،؛,;'\":]";

        private string _regex = string.Empty;
        private Regex _compiledRegex = null;
        public RegularExpression()
        {
            pivotIndices = new List<int>();
            regexParts = new List<string>();
            coveringSentences = new List<TripleEntry>();
        }
        public Regex compiledRegex
        {
            get
            {
                string finalRegex = optimizeRegex(ToString(simplifiedVersion: false));
                if (!finalRegex.Equals("^" + RegularExpression.WORD_REGEX + "+$") &&
                            !finalRegex.Equals("^" + RegularExpression.WORD_REGEX + "*$"))
                {
                    return _compiledRegex != null ?_compiledRegex  :_compiledRegex = new Regex(finalRegex/*, RegexOptions.Compiled*/) ;//new Regex(finalRegex);//, RegexOptions.Compiled);// // 
                }
                return null;
            }
        }
        public RegularExpression(string regex)
        {
            if (!string.IsNullOrEmpty(regex))
            {
                this._regex = optimizeRegex(regex);
            }
            pivotIndices = new List<int>();
            regexParts = new List<string>();
            coveringSentences = new List<TripleEntry>();
        }
        public List<string> regexParts
        {
            get;
            set;
        }
        public List<TripleEntry> coveringSentences
        {
            get;
            set;
        }
        public RegularExpression makeOrClause(List<RegularExpression> sameWidthRegexes, PivotWord pivotWordsList, List<TripleEntry> coveringSentences)
        {
            RegularExpression finalRegex = new RegularExpression();
            
            if (sameWidthRegexes != null && sameWidthRegexes.Count > 0)
            {
                for (int clauseIndex = 0; clauseIndex < sameWidthRegexes[0].regexParts.Count; clauseIndex++)
                {
                    string currentClause = "";
                    for (int regexIndex = 0; regexIndex < sameWidthRegexes.Count; regexIndex++)
                    {
                        ///if (string.IsNullOrEmpty(sameWidthRegexes[regexIndex].regexParts[clauseIndex]))
                            /// continue;
                        if (regexIndex == 0)// clauseIndex == 0)
                        {
                            currentClause += "(";
                        }
                        string[] currentClauseParts = currentClause.Split('(', ')', '|');

                        //if (!currentClause.EndsWith(sameWidthRegexes[regexIndex].regexParts[clauseIndex]) &&
                        //    !currentClause.EndsWith(sameWidthRegexes[regexIndex].regexParts[clauseIndex]+"|"))
                        // ignore same regex parts in currentClause because OR operator will apply them 
                       
                        if(!currentClauseParts.Contains(sameWidthRegexes[regexIndex].regexParts[clauseIndex]) && (regexIndex == 0 ||
                            regexIndex > 0 && sameWidthRegexes[regexIndex-1].regexParts[clauseIndex] != sameWidthRegexes[regexIndex].regexParts[clauseIndex]))
                        {
                            if (!string.IsNullOrEmpty(currentClause) && (currentClause.Last() != '+' || currentClause.Last() != '*' || currentClause.Last() != ')' || currentClause.Last() != '(' ||
                                currentClause.Last() != '?' || currentClause.Last() != ')' ) && char.IsLetter(currentClause.Last()))
                            {
                                ///currentClause += " ";
                            }

                            currentClause += sameWidthRegexes[regexIndex].regexParts[clauseIndex];

                            //if(clauseIndex > 0 && sameWidthRegexes[regexIndex].regexParts[clauseIndex].Equals(sameWidthRegexes[regexIndex].regexParts[clauseIndex - 1])){
                            //    ;//jut to assert
                            //}

                            // check to see if this regex part is a pivot word, if so, add pivot word synonyms (if any)
                            if (pivotWordsList != null && sameWidthRegexes[regexIndex].regexParts[clauseIndex] != null && pivotWordsList.pivotWordItems.Count > 0)
                            {
                                PivotWordItem pivot;
                                foreach (List<PivotWordItem> pivotWordItem in pivotWordsList.pivotWordItems)
                                {
                                    pivot = pivotWordItem.Where(p => p.word.ToLower().Equals(sameWidthRegexes[regexIndex].regexParts[clauseIndex].Trim().ToLower())).SingleOrDefault();
                                    if (pivot != null  && pivot.synonyms != null/* && pivot.synonyms.Count > 0*/)
                                    {
                                        // remove duplicate synonyms (if any)
                                        //pivot.synonyms.RemoveAll(p => p.Equals(sameWidthRegexes[regexIndex].regexParts[clauseIndex]));
                                        
                                        foreach (string syn in pivot.synonyms)
                                        {
                                            currentClause += "|" + syn;
                                        }
                                    }
                                }
                            }                           
                        }
                        if (regexIndex > 0 && regexIndex == sameWidthRegexes.Count -1 )// clauseIndex == sameWidthRegexes[regexIndex].regexParts.Count - 1)
                        {
                            if(!string.IsNullOrEmpty(currentClause) && currentClause.First() != '(')
                            {
                                currentClause = '(' + currentClause;
                            }
                            currentClause += ")";
                        }
                        else if(!string.IsNullOrEmpty(currentClause) && !currentClause.Last().Equals('|'))
                        {
                            currentClause += "|";
                        }
                        if (currentClause.EndsWith("|)"))
                        {
                            currentClause = currentClause.Replace("|)",")");
                        }
                        if (currentClause.EndsWith("(|"))
                        {
                            currentClause = currentClause.Replace("(|", "(");
                        }
                        if (!currentClause.Contains("|"))
                        {
                            currentClause = currentClause.Replace("(", "").Replace(")", "");
                        }
                    }
                    currentClause = optimizeRegex(currentClause);
                    
                    finalRegex.regexParts.Add(currentClause);                   
                }
            }
            finalRegex.coveringSentences = coveringSentences;
            
            return finalRegex;
        }
        public static string optimizeRegex(string regex)
        {
            while (regex.Contains(RegularExpression.WORD_REGEX + "*" + "|" + RegularExpression.WORD_REGEX + "+") || regex.Contains(RegularExpression.WORD_REGEX + "+" + "|" + RegularExpression.WORD_REGEX + "*") ||
                        regex.Contains(RegularExpression.WORD_REGEX + "+" + "|" + RegularExpression.WORD_REGEX + "+") || 
                        regex.Contains(RegularExpression.WORD_REGEX + "*" + RegularExpression.WORD_REGEX + "*") ||
                        regex.Contains(RegularExpression.WORD_REGEX + "+" + RegularExpression.WORD_REGEX + "+") ||
                        regex.Contains("(" + WORD_REGEX + "*)") || regex.Contains("(" + WORD_REGEX + "+)"))
            {
                regex = regex.Replace("(" + WORD_REGEX + "*)", WORD_REGEX + "*").Replace("(" + WORD_REGEX + "+)", WORD_REGEX + "+").Replace(RegularExpression.WORD_REGEX + "*" + "|" + RegularExpression.WORD_REGEX + "+", RegularExpression.WORD_REGEX + "*").
                    Replace(RegularExpression.WORD_REGEX + "+" + "|" + RegularExpression.WORD_REGEX + "*", RegularExpression.WORD_REGEX + "*").
                    Replace(RegularExpression.WORD_REGEX + "+" + "|" + RegularExpression.WORD_REGEX + "+", RegularExpression.WORD_REGEX + "+").
                    Replace(RegularExpression.WORD_REGEX + "+" + RegularExpression.WORD_REGEX + "+", RegularExpression.WORD_REGEX + "+").
                    Replace(RegularExpression.WORD_REGEX + "*" + RegularExpression.WORD_REGEX + "*", RegularExpression.WORD_REGEX + "*");
            }
            return regex;
        }
        public string makeOrClause(List<string> clauses)
        {
            StringBuilder finalClause = new StringBuilder( "");
            for( int clauseIndex = 0; clauseIndex < clauses.Count; clauseIndex++)
            {
                if (clauses[clauseIndex].Equals("\\x"))
                    continue;
                if(clauseIndex == 0)
                {
                    finalClause.Append("(");
                }
                finalClause.Append( clauses[clauseIndex]);
                if(clauseIndex == clauses.Count - 1)
                {
                    finalClause.Append( ")");
                }
                else
                {
                    finalClause.Append("|");
                }
            }
            return finalClause.ToString();
        }
        
        public List<int> pivotIndices
        {
            get;
            set;
        }
        public static bool IsValidRegex(string pattern)
        {
            if (string.IsNullOrEmpty(pattern)) return false;

            try
            {
                Regex.Match("", pattern);
            }
            catch (ArgumentException)
            {
                return false;
            }

            return true;
        }
        public static Dictionary<int,string> findRegexErrorInfo(string input, string pattern)
        {
            Match match = Re2.Net.Regex.Match(input,pattern);
            Dictionary<int, string> errorInfo = new Dictionary<int, string>();
            for (int groupIndex = 0; groupIndex < match.Groups.Count; groupIndex++)
            {
                if (!match.Groups[groupIndex].Success)
                {
                    errorInfo.Add(match.Groups[groupIndex].Index, match.Groups[groupIndex].Value);
                }
            }
            return errorInfo;
        }
        
        public override string ToString()
        {
            if (string.IsNullOrEmpty(_regex))
            {
                StringBuilder finalRegex = new StringBuilder("^");                
                for (int partIndex = 0; partIndex < regexParts.Count; partIndex++)
                {
                    //if (partIndex > 0)
                    // {
                    //    if ( !(regexParts[partIndex - 1].Equals("w*") && regexParts[partIndex].Equals("w*")))
                    // {
                    finalRegex.Append(regexParts[partIndex]);
                                   
                    finalRegex = finalRegex.Replace(RegularExpression.WORD_REGEX + "*" + "|"+ RegularExpression.WORD_REGEX + "*", RegularExpression.WORD_REGEX + "*").
                        Replace("("+ RegularExpression.WORD_REGEX + "*" + "|"+ RegularExpression.WORD_REGEX + "*" + ")", RegularExpression.WORD_REGEX + "*").
                        Replace("("+ RegularExpression.WORD_REGEX + "*" + ")", RegularExpression.WORD_REGEX + "*").
                        Replace(RegularExpression.WORD_REGEX + "*"+ RegularExpression.WORD_REGEX + "*", RegularExpression.WORD_REGEX + "*").
                        Replace("()", "").Replace(RegularExpression.WORD_REGEX + "+"+RegularExpression.WORD_REGEX + "*", RegularExpression.WORD_REGEX + "+").
                        Replace(RegularExpression.WORD_REGEX + "*"+ RegularExpression.WORD_REGEX + "+", RegularExpression.WORD_REGEX + "+").
                        Replace(RegularExpression.WORD_REGEX + "+"+ RegularExpression.WORD_REGEX + "+", RegularExpression.WORD_REGEX + "+").
                        Replace(RegularExpression.WORD_REGEX + "+" + "|"+ RegularExpression.WORD_REGEX + "*", RegularExpression.WORD_REGEX + "*").
                        Replace(RegularExpression.WORD_REGEX + "*" + "|"+ RegularExpression.WORD_REGEX + "+", RegularExpression.WORD_REGEX + "*").Replace("(|", "(");
                    //  }
                    //}
                    //else
                    //{
                    //    finalRegex += regexParts[partIndex];
                    //}
                }
                finalRegex.Append ("$");
                return optimizeRegex(finalRegex.ToString().Trim()).Replace(WORD_REGEX, "w");//.ToString();
            }
            else
            {
                return optimizeRegex( _regex).Replace(WORD_REGEX, "w");
            }
        }

        public string ToString(bool simplifiedVersion)
        {
            return ToString().Replace("w",WORD_REGEX);
        }
    }
}
