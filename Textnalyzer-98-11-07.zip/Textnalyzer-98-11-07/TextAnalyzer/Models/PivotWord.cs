﻿using System;
using System.Collections.Generic;

namespace TextAnalyzer.Models
{
    public class PivotWord
    {
        public PivotWord()
        {
            pivotWordItems = new List<List<PivotWordItem>>();
        }
        public string relation
        {
            get;
            set;
        }
        public List<List<PivotWordItem>> pivotWordItems
        {
            get;
            set;
        }
    }
}
