﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TextAnalyzer.Models;
using System.Web.Script.Serialization;
using System.IO;
using Re2.Net;
using Stemming.Persian;

namespace TextAnalyzer
{
    public partial class frmDefinePivotWords : Form
    {
        Stemmer persianStemmer;
        public frmDefinePivotWords()
        {
            InitializeComponent();
            loadPivotWords();
            persianStemmer = new Stemmer();
        }
        private string selectedRelation
        {
            get;
            set;
        }
        public void ShowDialog(string selectedRelation)
        {
            lblSelectedRelation.Text = "Selected Relation: "+ selectedRelation;
            this.Text = "Define Potential Sentences for relation: " + selectedRelation;
            this.selectedRelation = selectedRelation;
            loadPivotWords();
            this.ShowDialog();
        }
        private void loadPivotWords()
        {
            try
            {
                string pivotWordsJson = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PivotWords.js"));                
                Constants.pivotWords = new JavaScriptSerializer().Deserialize<List<PivotWord>>(pivotWordsJson);
                PivotWord pivotWord = Constants.pivotWords.Where(p => p.relation == selectedRelation).SingleOrDefault();
                lvPotentialSemiRegexes.Items.Clear();
                if(pivotWord != null)
                {
                    for (int counter = 0; counter < pivotWord.pivotWordItems.Count; counter++)
                    {
                        lvPotentialSemiRegexes.Items.Add("Sentence " + (counter+1));                        
                    }
                    
                }
                
            }
            catch(FileNotFoundException fnfex)
            {
                // ignore
            }
            catch(IOException ioex)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw;
            }
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            var pivotWordsJson = new JavaScriptSerializer().Serialize(Constants.pivotWords);
            File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PivotWords.js"), pivotWordsJson,Encoding.UTF8);
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtWord.Text))
            {
                txtWord.Text = txtWord.Text.Replace(" ", "\\s");
                try
                {
                    Regex.Match("", txtWord.Text);
                }
                catch (ArgumentException ae)
                {
                    MessageBox.Show("Error in Regex, Details: \n" + ae.Message);
                    return;
                }
                if (!string.IsNullOrEmpty(txtWeight.Text))
                {
                    if(float.Parse(txtWeight.Text) > 1.0)
                    {
                        MessageBox.Show("وزن نباید بیش از 1 باشد. مقدار وزن به 1 بازنشانی شد");
                        txtWeight.Text = "1.0";
                    }
                }
                lvPivotWords.Items.Add(new ListViewItem( new[] { txtWord.Text, (!string.IsNullOrEmpty( txtWeight.Text ) ? txtWeight.Text : "1.0") } ));
                                
                PivotWord pivotWord = Constants.pivotWords.Where(pw => pw.relation == selectedRelation).SingleOrDefault();

                bool addToList = false;
                if (pivotWord == null)
                {
                    pivotWord = new PivotWord();
                    pivotWord.relation = selectedRelation;
                    addToList = true;                 
                }
                PivotWordItem pivotWordItem = new PivotWordItem();
                pivotWordItem.word = txtWord.Text;
                pivotWordItem.weight = float.Parse(txtWeight.Text);
                if(pivotWord.pivotWordItems.Count <= lvPotentialSemiRegexes.Items.Count ) //< to <=
                {
                    pivotWord.pivotWordItems.Add(new List<PivotWordItem>());
                }
                pivotWord.pivotWordItems[ lvPotentialSemiRegexes.Items.Count - 1 ].Add(pivotWordItem);

                if (addToList)
                {
                    Constants.pivotWords.Add(pivotWord);
                }
                txtWord.Text = "";             

            }
            else
            {
                MessageBox.Show("کلمه را تایپ نکرده اید");
            }
        }

        
        private void lvPivotWords_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnRemove.Enabled = true;
            txtWord.Text = lvPivotWords.SelectedItems[0].Text;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            PivotWord pivotWord = Constants.pivotWords.Where(p => p.relation == selectedRelation).SingleOrDefault();
            if (pivotWord != null)
            {
                pivotWord.pivotWordItems[lvPotentialSemiRegexes.SelectedIndices[0]].RemoveAt(lvPivotWords.SelectedIndices[0]);
            }
            lvPivotWords.SelectedItems[0].Remove();
            btnRemove.Enabled = false;
        }

        private void btnAddSentence_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSemiRegex.Text))
            {                
                lvPotentialSemiRegexes.Items.Add(new ListViewItem(new[] { txtSemiRegex.Text }));
                txtSemiRegex.Text = "Sentence " + (lvPotentialSemiRegexes.Items.Count + 1);
                txtWord.Focus();

            }
            else
            {
                MessageBox.Show("Type Sentence Name");
            }
        }

        private void lvPotentialSemiRegexes_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnRemoveSentence.Enabled = true;
            gbPivotWords.Enabled = true;
            if (lvPotentialSemiRegexes.SelectedItems.Count == 0)
            {
                gbPivotWords.Enabled = false;
            }
            else
            {
                lvPivotWords.Items.Clear();
                PivotWord pivotWord = Constants.pivotWords.Where(p => p.relation == selectedRelation).SingleOrDefault();

                if (pivotWord != null && lvPotentialSemiRegexes.SelectedIndices[0] < pivotWord.pivotWordItems.Count)
                {
                    for (int i = 0; i < pivotWord.pivotWordItems[lvPotentialSemiRegexes.SelectedIndices[0]].Count; i++)
                    {
                        lvPivotWords.Items.Add(new ListViewItem(new string[] { pivotWord.pivotWordItems[lvPotentialSemiRegexes.SelectedIndices[0]][i].word,
                        pivotWord.pivotWordItems[lvPotentialSemiRegexes.SelectedIndices[0]][i].weight.ToString()}));
                    }
                }
            }
            
        }

        private void btnRemoveSentence_Click(object sender, EventArgs e)
        {
            
            btnRemoveSentence.Enabled = false;
            PivotWord pivotWord = Constants.pivotWords.Where(p => p.relation == selectedRelation).SingleOrDefault();
            if(pivotWord != null && lvPotentialSemiRegexes.SelectedIndices[0] < pivotWord.pivotWordItems.Count)
            {
                pivotWord.pivotWordItems.RemoveAt(lvPotentialSemiRegexes.SelectedIndices[0]);
            }
            lvPotentialSemiRegexes.SelectedItems[0].Remove();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmDefinePivotWords_Load(object sender, EventArgs e)
        {

        }

        private void btnSynonyms_Click(object sender, EventArgs e)
        {
            if (selectedRelation != null && lvPotentialSemiRegexes.SelectedIndices.Count > 0 && lvPivotWords.SelectedIndices.Count > 0)
            {
                PivotWord pivotWord = Constants.pivotWords.Where(p => p.relation == selectedRelation).SingleOrDefault();
                PivotWordItem selectedPivotWordItem = pivotWord.pivotWordItems[lvPotentialSemiRegexes.SelectedIndices[0]][lvPivotWords.SelectedIndices[0]];
                new DefinePivotWordSynonyms().showDialog(ref selectedPivotWordItem);
            }
            else
            {
                MessageBox.Show(this, "Hey Buddy! Select a Potential Sentence and Pivot Word First!", "Nothing Selected",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtWordToStem_TextChanged(object sender, EventArgs e)
        {
            try
            {
                lblRoot.Text = persianStemmer.run(txtWordToStem.Text);
            }
            catch(NullReferenceException nre)
            {
                // ignore
            }
            
        }
        private ArgumentException lastRegexException;
        private void txtWord_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Regex.Match("", txtWord.Text);
                if(txtWord.Text!= string.Empty)
                    txtWord.BackColor = Color.Green;
            }
            catch (ArgumentException ae)
            {
                lastRegexException = ae;
                
                txtWord.BackColor = Color.Red;
            }
        }
    }
}
