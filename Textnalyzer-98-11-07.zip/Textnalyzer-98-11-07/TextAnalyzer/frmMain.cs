﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Web.Script.Serialization;
using TextAnalyzer.Controllers;
using TextAnalyzer.Models;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Text;

namespace TextAnalyzer
{
    public partial class frmMain : Form
    {
        private string trainingContent = null;
        private string testContent = null;
        private List<List<RelationStatistics>> relationStatistics = null;
        private List<TripleEntry> trainEntries;
        private List<TripleEntry> testEntries;
        private List<RegexContainer> regexes = new List<RegexContainer>();
        private List<RegexContainer> simplifiedRegexes = new List<RegexContainer>();
        private Color normalBackColor;
        public frmMain()
        {
            InitializeComponent();
            normalBackColor = btnLogger.BackColor;
            //if(Constants.prepositions.Count() > 0)
            //{
            //    txtPrepositions.Text = "";
            //    foreach(var prep in Constants.prepositions)
            //    {
            //        txtPrepositions.Text += prep.Trim() + " ";
            //    }                
            //}
            cmbLanguage.SelectedItem = (Constants.CURRENT_LANGUAGE == "fa"?"Persian":"English");
            Constants.STEM_WORDS = chkStemWords.Checked;
            
           
        }
      
        private void btnOpenTrainFile_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            trainingContent = null;
            lblMessage.ForeColor = Color.Black;
            if (ofdOpenTrainFile.ShowDialog() == DialogResult.OK)
            {                
                //try
                {
                    if(Path.GetExtension(ofdOpenTrainFile.FileName).ToLower().Equals("js") || Path.GetExtension(ofdOpenTrainFile.FileName).ToLower().Equals(".json"))
                    {
                        trainEntries = parser.parse(ofdOpenTrainFile.FileName, true, out testEntries, cuttoff:-1);
                        btnApplyRegexes.Enabled = true;
                    }
                    else if ((trainingContent = File.ReadAllText(ofdOpenTrainFile.FileName)) != null)
                    {                        
                        trainEntries = parser.parse(trainingContent);
                        if(testEntries != null)
                            testEntries.Clear();                      
                    }
                    lblMessage.ForeColor = Color.Green;
                   
                    btnAnalyze.Enabled = true;
                    btnDefinePivotWords.Enabled = true;
                    List<string> relationTypes = trainEntries.GroupBy(te => te.relationType).Select(g => g.First()).OrderBy(x => x.relationType).Select(r => r.relationType).ToList();
                     lblMessage.Text = "Train File Loaded Succesfully. ("+trainEntries.Count+" Train Entries & "+(testEntries!= null? testEntries.Count + " Test Entries, ":",")+relationTypes.Count+ " Relation Types)";
                    lstAnnotators.Items.Clear();
                    relationTypes.Remove("other");
                    lstAnnotators.Items.AddRange(relationTypes.ToArray());
                }
                //catch (Exception ex)
                //{
                //    lblMessage.ForeColor = Color.Red;
                //    lblMessage.Text = "خطا " + ex.Message;
                //    btnAnalyze.Enabled = false;
                //}
            }
        }

        private async void btnAnalyze_Click(object sender, EventArgs e)
        {            
            tcMain.Enabled = false;
            lblMessage.Text = "Learning...";
            btnAnalyze.Text = "3- Learning...";
            Constants.LOG = "";
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Restart();
            //bool x = await Task.Run(doAnalyze);
            doAnalyze();
            tcMain.Enabled = true;
            lsRegexes.Items.Clear();
            lsSimilarSentencesRegex.Items.Clear();
            // keep an unchanged copy of regexes, because we may change and simplify regexes display
            simplifiedRegexes = new List<RegexContainer>(regexes);
            if (simplifiedRegexes != null && simplifiedRegexes.Count > 0)
            {
                foreach (RegexContainer regex in simplifiedRegexes.Where(r => !r.relation.Contains("#")))
                {
                    lsRegexes.Items.Add(regex);
                }
                foreach (RegexContainer similarSentencesRegex in simplifiedRegexes.Where(r => r.relation.Contains("#")))
                {
                    lsSimilarSentencesRegex.Items.Add(similarSentencesRegex);
                }
                lblMessage.Text = "Done. Total Regex Learned: " + simplifiedRegexes.Count;
                btnAnalyze.Text = "3- Learn";
                if(!string.IsNullOrEmpty(Constants.LOG))
                {
                    btnLogger.BackColor = Color.Orange;
                }
                else
                {
                    btnLogger.BackColor = normalBackColor;
                }
            }
            stopwatch.Stop();
            lblMessage.Text += " Elapsed Time: " + (stopwatch.ElapsedMilliseconds/1000).ToString() + " sec.";
        }
        private /*async Task<bool>*/bool doAnalyze()
        {
            Constants.MIN_REPEAT_TRESHOULD = nudMinSubstringOccourance.Value;
            Constants.STEM_WORDS = chkStemWords.Checked;
            Constants.IGNORE_PREPOSITIONS = chkIgnorePrepositions.Checked;
            Constants.COMMON_WORDS_SCORE = (int)nudCommonWordsQualifiedScore.Value;
            Constants.MAX_NON_SAME_WORDS_PERCENT = (int)nudMaxNonSameWords.Value;
            Constants.MAX_SENTENCE_LENGTH_DIFFRENCE_PERCENT = (int)nudMaxSentenceLengthDiff.Value;
            Constants.MAX_SENTENCE_WORD_COUNT_DIFFRENCE = (int)nudMaxSentenceWordCountDiff.Value;
            Constants.MIN_COMMON_WORDS_PERCENT = (int)nudMinCommonWords.Value;
            Constants.NON_SAME_WORDS_QUALIFIED_SCORE = (int)nudNonSameWordsQualified.Value;
            Constants.SENTENCE_LENGTH_QUALIFIED_SCORE = (int)nudSentenceLengthQualifiedScore.Value;
            Constants.SENTENCE_WORD_COUNT_QUALIFIED_SCORE = (int)nudSentenceWordCountQualifiedScore.Value;
            Constants.USE_SYSNONYMS = chkUseSynonyms.Checked;
            Constants.MAX_SYNONYMS_COUNT = (int)nudMaxSynonyms.Value;
            Constants.MIN_SIMILARITY_PERCENT = (int)nudMinSimilarityPercent.Value;
            Constants.RIGHT_TO_LEFT_LAYOUT = chkRightToLeftLayout.Checked;
            Constants.LEARN_ENTITIES_ITSELF_AS_REGEX = chkExactMatchOfEntities.Checked;
            Constants.GENERATE_LOW_FREQUENCY_REGEXES = chkLowFreqRegexGenerate.Checked;
            regexes = new List<RegexContainer>();

            try
            {
                string pivotWordsJson = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PivotWords.js"));
                Constants.pivotWords = new JavaScriptSerializer().Deserialize<List<PivotWord>>(pivotWordsJson);
            }
            catch (FileNotFoundException fnfex)
            {
                // ignore
            }
            catch (IOException ioex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
            if (!string.IsNullOrEmpty(txtPrepositions.Text))
            {
                Constants.prepositions = txtPrepositions.Text.Split(' ');
            }
            if (trainEntries == null)
            {
                lblMessage.ForeColor = Color.Red;
                lblMessage.Text = "هنوز داده Train بارگذاری نشده است";
                return true;
            }

            relationStatistics = new Analyzer().analyze(trainEntries, chkStemWords.Checked, chkIgnorePrepositions.Checked, ref regexes);            
            
            return true;
        }
        private void lstAnnotators_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            lsRegexes.Text = "";
            lstStats.Items.Clear();
            if (relationStatistics != null)
            {
                List<RelationStatistics> stats = null;
                for (int i = 0; i < relationStatistics.Count; i++)
                {
                    stats = relationStatistics[i].Where(r=>r.relation == lstAnnotators.GetItemText(lstAnnotators.SelectedItem)).Select(x=>x).ToList();
                    if (stats.Count > 0) break;
                }
                ///RelationStatistics statistics = relationStatistics.Where(s => s.relation == lstAnnotators.GetItemText(lstAnnotators.SelectedItem)).SingleOrDefault();
                if (stats != null)
                {
                    string semiRegex = "";
                    foreach (RelationStatistics statistics in stats)
                    {
                        foreach (List<WordFrequencyStatistics> eachSimilarSentenceStats in statistics.wordFrequencies)
                        {
                            string text = "";
                            foreach (WordFrequencyStatistics s in eachSimilarSentenceStats.OrderByDescending(st => st.frequency))//.wordFrequencies.OrderByDescending(st => st.frequency))
                            {

                                if (s.frequency <= Constants.MAX_REPEAT_TRESHOULD && s.frequency >= Constants.MIN_REPEAT_TRESHOULD)
                                {

                                    text += s.word + "(" + s.frequency + ") ";
                                }

                            }
                            lstStats.Items.Add(text);
                        }
                    }
                }
            }
            else
            {
                lblMessage.Text = "لطفاً ابتدا دکمه تجزیه و تحلیل را کلیک نمایید.";
            }
        }

        private void nudMinSubstringOccourance_ValueChanged(object sender, EventArgs e)
        {
            Constants.MIN_REPEAT_TRESHOULD = nudMinSubstringOccourance.Value;
            lstAnnotators_SelectedIndexChanged(sender, e);
        }

        private void lblRelations_Click(object sender, EventArgs e)
        {

        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void nudMaxWordOccourance_ValueChanged(object sender, EventArgs e)
        {
            Constants.MAX_REPEAT_TRESHOULD = nudMaxWordOccourance.Value;
            lstAnnotators_SelectedIndexChanged(sender, e);
        }

        private void chkIgnorePrepositions_CheckedChanged(object sender, EventArgs e)
        {
            txtPrepositions.Enabled = chkIgnorePrepositions.Checked;
        }

        private void btnDefinePivotWords_Click(object sender, EventArgs e)
        {
            if (lstAnnotators.SelectedItem != null) {
                new frmDefinePivotWords().ShowDialog(lstAnnotators.GetItemText(lstAnnotators.SelectedItem));
            }
            
            else
            {
                MessageBox.Show("لطفا یک رابطه را برای تعریف جملات بالقوه ی آن جهت تولید رجکس انتخاب نمایید.");
            }
        }

        private void chkRightToLeftLayout_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRightToLeftLayout.Checked)
                this.RightToLeft = RightToLeft.Yes;
            else
                this.RightToLeft = RightToLeft.No;
            this.RightToLeftLayout = chkRightToLeftLayout.Checked;
            lsRegexes.RightToLeft = (chkRightToLeftLayout.Checked ? RightToLeft.Yes : RightToLeft.No);
            lstStats.RightToLeft = (chkRightToLeftLayout.Checked ? RightToLeft.Yes : RightToLeft.No);
            lsSimilarSentencesRegex.RightToLeft = (chkRightToLeftLayout.Checked ? RightToLeft.Yes : RightToLeft.No);
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void lblMessage_Click(object sender, EventArgs e)
        {
            Database.Instance().loadSynonymsLibrary();
        }

        private void btnSaveRegexes_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfdRegex = new SaveFileDialog();
            lblMessage.Text = "";
            trainingContent = null;
            lblMessage.ForeColor = Color.Black;
            if (sfdRegex.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(sfdRegex.FileName, new JavaScriptSerializer().Serialize(regexes));                
                lblMessage.ForeColor = Color.Green;
                lblMessage.Text = "ذخیره فایل انجام شد";
                
            }
        }

        private void chkMaxSynonyms_CheckedChanged(object sender, EventArgs e)
        {
            nudMaxSynonyms.Enabled = chkMaxSynonyms.Checked;
        }

        private void btnResetParametersToDefaults_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure You Want to Reset Parameters to Defaults?", "Sure?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                nudCommonWordsQualifiedScore.Value = 26;
                nudMaxNonSameWords.Value = 18;
                nudMaxSentenceLengthDiff.Value = 20;
                nudMaxSentenceWordCountDiff.Value = 4;
                nudMaxSynonyms.Value = 3;
                nudMaxWordOccourance.Value = 10000;
                nudMinCommonWords.Value = 65;
                nudMinSimilarityPercent.Value = 60;
                nudMinSubstringOccourance.Value = 30;
                nudNonSameWordsQualified.Value = 18;
                nudSentenceLengthQualifiedScore.Value = 23;
                nudSentenceWordCountQualifiedScore.Value = 25;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure You Want to Exit?", "Sure?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void Click(object sender, EventArgs e)
        {

        }
        private void btnLoadTestFile_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            testContent = null;
            lblMessage.ForeColor = Color.Black;
            ofdOpenTrainFile.Title = "Open Test File";
            if (ofdOpenTrainFile.ShowDialog() == DialogResult.OK)
            {

                //try
                {
                    if ((testContent = File.ReadAllText(ofdOpenTrainFile.FileName)) != null)
                    {
                        lblMessage.ForeColor = Color.Green;
                        lblMessage.Text = "Test File Loaded Succesfully";
                        
                        Parser parser = new Parser();
                        testEntries = parser.parse(testContent,"\n\n");
                        testEntries = testEntries.Except(testEntries.Where(te => te.relationType.ToLower().Equals("other"))).ToList();
                        lblTotalTestEntryCount.Text = testEntries.Count.ToString();
                        string[] relationTypes = testEntries.GroupBy(te => te.relationType).Select(g => g.First()).OrderBy(x => x.relationType).Select(r => r.relationType).ToArray();
                        lsRealRelations.Items.Clear();
                        lsRealRelations.Items.AddRange(relationTypes);
                        btnApplyRegexes.Enabled = true;
                        btnLoadOtherLearnedRegexes.Enabled = !chkUseCurrentLearnedRegexes.Checked;
                    }
                }
                //catch (Exception ex)
                //{
                //    lblMessage.ForeColor = Color.Red;
                //    lblMessage.Text ="خطا " + ex.Message;
                //    btnAnalyze.Enabled = false;
                //}
            }
        }

        private void lsSimilarSentencesRegex_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnRegexDetails_Click(object sender, EventArgs e)
        {
            if(lsSimilarSentencesRegex.SelectedIndices[0] > -1)
            {
                new frmRegexDetails().showDialog((RegexContainer)lsSimilarSentencesRegex.SelectedItem);
            }            
        }
        private void chkSimpleRegexView_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSimpleRegexView.Checked)
            {
                //lsSimilarSentencesRegex.Items.Clear();
                List<RegexContainer> regs = new List<RegexContainer>();
                foreach (var regexContainer in simplifiedRegexes)
                {
                    RegexContainer r = (RegexContainer)regexContainer;
                    r.regex = new RegularExpression( r.regex.ToString().Replace(RegularExpression.WORD_REGEX, "w"));
                    //lsSimilarSentencesRegex.Items.Add(r);
                    regs.Add(r);
                }
                lsSimilarSentencesRegex.Items.Clear();
                lsSimilarSentencesRegex.Items.AddRange(regs.ToArray());
                lsSimilarSentencesRegex.Refresh();
            }
            else
            {
                lsSimilarSentencesRegex.Items.Clear();
                lsSimilarSentencesRegex.Items.AddRange(regexes.Where(r => r.relation.Contains("#")).ToArray());
                lsSimilarSentencesRegex.Refresh();                
            }
        }

        private void chkUseCurrentLearnedRegexes_CheckedChanged(object sender, EventArgs e)
        {
            btnLoadOtherLearnedRegexes.Enabled = !chkUseCurrentLearnedRegexes.Checked;
        }
        Parser parser = new Parser();
        List<RegexMatchResult> regexMatchResults;
        private void btnApplyRegexes_Click(object sender, EventArgs e)
        {
            Constants.CONSIDER_E1_E2_AS_E2_E1 = chkConsiderE2E1SameAsE1E2.Checked;
            tcMain.Enabled = false;
            lblMessage.Text = "Evaluating...";
            btnApplyRegexes.Text = "Evaluating...";
            Constants.LOG = "";
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Restart();
            if (regexes != null && regexes.Count > 0)
            {
                if(testEntries != null && testEntries.Count > 0)
                {
                    lblTotalTestEntryCount.Text = testEntries.Count.ToString();
                    List<RegexContainer> validRegexes = new List<RegexContainer>();
                    // separate invalid regexes (if any) and warn them to user
                    foreach(RegexContainer regexContainer in regexes)
                    {
                        /*if (/*RegularExpression.IsValidRegex(regexContainer.regex.ToString(simplifiedVersion: false)) && *//*
                            !RegularExpression.optimizeRegex(regexContainer.regex.ToString(simplifiedVersion:false)).Equals("^"+RegularExpression.WORD_REGEX+"+$") &&
                            !RegularExpression.optimizeRegex(regexContainer.regex.ToString(simplifiedVersion:false)).Equals("^"+RegularExpression.WORD_REGEX+"*$"))
                        {
                            validRegexes.Add(regexContainer);
                        }*/
                        if (regexContainer.regex.compiledRegex != null)
                        {
                            validRegexes.Add(regexContainer);
                        }
                    }
                    // may want to display invalid regexes here 
                    // now apply all valid regexes to each sentence
                    regexMatchResults = new List<RegexMatchResult>();

                    /// new
                    /*
                    foreach (RegexContainer regex in validRegexes)
                    {
                        Regex currentRegex = regex.regex.compiledRegex;
                        
                        foreach (TrainEntry testSentence in testEntries)
                        {
                            if (testSentence.relationType != "other")
                            {
                                if (Constants.STEM_WORDS)
                                {
                                    testSentence.sentence = parser.doStemming(testSentence.sentence, Constants.CURRENT_LANGUAGE);
                                }
                                RegexMatchResult matchResult = new RegexMatchResult();
                                matchResult.entry = testSentence;
                                if (currentRegex.IsMatch(testSentence.sentence))
                                {
                                    matchResult.regexes.Add(regex);
                                }
                            }
                    ///end new*/
                    foreach (TripleEntry testSentence in testEntries)
                    {
                        if (testSentence.relationType != "other")
                        {
                            if (Constants.STEM_WORDS)
                            {
                                testSentence.sentence = parser.doStemming(testSentence.sentence, Constants.CURRENT_LANGUAGE);
                            }
                            RegexMatchResult matchResult = new RegexMatchResult();
                            foreach (RegexContainer regex in validRegexes)
                            {
                                matchResult.entry = testSentence;
                                //if (Regex.IsMatch(testSentence.sentence, regex.regex.ToString(simplifiedVersion: false)))
                                if (regex.regex.compiledRegex.IsMatch(testSentence.sentence))
                                { 
                                    matchResult.regexes.Add(regex);                                    
                                }
                            }
                            regexMatchResults.Add(matchResult);
                        }
                    }
                    measureResults(regexMatchResults);                    
                }
                else
                {
                    MessageBox.Show("Please Load Test Entries first.","Test Entries not found");
                }
            }
            else
            {
                MessageBox.Show("No Learned Regexes Found. Please first train some sentences by Pressing Analyze Button fisrt.");
            }
            tcMain.Enabled = true;
            stopwatch.Stop();
            
            lblMessage.Text = "Evaluation Done." + simplifiedRegexes.Count + " Elapsed Time: " + (stopwatch.ElapsedMilliseconds/1000).ToString() +" sec.";
            btnApplyRegexes.Text = "Evaluate";
           
            if (!string.IsNullOrEmpty(Constants.LOG))
            {
                btnLogger.BackColor = Color.Orange;
            }
            else
            {
                btnLogger.BackColor = normalBackColor;
            }
        }
        List<TripleEntry> trulyDetectedInfo = null;
        private void measureResults( List<RegexMatchResult> regexMatchResults)
        {
            foreach(RegexMatchResult matchResult in regexMatchResults)
            {
                matchResult.calculateTestResult();
            }
            List<RegexMatchResult> result = regexMatchResults.Where(matchResult => matchResult.TestResult == RegexTestResult.CORRECT).ToList();
            trulyDetectedInfo = result.Select(r => r.entry).ToList();
            lblCorrectDetectionsCount.Text = result.Count.ToString();
            int truePositive = result.Count;
            lbCorrectDetected.Items.Clear();
            lbCorrectDetected.Items.AddRange(result.OrderBy(x => x.entry.relationType).ToArray());
            // maybe use list items to display separatly in diffrent tab, etc.

            result = regexMatchResults.Where(matchResult => matchResult.TestResult == RegexTestResult.MISMATCH).ToList();
            lblMisMatchCount.Text = result.Count.ToString();
            int falsePositive = result.Count;
            lbMisMatches.Items.Clear();
            lbMisMatches.Items.AddRange(result.OrderBy(x => x.entry.relationType).ToArray());

            result = regexMatchResults.Where(matchResult => matchResult.TestResult == RegexTestResult.MULTIPLE_MATCH).ToList();
            
            lblMultipleMatchCount.Text = result.Count.ToString();
            if (chkTreatMultipleMatchAsCorrect.Checked)
            {
                truePositive += result.Count;
                trulyDetectedInfo.Union(result.Select(r => r.entry));
            }
            else
            {
                falsePositive += result.Count;
            }
            lbMultipleMatches.Items.Clear();
            lbMultipleMatches.Items.AddRange(result.OrderBy(x => x.entry.relationType).ToArray());



            result = regexMatchResults.Where(matchResult => matchResult.TestResult == RegexTestResult.NO_MATCH).ToList();
            int falseNegative =testEntries.Count - (truePositive+falsePositive); //result.Count;
            lblUnmatchCount.Text = falseNegative.ToString();// result.Count.ToString();
            
            lbNoMatches.Items.Clear();            
            lbNoMatches.Items.AddRange(result.OrderBy(x=>x.entry.relationType).Select(u=>u.entry.sentence+" TYPE: <"+u.entry.relationType+">").ToArray());
            lblPrecision.Text = truePositive + falsePositive != 0 ? (truePositive * 100 / (truePositive + falsePositive)).ToString() + "%" : "N/A";

            lblRecal.Text = truePositive + falseNegative != 0 ? (truePositive * 100 / (truePositive + falseNegative)).ToString() + "%" : "N/A";

            lsOutput.Items.Clear();
            // finally display fine matched results 
            lsOutput.Items.AddRange(regexMatchResults.ToArray());
        }
        private void btnLogger_Click(object sender, EventArgs e)
        {           
             MessageBox.Show(string.IsNullOrEmpty(Constants.LOG)?"No Error Log":Constants.LOG, "Error Logger");             
        }

        private void lblMisMatchCount_Click(object sender, EventArgs e)
        {

        }

        private void chkTreatMultipleMatchAsCorrect_CheckedChanged(object sender, EventArgs e)
        {
            if (regexMatchResults != null)
            {
                measureResults(regexMatchResults);
            }           
        }

        private void chkConsiderE2E1SameAsE1E2_CheckedChanged(object sender, EventArgs e)
        {
            Constants.CONSIDER_E1_E2_AS_E2_E1 = chkConsiderE2E1SameAsE1E2.Checked;
            if (regexMatchResults != null)
            {
                measureResults(regexMatchResults);
            }
        }

        private void chkLowFreqRegexGenerate_CheckedChanged(object sender, EventArgs e)
        {
            tabLowFreqRegexes.Visible = chkLowFreqRegexGenerate.Checked;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }
        List<TripleEntry> baseKB = null;
        private void btnLoadKnowledgeBade_Click(object sender, EventArgs e)
        {
            string knowledgeBase;
            if (ofdOpenTrainFile.ShowDialog() == DialogResult.OK)
            {
                //try
                {
                    if (Path.GetExtension(ofdOpenTrainFile.FileName).ToLower().Equals("js") || Path.GetExtension(ofdOpenTrainFile.FileName).ToLower().Equals(".json"))
                    {
                        baseKB = parser.parse(ofdOpenTrainFile.FileName, true, cuttoff: -1);
                        
                    }
                    else if ((knowledgeBase = File.ReadAllText(ofdOpenTrainFile.FileName)) != null)
                    {
                        baseKB = parser.parse(knowledgeBase);                       
                    }
                    btnExtractNewKnowledge.Enabled = true;
                    lblMessage.ForeColor = Color.Green;

                    lblMessage.Text = "بارگذاری گراف دانش مبنا انجام شد " + baseKB.Count;
                }
            }
        }
        List<TripleEntry> suggestedTriples = new List<TripleEntry>();
        private void _btnExtractNewKnowledge_Click(object sender, EventArgs e)
        {            
            if (baseKB != null)
            {
                if(trulyDetectedInfo != null)
                {                    
                    foreach (TripleEntry triple in trulyDetectedInfo)
                    {
                        string entity1Simplifed = parser.simplifyText(triple.entity1);
                        string entity1SimplifiedStemmed = parser.doStemming(entity1Simplifed, Constants.CURRENT_LANGUAGE);
                        string entity2Simplifed = parser.simplifyText(triple.entity2);
                        string entity2SimplifiedStemmed = parser.doStemming(entity2Simplifed, Constants.CURRENT_LANGUAGE);
                        string relationSimplifed = parser.doStemming(parser.simplifyText(triple.relationType), "en");
                        TripleEntry triple1 = triple, triple2 = triple;
                        string relation1 = triple.relationType.Substring(0, triple.relationType.IndexOf("-")),
                            relation2 = triple.relationType.Substring(triple.relationType.IndexOf("-") + 1, triple.relationType.IndexOf("(") - triple.relationType.IndexOf("-")-1);
                        bool isE1E2Direction = triple.relationType.IndexOf("e1") < triple.relationType.IndexOf("e2") ? true : false;

                        triple1.relationType = isE1E2Direction ? relation1 : relation2;
                       
                        triple2.relationType = isE1E2Direction ? relation2 : relation1;
                        triple.entity1 = parser.simplifyText(triple.entity1);
                        triple.entity2 = parser.simplifyText(triple.entity2);

                        List<TripleEntry> equivalentEntriesInKb = baseKB.Where
                            (kb => parser.simplifyText(kb.entity1).Equals(parser.simplifyText( triple.entity1)) &&
                            parser.simplifyText( kb.entity2).Equals(parser.simplifyText(triple.entity2)) && 
                            (!chkStemWordsOnCompare.Checked || 
                            (parser.doStemming(parser.simplifyText(kb.entity1),Constants.CURRENT_LANGUAGE).Equals(entity1SimplifiedStemmed) &&
                            parser.doStemming(parser.simplifyText(kb.entity2),Constants.CURRENT_LANGUAGE).Equals(entity2SimplifiedStemmed)))).ToList();

                        
                        if (equivalentEntriesInKb != null && equivalentEntriesInKb.Count != 0)
                        {
                            if(equivalentEntriesInKb.Where(t=>parser.simplifyText(t.relationType).Equals(parser.simplifyText(triple.relationType)) && 
                            (!chkStemWordsOnCompare.Checked || (parser.doStemming(parser.simplifyText(t.relationType), Constants.CURRENT_LANGUAGE).Equals(relationSimplifed)))).DefaultIfEmpty() == null)
                            {
                                // suggest (e1, e2, r) tuple to be added to source KB                                
                                suggestedTriples.Add(chkStemWordsOnSuggestedTriples.Checked? new TripleEntry( entity1Simplifed, entity2Simplifed, isE1E2Direction? relation1 : relation2):triple1);
                                suggestedTriples.Add(chkStemWordsOnSuggestedTriples.Checked ? new TripleEntry(entity2Simplifed, entity1Simplifed, isE1E2Direction? relation2 : relation1) : triple2);
                            }
                        }
                        else if (chkSuggestNonExistingTriples.Checked)
                        {
                            triple.isAlreadyGrouped = true;
                            suggestedTriples.Add(chkStemWordsOnSuggestedTriples.Checked ? new TripleEntry(entity1Simplifed, entity2Simplifed, isE1E2Direction ? relation1 : relation2, true) : triple1);
                            suggestedTriples.Add(chkStemWordsOnSuggestedTriples.Checked ? new TripleEntry(entity2Simplifed, entity1Simplifed, isE1E2Direction ? relation2 : relation1, true) : triple2);
                        }
                    }
                    lbSuggestedTriples.Items.Clear();
                    foreach(TripleEntry triple in suggestedTriples.OrderBy(t=>t.relationType))
                    {                       

                        lbSuggestedTriples.Items.Add("("+ triple.entity1+"," + triple.entity2 + ", " + triple.relationType+(triple.isAlreadyGrouped?"*":"")+")");
                    }
                    lblMessage.Text = "Suggested Triples: " + suggestedTriples.Count ;
                    btnExportSuggestedTriples.Enabled = true;              
                }
            }
        }
        private void btnExtractNewKnowledge_Click(object sender, EventArgs e)
        {
            if (baseKB != null)
            {
                if (trulyDetectedInfo != null)
                {
                    foreach (TripleEntry triple in trulyDetectedInfo)
                    {
                        string entity1Simplifed = parser.doStemming(parser.simplifyText(triple.entity1), Constants.CURRENT_LANGUAGE);
                        string entity2Simplifed = parser.doStemming(parser.simplifyText(triple.entity2), Constants.CURRENT_LANGUAGE);
                        string relationSimplifed = parser.doStemming(parser.simplifyText(triple.relationType), "en");
                        TripleEntry triple1 = triple, triple2 = triple;
                        string relation1 = triple.relationType.Substring(0, triple.relationType.IndexOf("-")),
                            relation2 = triple.relationType.Substring(triple.relationType.IndexOf("-") + 1, triple.relationType.IndexOf("(") - triple.relationType.IndexOf("-") - 1);
                        bool isE1E2Direction = triple.relationType.IndexOf("e1") < triple.relationType.IndexOf("e2") ? true : false;

                        triple1.relationType = isE1E2Direction ? relation1 : relation2;
                        triple2.relationType = isE1E2Direction ? relation2 : relation1;

                        List<TripleEntry> equivalentEntriesInKb = baseKB.Where
                            (kb => parser.simplifyText(kb.entity1).Equals(parser.simplifyText(triple.entity1)) &&
                            parser.simplifyText(kb.entity2).Equals(parser.simplifyText(triple.entity2)) &&
                            (!chkStemWordsOnCompare.Checked ||
                            (parser.doStemming(parser.simplifyText(kb.entity1), Constants.CURRENT_LANGUAGE).Equals(entity1Simplifed) &&
                            parser.doStemming(parser.simplifyText(kb.entity2), Constants.CURRENT_LANGUAGE).Equals(entity2Simplifed)))).ToList();


                        if (equivalentEntriesInKb != null && equivalentEntriesInKb.Count != 0)
                        {
                            if (equivalentEntriesInKb.Where(t => parser.simplifyText(t.relationType).Equals(parser.simplifyText(triple.relationType)) &&
                             (!chkStemWordsOnCompare.Checked || (parser.doStemming(parser.simplifyText(t.relationType), Constants.CURRENT_LANGUAGE).Equals(relationSimplifed)))).DefaultIfEmpty() == null)
                            {
                                // suggest (e1, e2, r) tuple to be added to source KB                                
                                suggestedTriples.Add(chkStemWordsOnSuggestedTriples.Checked ? new TripleEntry(entity1Simplifed, entity2Simplifed, isE1E2Direction ? relation1 : relation2) : triple1);
                                suggestedTriples.Add(chkStemWordsOnSuggestedTriples.Checked ? new TripleEntry(entity2Simplifed, entity1Simplifed, isE1E2Direction ? relation2 : relation1) : triple2);
                            }
                        }
                        else if (chkSuggestNonExistingTriples.Checked)
                        {
                            ///triple.isAlreadyGrouped = true;
                            suggestedTriples.Add(chkStemWordsOnSuggestedTriples.Checked ? new TripleEntry(entity1Simplifed, entity2Simplifed, isE1E2Direction ? relation1 : relation2, true) : triple1);
                            suggestedTriples.Add(chkStemWordsOnSuggestedTriples.Checked ? new TripleEntry(entity2Simplifed, entity1Simplifed, isE1E2Direction ? relation2 : relation1, true) : triple2);
                        }
                    }
                    lbSuggestedTriples.Items.Clear();
                    foreach (TripleEntry triple in suggestedTriples.OrderBy(t => t.relationType))
                    {

                        lbSuggestedTriples.Items.Add("(" + triple.entity1 + "," + triple.entity2 + ", " + triple.relationType + (triple.isAlreadyGrouped ? "*" : "") + ")");
                    }
                    lblMessage.Text = "Suggested Triples: " + suggestedTriples.Count;
                    btnExportSuggestedTriples.Enabled = true;
                }
            }
        }


        private void btnLoadMoreRelations_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            string relations = null;
            lblMessage.ForeColor = Color.Black;
            if (trulyDetectedInfo == null)
                trulyDetectedInfo = new List<TripleEntry>();
            
            if (!chkModeMerge.Checked)
            {
                trulyDetectedInfo.Clear();
            }
            if (ofdOpenTrainFile.ShowDialog() == DialogResult.OK)
            {                
                if (Path.GetExtension(ofdOpenTrainFile.FileName).ToLower().Equals("js") || Path.GetExtension(ofdOpenTrainFile.FileName).ToLower().Equals(".json"))
                {
                    List<TripleEntry> loadedTriples = parser.parse(ofdOpenTrainFile.FileName, true, cuttoff: -1);
                    loadedTriples = loadedTriples.Where(t => !t.relationType.ToLower().Trim().Equals("other")).ToList();
                    trulyDetectedInfo.AddRange( loadedTriples);
                    
                }
                else if ((relations = File.ReadAllText(ofdOpenTrainFile.FileName)) != null)
                {
                    List<TripleEntry> loadedTriples = parser.parse(relations);
                    loadedTriples = loadedTriples.Where(t => !t.relationType.ToLower().Trim().Equals("other")).ToList();
                    trulyDetectedInfo.AddRange( loadedTriples);                    
                }
                lblMessage.ForeColor = Color.Green;
                lblMessage.Text = "Relations " + (chkModeMerge.Checked ? "Merged. " : "Loaded. ") + trulyDetectedInfo.Count;              
            }
        }

        private void btnExportSuggestedTriples_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfdRegex = new SaveFileDialog();
            lblMessage.Text = "";
            StringBuilder output = new StringBuilder();
            lblMessage.ForeColor = Color.Black;
            if (sfdRegex.ShowDialog() == DialogResult.OK)
            {
                if (Path.GetExtension(sfdRegex.FileName).ToLower().Equals(".json"))
                {
                    File.WriteAllText(sfdRegex.FileName, new JavaScriptSerializer().Serialize(suggestedTriples));
                }
                else if (Path.GetExtension(sfdRegex.FileName).ToLower().Equals(".txt"))
                {
                    for (int currentItem = 0; currentItem < suggestedTriples.Count; currentItem++)
                    {
                        output.Append("(" + suggestedTriples[currentItem].entity1 + ", " + suggestedTriples[currentItem].relationType + ", " + suggestedTriples[currentItem].entity2 + ")\n");
                    }
                    File.WriteAllText(sfdRegex.FileName, output.ToString());
                }
                lblMessage.ForeColor = Color.Green;
                lblMessage.Text = "Suggested Triples Exported " + suggestedTriples.Count + " Items.";                
            }
        }
        List<TripleEntry> testSamples;
        private void btnExtractEqualLengthSamples_Click(object sender, EventArgs e)
        {
            int interval = testEntries.Count / 300;
            StringBuilder output = new StringBuilder();
            testSamples = new List<TripleEntry>();
            
            if (testEntries != null && testEntries.Count > 0)
            {
                for (int currentSample = 0; currentSample < testEntries.Count; currentSample += interval)
                {
                    string entity1Simplifed = parser.simplifyText(testEntries[currentSample].entity1);
                    string entity1SimplifiedStemmed = parser.doStemming(entity1Simplifed, Constants.CURRENT_LANGUAGE);
                    string entity2Simplifed = parser.simplifyText(testEntries[currentSample].entity2);
                    string entity2SimplifiedStemmed = parser.doStemming(entity2Simplifed, Constants.CURRENT_LANGUAGE);
                    string relationSimplifed = parser.doStemming(parser.simplifyText(testEntries[currentSample].relationType), "en");
                    TripleEntry triple1 = testEntries[currentSample], triple2 = testEntries[currentSample];
                    string relation1 = testEntries[currentSample].relationType.Substring(0, testEntries[currentSample].relationType.IndexOf("-")),
                        relation2 = testEntries[currentSample].relationType.Substring(testEntries[currentSample].relationType.IndexOf("-") + 1, testEntries[currentSample].relationType.IndexOf("(") - testEntries[currentSample].relationType.IndexOf("-") - 1);
                    bool isE1E2Direction = testEntries[currentSample].relationType.IndexOf("e1") < testEntries[currentSample].relationType.IndexOf("e2") ? true : false;

                    triple1.relationType = isE1E2Direction ? relation1 : relation2;

                    triple2.relationType = isE1E2Direction ? relation2 : relation1;
                    testEntries[currentSample].entity1 = parser.simplifyText(testEntries[currentSample].entity1);
                    testEntries[currentSample].entity2 = parser.simplifyText(testEntries[currentSample].entity2);
                       
                                                  
                    testSamples.Add(chkStemWordsOnSuggestedTriples.Checked ? new TripleEntry(entity1SimplifiedStemmed, entity2SimplifiedStemmed, isE1E2Direction ? relation1 : relation2) : triple1);
                    testSamples.Add(chkStemWordsOnSuggestedTriples.Checked ? new TripleEntry(entity2SimplifiedStemmed, entity1SimplifiedStemmed, isE1E2Direction ? relation2 : relation1) : triple2);
                    output.Append("(" + entity1SimplifiedStemmed + ", " + (isE1E2Direction ? relation1 : relation2) + ", " + entity2SimplifiedStemmed + ")\n");
                    output.Append("(" + entity2SimplifiedStemmed + ", " + (isE1E2Direction ? relation2 : relation1) + ", " + entity1SimplifiedStemmed + ")\n");
                }
                SaveFileDialog sfdRegex = new SaveFileDialog();
                lblMessage.Text = "";

                lblMessage.ForeColor = Color.Black;
                if (sfdRegex.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(sfdRegex.FileName, output.ToString()/* new JavaScriptSerializer().Serialize(testSamples)*/);
                    lblMessage.ForeColor = Color.Green;
                    lblMessage.Text = "Test Sample Triples Exported " + suggestedTriples.Count + " Items.";
                }
            }
                                   
            
        }

        private void btnGetSubtracts_Click(object sender, EventArgs e)
        {
            List<TripleEntry> subtracts = new List<TripleEntry>();
            StringBuilder output = new StringBuilder();
            if(testSamples != null && testSamples.Count > 0 && suggestedTriples != null && suggestedTriples.Count > 0)
            {
                foreach(TripleEntry t in suggestedTriples)
                {
                    //TripleEntry nonExistingItem = testSamples.Where(s => s.entity1 != t.entity1 && s.entity2 != t.entity2 && s.relationType != t.relationType).FirstOrDefault();
                    if(!testSamples.Contains(t) && !subtracts.Contains(t))
                    {
                        subtracts.Add(t);
                    }
                    //if (nonExistingItem != null)
                    //{ 
                       
                    //}
                }
                //subtracts = suggestedTriples.Except(testSamples).ToList();
                for (int currentItem = 0; currentItem < subtracts.Count; currentItem++)
                {
                    output.Append("(" + subtracts[currentItem].entity1 + ", " + subtracts[currentItem].relationType + ", " + subtracts[currentItem].entity2 + ")\n");
                }
                SaveFileDialog sfdRegex = new SaveFileDialog();
                lblMessage.Text = "";

                lblMessage.ForeColor = Color.Black;
                if (sfdRegex.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(sfdRegex.FileName, output.ToString()/* new JavaScriptSerializer().Serialize(testSamples)*/);
                    lblMessage.ForeColor = Color.Green;
                    lblMessage.Text = "Subtract Triples Exported " + subtracts.Count + " Items.";
                }
            }

        }
    }
}
