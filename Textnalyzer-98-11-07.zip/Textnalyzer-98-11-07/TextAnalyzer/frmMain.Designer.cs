﻿namespace TextAnalyzer
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.lstAnnotators = new System.Windows.Forms.ListBox();
            this.btnAnalyze = new System.Windows.Forms.Button();
            this.nudMinSubstringOccourance = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOpenTrainFile = new System.Windows.Forms.Button();
            this.ofdOpenTrainFile = new System.Windows.Forms.OpenFileDialog();
            this.lblMessage = new System.Windows.Forms.Label();
            this.txtPrepositions = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nudMaxWordOccourance = new System.Windows.Forms.NumericUpDown();
            this.chkIgnorePrepositions = new System.Windows.Forms.CheckBox();
            this.chkStemWords = new System.Windows.Forms.CheckBox();
            this.lstStats = new System.Windows.Forms.ListBox();
            this.btnDefinePivotWords = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nudMaxSynonyms = new System.Windows.Forms.NumericUpDown();
            this.cmbLanguage = new System.Windows.Forms.ComboBox();
            this.chkMaxSynonyms = new System.Windows.Forms.CheckBox();
            this.chkNoSynonymsWhenStemming = new System.Windows.Forms.CheckBox();
            this.chkUseSynonyms = new System.Windows.Forms.CheckBox();
            this.chkExactMatchOfEntities = new System.Windows.Forms.CheckBox();
            this.chkLowFreqRegexGenerate = new System.Windows.Forms.CheckBox();
            this.chkRightToLeftLayout = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lsRegexes = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nudSentenceWordCountQualifiedScore = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.nudSentenceLengthQualifiedScore = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.nudMaxSentenceWordCountDiff = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.nudMaxSentenceLengthDiff = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.nudNonSameWordsQualified = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.nudMaxNonSameWords = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.nudCommonWordsQualifiedScore = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.nudMinCommonWords = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.nudMinSimilarityPercent = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSaveRegexes = new System.Windows.Forms.Button();
            this.btnAddToLearnedRegexes = new System.Windows.Forms.Button();
            this.btnResetParametersToDefaults = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lsSimilarSentencesRegex = new System.Windows.Forms.ListBox();
            this.lblRelations = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tcMain = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPageRegexes = new System.Windows.Forms.TabControl();
            this.tabHighFrequencyRegexes = new System.Windows.Forms.TabPage();
            this.tabLowFreqRegexes = new System.Windows.Forms.TabPage();
            this.chkSimpleRegexView = new System.Windows.Forms.CheckBox();
            this.btnRegexDetails = new System.Windows.Forms.Button();
            this.btnLogger = new System.Windows.Forms.Button();
            this.tabTest = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lsOutput = new System.Windows.Forms.ListBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lbCorrectDetected = new System.Windows.Forms.ListBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.lbMultipleMatches = new System.Windows.Forms.ListBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.lbMisMatches = new System.Windows.Forms.ListBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.lbNoMatches = new System.Windows.Forms.ListBox();
            this.chkConsiderE2E1SameAsE1E2 = new System.Windows.Forms.CheckBox();
            this.chkTreatMultipleMatchAsCorrect = new System.Windows.Forms.CheckBox();
            this.chkUseCurrentLearnedRegexes = new System.Windows.Forms.CheckBox();
            this.btnApplyRegexes = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblRecal = new System.Windows.Forms.Label();
            this.lblPrecision = new System.Windows.Forms.Label();
            this.lblTotalTestEntryCount = new System.Windows.Forms.Label();
            this.lblUnmatchCount = new System.Windows.Forms.Label();
            this.lblMisMatchCount = new System.Windows.Forms.Label();
            this.lblMultipleMatchCount = new System.Windows.Forms.Label();
            this.lblCorrectDetectionsCount = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lsRealRelations = new System.Windows.Forms.ListBox();
            this.btnLoadOtherLearnedRegexes = new System.Windows.Forms.Button();
            this.btnExtractEqualLengthSamples = new System.Windows.Forms.Button();
            this.btnLoadTestFile = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkUseInMemoryExtractedRelations = new System.Windows.Forms.CheckBox();
            this.btnLoadMoreRelations = new System.Windows.Forms.Button();
            this.chkModeMerge = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.lbSuggestedTriples = new System.Windows.Forms.ListBox();
            this.chkSuggestNonExistingTriples = new System.Windows.Forms.CheckBox();
            this.chkStemWordsOnSuggestedTriples = new System.Windows.Forms.CheckBox();
            this.chkStemWordsOnCompare = new System.Windows.Forms.CheckBox();
            this.btnExtractNewKnowledge = new System.Windows.Forms.Button();
            this.btnExportSuggestedTriples = new System.Windows.Forms.Button();
            this.btnLoadKnowledgeBade = new System.Windows.Forms.Button();
            this.btnGetSubtracts = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinSubstringOccourance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxWordOccourance)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxSynonyms)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSentenceWordCountQualifiedScore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSentenceLengthQualifiedScore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxSentenceWordCountDiff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxSentenceLengthDiff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNonSameWordsQualified)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxNonSameWords)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCommonWordsQualifiedScore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinCommonWords)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinSimilarityPercent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tcMain.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPageRegexes.SuspendLayout();
            this.tabHighFrequencyRegexes.SuspendLayout();
            this.tabLowFreqRegexes.SuspendLayout();
            this.tabTest.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstAnnotators
            // 
            this.lstAnnotators.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lstAnnotators.FormattingEnabled = true;
            this.lstAnnotators.ItemHeight = 16;
            this.lstAnnotators.Location = new System.Drawing.Point(9, 19);
            this.lstAnnotators.Name = "lstAnnotators";
            this.lstAnnotators.Size = new System.Drawing.Size(209, 260);
            this.lstAnnotators.TabIndex = 0;
            this.lstAnnotators.SelectedIndexChanged += new System.EventHandler(this.lstAnnotators_SelectedIndexChanged);
            // 
            // btnAnalyze
            // 
            this.btnAnalyze.Enabled = false;
            this.btnAnalyze.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnAnalyze.Image = ((System.Drawing.Image)(resources.GetObject("btnAnalyze.Image")));
            this.btnAnalyze.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAnalyze.Location = new System.Drawing.Point(879, 281);
            this.btnAnalyze.Name = "btnAnalyze";
            this.btnAnalyze.Size = new System.Drawing.Size(254, 62);
            this.btnAnalyze.TabIndex = 1;
            this.btnAnalyze.Text = "3 - Learn";
            this.btnAnalyze.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAnalyze.UseVisualStyleBackColor = true;
            this.btnAnalyze.Click += new System.EventHandler(this.btnAnalyze_Click);
            // 
            // nudMinSubstringOccourance
            // 
            this.nudMinSubstringOccourance.Location = new System.Drawing.Point(158, 199);
            this.nudMinSubstringOccourance.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMinSubstringOccourance.Name = "nudMinSubstringOccourance";
            this.nudMinSubstringOccourance.Size = new System.Drawing.Size(132, 21);
            this.nudMinSubstringOccourance.TabIndex = 2;
            this.nudMinSubstringOccourance.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.nudMinSubstringOccourance.ValueChanged += new System.EventHandler(this.nudMinSubstringOccourance_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(6, 201);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Minimum Phrase Occurance:";
            // 
            // btnOpenTrainFile
            // 
            this.btnOpenTrainFile.Image = ((System.Drawing.Image)(resources.GetObject("btnOpenTrainFile.Image")));
            this.btnOpenTrainFile.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnOpenTrainFile.Location = new System.Drawing.Point(879, 176);
            this.btnOpenTrainFile.Name = "btnOpenTrainFile";
            this.btnOpenTrainFile.Size = new System.Drawing.Size(254, 47);
            this.btnOpenTrainFile.TabIndex = 1;
            this.btnOpenTrainFile.Text = "1 - Open Train File";
            this.btnOpenTrainFile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOpenTrainFile.UseVisualStyleBackColor = true;
            this.btnOpenTrainFile.Click += new System.EventHandler(this.btnOpenTrainFile_Click);
            // 
            // ofdOpenTrainFile
            // 
            this.ofdOpenTrainFile.Filter = "rain Files (Train Files)|*.txt|Knowledge Graph Files (Knowledge Graph Files)|*.js" +
    "on";
            this.ofdOpenTrainFile.Title = "Open Properties file";
            // 
            // lblMessage
            // 
            this.lblMessage.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblMessage.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblMessage.Location = new System.Drawing.Point(0, 800);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(1164, 13);
            this.lblMessage.TabIndex = 4;
            this.lblMessage.Text = "Ready";
            this.lblMessage.Click += new System.EventHandler(this.lblMessage_Click);
            // 
            // txtPrepositions
            // 
            this.txtPrepositions.Location = new System.Drawing.Point(3, 322);
            this.txtPrepositions.Name = "txtPrepositions";
            this.txtPrepositions.Size = new System.Drawing.Size(866, 21);
            this.txtPrepositions.TabIndex = 7;
            this.txtPrepositions.Text = "از یا و and or the a an as این آن اینها آنها یک که می را به در با است بر شد ما تا" +
    " شود شده من تو او شما ایشان تر بی یی بزرگ بله صفر یک دو سه چهار پنج شش هفت هشت ن" +
    "ه کند";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(0, 346);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(203, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Available Phrases and frequencies:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(6, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(145, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Maximum Phrase Occurance:";
            // 
            // nudMaxWordOccourance
            // 
            this.nudMaxWordOccourance.Location = new System.Drawing.Point(158, 229);
            this.nudMaxWordOccourance.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMaxWordOccourance.Name = "nudMaxWordOccourance";
            this.nudMaxWordOccourance.Size = new System.Drawing.Size(132, 21);
            this.nudMaxWordOccourance.TabIndex = 2;
            this.nudMaxWordOccourance.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudMaxWordOccourance.ValueChanged += new System.EventHandler(this.nudMaxWordOccourance_ValueChanged);
            // 
            // chkIgnorePrepositions
            // 
            this.chkIgnorePrepositions.AutoSize = true;
            this.chkIgnorePrepositions.Checked = true;
            this.chkIgnorePrepositions.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIgnorePrepositions.Location = new System.Drawing.Point(3, 299);
            this.chkIgnorePrepositions.Name = "chkIgnorePrepositions";
            this.chkIgnorePrepositions.Size = new System.Drawing.Size(355, 17);
            this.chkIgnorePrepositions.TabIndex = 9;
            this.chkIgnorePrepositions.Text = "Ignore Following Prepositions for Selected Relation (Space Delimited)";
            this.chkIgnorePrepositions.UseVisualStyleBackColor = true;
            this.chkIgnorePrepositions.CheckedChanged += new System.EventHandler(this.chkIgnorePrepositions_CheckedChanged);
            // 
            // chkStemWords
            // 
            this.chkStemWords.AutoSize = true;
            this.chkStemWords.Location = new System.Drawing.Point(6, 22);
            this.chkStemWords.Name = "chkStemWords";
            this.chkStemWords.Size = new System.Drawing.Size(122, 17);
            this.chkStemWords.TabIndex = 9;
            this.chkStemWords.Text = "Use Word Stemming";
            this.chkStemWords.UseVisualStyleBackColor = true;
            this.chkStemWords.CheckedChanged += new System.EventHandler(this.chkIgnorePrepositions_CheckedChanged);
            // 
            // lstStats
            // 
            this.lstStats.FormattingEnabled = true;
            this.lstStats.HorizontalScrollbar = true;
            this.lstStats.Location = new System.Drawing.Point(0, 362);
            this.lstStats.Name = "lstStats";
            this.lstStats.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lstStats.Size = new System.Drawing.Size(1133, 82);
            this.lstStats.TabIndex = 10;
            // 
            // btnDefinePivotWords
            // 
            this.btnDefinePivotWords.Enabled = false;
            this.btnDefinePivotWords.Image = ((System.Drawing.Image)(resources.GetObject("btnDefinePivotWords.Image")));
            this.btnDefinePivotWords.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDefinePivotWords.Location = new System.Drawing.Point(879, 228);
            this.btnDefinePivotWords.Name = "btnDefinePivotWords";
            this.btnDefinePivotWords.Size = new System.Drawing.Size(254, 47);
            this.btnDefinePivotWords.TabIndex = 1;
            this.btnDefinePivotWords.Text = "2 - Define Selected Relation\'s Pivot Words";
            this.btnDefinePivotWords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDefinePivotWords.UseVisualStyleBackColor = true;
            this.btnDefinePivotWords.Click += new System.EventHandler(this.btnDefinePivotWords_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nudMaxSynonyms);
            this.groupBox1.Controls.Add(this.cmbLanguage);
            this.groupBox1.Controls.Add(this.chkMaxSynonyms);
            this.groupBox1.Controls.Add(this.chkNoSynonymsWhenStemming);
            this.groupBox1.Controls.Add(this.chkUseSynonyms);
            this.groupBox1.Controls.Add(this.chkExactMatchOfEntities);
            this.groupBox1.Controls.Add(this.chkLowFreqRegexGenerate);
            this.groupBox1.Controls.Add(this.chkRightToLeftLayout);
            this.groupBox1.Controls.Add(this.chkStemWords);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.nudMinSubstringOccourance);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.nudMaxWordOccourance);
            this.groupBox1.Location = new System.Drawing.Point(574, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(299, 279);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Options";
            // 
            // nudMaxSynonyms
            // 
            this.nudMaxSynonyms.Location = new System.Drawing.Point(229, 134);
            this.nudMaxSynonyms.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMaxSynonyms.Name = "nudMaxSynonyms";
            this.nudMaxSynonyms.Size = new System.Drawing.Size(61, 21);
            this.nudMaxSynonyms.TabIndex = 2;
            this.nudMaxSynonyms.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // cmbLanguage
            // 
            this.cmbLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLanguage.FormattingEnabled = true;
            this.cmbLanguage.Items.AddRange(new object[] {
            "Persian",
            "English"});
            this.cmbLanguage.Location = new System.Drawing.Point(158, 36);
            this.cmbLanguage.Name = "cmbLanguage";
            this.cmbLanguage.Size = new System.Drawing.Size(132, 21);
            this.cmbLanguage.TabIndex = 10;
            // 
            // chkMaxSynonyms
            // 
            this.chkMaxSynonyms.AutoSize = true;
            this.chkMaxSynonyms.Checked = true;
            this.chkMaxSynonyms.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMaxSynonyms.Location = new System.Drawing.Point(6, 135);
            this.chkMaxSynonyms.Name = "chkMaxSynonyms";
            this.chkMaxSynonyms.Size = new System.Drawing.Size(141, 17);
            this.chkMaxSynonyms.TabIndex = 9;
            this.chkMaxSynonyms.Text = "Max Synonyms to Fetch";
            this.chkMaxSynonyms.UseVisualStyleBackColor = true;
            this.chkMaxSynonyms.CheckedChanged += new System.EventHandler(this.chkMaxSynonyms_CheckedChanged);
            // 
            // chkNoSynonymsWhenStemming
            // 
            this.chkNoSynonymsWhenStemming.AutoSize = true;
            this.chkNoSynonymsWhenStemming.Checked = true;
            this.chkNoSynonymsWhenStemming.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkNoSynonymsWhenStemming.Location = new System.Drawing.Point(6, 112);
            this.chkNoSynonymsWhenStemming.Name = "chkNoSynonymsWhenStemming";
            this.chkNoSynonymsWhenStemming.Size = new System.Drawing.Size(204, 17);
            this.chkNoSynonymsWhenStemming.TabIndex = 9;
            this.chkNoSynonymsWhenStemming.Text = "Don\'t Use Synonyms When Stemming";
            this.chkNoSynonymsWhenStemming.UseVisualStyleBackColor = true;
            // 
            // chkUseSynonyms
            // 
            this.chkUseSynonyms.AutoSize = true;
            this.chkUseSynonyms.Location = new System.Drawing.Point(6, 89);
            this.chkUseSynonyms.Name = "chkUseSynonyms";
            this.chkUseSynonyms.Size = new System.Drawing.Size(244, 17);
            this.chkUseSynonyms.TabIndex = 9;
            this.chkUseSynonyms.Text = "Use Synonyms of Words in Regex Generation";
            this.chkUseSynonyms.UseVisualStyleBackColor = true;
            // 
            // chkExactMatchOfEntities
            // 
            this.chkExactMatchOfEntities.AutoSize = true;
            this.chkExactMatchOfEntities.Location = new System.Drawing.Point(6, 66);
            this.chkExactMatchOfEntities.Name = "chkExactMatchOfEntities";
            this.chkExactMatchOfEntities.Size = new System.Drawing.Size(262, 17);
            this.chkExactMatchOfEntities.TabIndex = 9;
            this.chkExactMatchOfEntities.Text = "Also Learn Match of Entities for Selected Relation";
            this.chkExactMatchOfEntities.UseVisualStyleBackColor = true;
            // 
            // chkLowFreqRegexGenerate
            // 
            this.chkLowFreqRegexGenerate.AutoSize = true;
            this.chkLowFreqRegexGenerate.Checked = true;
            this.chkLowFreqRegexGenerate.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkLowFreqRegexGenerate.Location = new System.Drawing.Point(6, 156);
            this.chkLowFreqRegexGenerate.Name = "chkLowFreqRegexGenerate";
            this.chkLowFreqRegexGenerate.Size = new System.Drawing.Size(245, 17);
            this.chkLowFreqRegexGenerate.TabIndex = 9;
            this.chkLowFreqRegexGenerate.Text = "Generate Regex for low frequency sentences";
            this.chkLowFreqRegexGenerate.UseVisualStyleBackColor = true;
            this.chkLowFreqRegexGenerate.CheckedChanged += new System.EventHandler(this.chkLowFreqRegexGenerate_CheckedChanged);
            // 
            // chkRightToLeftLayout
            // 
            this.chkRightToLeftLayout.AutoSize = true;
            this.chkRightToLeftLayout.Location = new System.Drawing.Point(6, 175);
            this.chkRightToLeftLayout.Name = "chkRightToLeftLayout";
            this.chkRightToLeftLayout.Size = new System.Drawing.Size(122, 17);
            this.chkRightToLeftLayout.TabIndex = 9;
            this.chkRightToLeftLayout.Text = "Right to Left Layout";
            this.chkRightToLeftLayout.UseVisualStyleBackColor = true;
            this.chkRightToLeftLayout.CheckedChanged += new System.EventHandler(this.chkRightToLeftLayout_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(6, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Stemming Language";
            // 
            // lsRegexes
            // 
            this.lsRegexes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsRegexes.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsRegexes.FormattingEnabled = true;
            this.lsRegexes.HorizontalScrollbar = true;
            this.lsRegexes.ItemHeight = 24;
            this.lsRegexes.Location = new System.Drawing.Point(3, 3);
            this.lsRegexes.Name = "lsRegexes";
            this.lsRegexes.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lsRegexes.Size = new System.Drawing.Size(989, 302);
            this.lsRegexes.TabIndex = 10;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.nudSentenceWordCountQualifiedScore);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.nudSentenceLengthQualifiedScore);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.nudMaxSentenceWordCountDiff);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.nudMaxSentenceLengthDiff);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.numericUpDown1);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.nudNonSameWordsQualified);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.nudMaxNonSameWords);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.nudCommonWordsQualifiedScore);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.nudMinCommonWords);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.nudMinSimilarityPercent);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(224, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(344, 280);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tuning";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // nudSentenceWordCountQualifiedScore
            // 
            this.nudSentenceWordCountQualifiedScore.Location = new System.Drawing.Point(214, 120);
            this.nudSentenceWordCountQualifiedScore.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudSentenceWordCountQualifiedScore.Name = "nudSentenceWordCountQualifiedScore";
            this.nudSentenceWordCountQualifiedScore.Size = new System.Drawing.Size(61, 21);
            this.nudSentenceWordCountQualifiedScore.TabIndex = 2;
            this.nudSentenceWordCountQualifiedScore.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label9.Location = new System.Drawing.Point(6, 125);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(206, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Sentence Word Count Qualified Score: %";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nudSentenceLengthQualifiedScore
            // 
            this.nudSentenceLengthQualifiedScore.Location = new System.Drawing.Point(214, 66);
            this.nudSentenceLengthQualifiedScore.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudSentenceLengthQualifiedScore.Name = "nudSentenceLengthQualifiedScore";
            this.nudSentenceLengthQualifiedScore.Size = new System.Drawing.Size(61, 21);
            this.nudSentenceLengthQualifiedScore.TabIndex = 2;
            this.nudSentenceLengthQualifiedScore.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label7.Location = new System.Drawing.Point(6, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(181, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Sentence Length Qualified Score: %";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nudMaxSentenceWordCountDiff
            // 
            this.nudMaxSentenceWordCountDiff.Location = new System.Drawing.Point(214, 93);
            this.nudMaxSentenceWordCountDiff.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMaxSentenceWordCountDiff.Name = "nudMaxSentenceWordCountDiff";
            this.nudMaxSentenceWordCountDiff.Size = new System.Drawing.Size(61, 21);
            this.nudMaxSentenceWordCountDiff.TabIndex = 2;
            this.nudMaxSentenceWordCountDiff.Value = new decimal(new int[] {
            9,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label8.Location = new System.Drawing.Point(6, 98);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(187, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Max Sentence Word Count Diffrence:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nudMaxSentenceLengthDiff
            // 
            this.nudMaxSentenceLengthDiff.Location = new System.Drawing.Point(214, 42);
            this.nudMaxSentenceLengthDiff.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMaxSentenceLengthDiff.Name = "nudMaxSentenceLengthDiff";
            this.nudMaxSentenceLengthDiff.Size = new System.Drawing.Size(61, 21);
            this.nudMaxSentenceLengthDiff.TabIndex = 2;
            this.nudMaxSentenceLengthDiff.Value = new decimal(new int[] {
            25,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label6.Location = new System.Drawing.Point(6, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(176, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Max Sentence Length Diffrence: %";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(214, 246);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(61, 21);
            this.numericUpDown1.TabIndex = 2;
            this.numericUpDown1.Value = new decimal(new int[] {
            70,
            0,
            0,
            0});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label14.Location = new System.Drawing.Point(6, 251);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(187, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "Min Frequency to Appear in Regex %";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label14.Click += new System.EventHandler(this.label12_Click);
            // 
            // nudNonSameWordsQualified
            // 
            this.nudNonSameWordsQualified.Location = new System.Drawing.Point(214, 223);
            this.nudNonSameWordsQualified.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudNonSameWordsQualified.Name = "nudNonSameWordsQualified";
            this.nudNonSameWordsQualified.Size = new System.Drawing.Size(61, 21);
            this.nudNonSameWordsQualified.TabIndex = 2;
            this.nudNonSameWordsQualified.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.Location = new System.Drawing.Point(6, 228);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(151, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Non same Words Qualified: %";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Click += new System.EventHandler(this.label12_Click);
            // 
            // nudMaxNonSameWords
            // 
            this.nudMaxNonSameWords.Location = new System.Drawing.Point(214, 196);
            this.nudMaxNonSameWords.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMaxNonSameWords.Name = "nudMaxNonSameWords";
            this.nudMaxNonSameWords.Size = new System.Drawing.Size(61, 21);
            this.nudMaxNonSameWords.TabIndex = 2;
            this.nudMaxNonSameWords.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label12.Location = new System.Drawing.Point(6, 201);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(129, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Max Non same Words: %";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // nudCommonWordsQualifiedScore
            // 
            this.nudCommonWordsQualifiedScore.Location = new System.Drawing.Point(214, 171);
            this.nudCommonWordsQualifiedScore.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudCommonWordsQualifiedScore.Name = "nudCommonWordsQualifiedScore";
            this.nudCommonWordsQualifiedScore.Size = new System.Drawing.Size(61, 21);
            this.nudCommonWordsQualifiedScore.TabIndex = 2;
            this.nudCommonWordsQualifiedScore.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label11.Location = new System.Drawing.Point(6, 176);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(175, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Common Words Qualified Score: %";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nudMinCommonWords
            // 
            this.nudMinCommonWords.Location = new System.Drawing.Point(214, 147);
            this.nudMinCommonWords.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMinCommonWords.Name = "nudMinCommonWords";
            this.nudMinCommonWords.Size = new System.Drawing.Size(61, 21);
            this.nudMinCommonWords.TabIndex = 2;
            this.nudMinCommonWords.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label10.Location = new System.Drawing.Point(6, 152);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(119, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "Min Common Words: %";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nudMinSimilarityPercent
            // 
            this.nudMinSimilarityPercent.Location = new System.Drawing.Point(214, 17);
            this.nudMinSimilarityPercent.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudMinSimilarityPercent.Name = "nudMinSimilarityPercent";
            this.nudMinSimilarityPercent.Size = new System.Drawing.Size(61, 21);
            this.nudMinSimilarityPercent.TabIndex = 2;
            this.nudMinSimilarityPercent.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.Location = new System.Drawing.Point(6, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Min Similarity Percent %:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnSaveRegexes
            // 
            this.btnSaveRegexes.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSaveRegexes.Location = new System.Drawing.Point(1033, 451);
            this.btnSaveRegexes.Name = "btnSaveRegexes";
            this.btnSaveRegexes.Size = new System.Drawing.Size(100, 76);
            this.btnSaveRegexes.TabIndex = 1;
            this.btnSaveRegexes.Text = "Export Regexes";
            this.btnSaveRegexes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveRegexes.UseVisualStyleBackColor = true;
            this.btnSaveRegexes.Click += new System.EventHandler(this.btnSaveRegexes_Click);
            // 
            // btnAddToLearnedRegexes
            // 
            this.btnAddToLearnedRegexes.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddToLearnedRegexes.Location = new System.Drawing.Point(1033, 533);
            this.btnAddToLearnedRegexes.Name = "btnAddToLearnedRegexes";
            this.btnAddToLearnedRegexes.Size = new System.Drawing.Size(100, 72);
            this.btnAddToLearnedRegexes.TabIndex = 1;
            this.btnAddToLearnedRegexes.Text = "Add to Exported Regexes";
            this.btnAddToLearnedRegexes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddToLearnedRegexes.UseVisualStyleBackColor = true;
            // 
            // btnResetParametersToDefaults
            // 
            this.btnResetParametersToDefaults.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnResetParametersToDefaults.Location = new System.Drawing.Point(881, 144);
            this.btnResetParametersToDefaults.Name = "btnResetParametersToDefaults";
            this.btnResetParametersToDefaults.Size = new System.Drawing.Size(158, 26);
            this.btnResetParametersToDefaults.TabIndex = 1;
            this.btnResetParametersToDefaults.Text = "Reset Parameters to Defaults";
            this.btnResetParametersToDefaults.UseVisualStyleBackColor = true;
            this.btnResetParametersToDefaults.Click += new System.EventHandler(this.btnResetParametersToDefaults_Click);
            // 
            // btnExit
            // 
            this.btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExit.Location = new System.Drawing.Point(1045, 144);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 26);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lsSimilarSentencesRegex
            // 
            this.lsSimilarSentencesRegex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsSimilarSentencesRegex.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsSimilarSentencesRegex.FormattingEnabled = true;
            this.lsSimilarSentencesRegex.HorizontalScrollbar = true;
            this.lsSimilarSentencesRegex.ItemHeight = 24;
            this.lsSimilarSentencesRegex.Location = new System.Drawing.Point(3, 3);
            this.lsSimilarSentencesRegex.Name = "lsSimilarSentencesRegex";
            this.lsSimilarSentencesRegex.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lsSimilarSentencesRegex.Size = new System.Drawing.Size(989, 302);
            this.lsSimilarSentencesRegex.TabIndex = 10;
            this.lsSimilarSentencesRegex.SelectedIndexChanged += new System.EventHandler(this.lsSimilarSentencesRegex_SelectedIndexChanged);
            // 
            // lblRelations
            // 
            this.lblRelations.AutoSize = true;
            this.lblRelations.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblRelations.Location = new System.Drawing.Point(9, 5);
            this.lblRelations.Name = "lblRelations";
            this.lblRelations.Size = new System.Drawing.Size(115, 13);
            this.lblRelations.TabIndex = 8;
            this.lblRelations.Text = "Detected Relations";
            this.lblRelations.Click += new System.EventHandler(this.lblRelations_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(951, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 117);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // tcMain
            // 
            this.tcMain.Controls.Add(this.tabPage1);
            this.tcMain.Controls.Add(this.tabTest);
            this.tcMain.Controls.Add(this.tabPage3);
            this.tcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcMain.Location = new System.Drawing.Point(0, 0);
            this.tcMain.Name = "tcMain";
            this.tcMain.SelectedIndex = 0;
            this.tcMain.Size = new System.Drawing.Size(1164, 800);
            this.tcMain.TabIndex = 13;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabPageRegexes);
            this.tabPage1.Controls.Add(this.lblRelations);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.lstAnnotators);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.btnAnalyze);
            this.tabPage1.Controls.Add(this.chkSimpleRegexView);
            this.tabPage1.Controls.Add(this.btnOpenTrainFile);
            this.tabPage1.Controls.Add(this.btnSaveRegexes);
            this.tabPage1.Controls.Add(this.lstStats);
            this.tabPage1.Controls.Add(this.btnRegexDetails);
            this.tabPage1.Controls.Add(this.btnLogger);
            this.tabPage1.Controls.Add(this.btnAddToLearnedRegexes);
            this.tabPage1.Controls.Add(this.chkIgnorePrepositions);
            this.tabPage1.Controls.Add(this.btnResetParametersToDefaults);
            this.tabPage1.Controls.Add(this.btnExit);
            this.tabPage1.Controls.Add(this.txtPrepositions);
            this.tabPage1.Controls.Add(this.btnDefinePivotWords);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1156, 774);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "TRAIN";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPageRegexes
            // 
            this.tabPageRegexes.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabPageRegexes.Controls.Add(this.tabHighFrequencyRegexes);
            this.tabPageRegexes.Controls.Add(this.tabLowFreqRegexes);
            this.tabPageRegexes.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tabPageRegexes.HotTrack = true;
            this.tabPageRegexes.Location = new System.Drawing.Point(3, 450);
            this.tabPageRegexes.Multiline = true;
            this.tabPageRegexes.Name = "tabPageRegexes";
            this.tabPageRegexes.SelectedIndex = 0;
            this.tabPageRegexes.Size = new System.Drawing.Size(1023, 316);
            this.tabPageRegexes.TabIndex = 13;
            // 
            // tabHighFrequencyRegexes
            // 
            this.tabHighFrequencyRegexes.Controls.Add(this.lsSimilarSentencesRegex);
            this.tabHighFrequencyRegexes.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tabHighFrequencyRegexes.Location = new System.Drawing.Point(24, 4);
            this.tabHighFrequencyRegexes.Name = "tabHighFrequencyRegexes";
            this.tabHighFrequencyRegexes.Padding = new System.Windows.Forms.Padding(3);
            this.tabHighFrequencyRegexes.Size = new System.Drawing.Size(995, 308);
            this.tabHighFrequencyRegexes.TabIndex = 0;
            this.tabHighFrequencyRegexes.Text = "High-Frequency Regexes";
            this.tabHighFrequencyRegexes.UseVisualStyleBackColor = true;
            // 
            // tabLowFreqRegexes
            // 
            this.tabLowFreqRegexes.Controls.Add(this.lsRegexes);
            this.tabLowFreqRegexes.Location = new System.Drawing.Point(24, 4);
            this.tabLowFreqRegexes.Name = "tabLowFreqRegexes";
            this.tabLowFreqRegexes.Padding = new System.Windows.Forms.Padding(3);
            this.tabLowFreqRegexes.Size = new System.Drawing.Size(995, 308);
            this.tabLowFreqRegexes.TabIndex = 1;
            this.tabLowFreqRegexes.Text = "Low-Frequency Regexes";
            this.tabLowFreqRegexes.UseVisualStyleBackColor = true;
            // 
            // chkSimpleRegexView
            // 
            this.chkSimpleRegexView.AutoSize = true;
            this.chkSimpleRegexView.Location = new System.Drawing.Point(1032, 703);
            this.chkSimpleRegexView.Name = "chkSimpleRegexView";
            this.chkSimpleRegexView.Size = new System.Drawing.Size(115, 17);
            this.chkSimpleRegexView.TabIndex = 9;
            this.chkSimpleRegexView.Text = "Simple Regex View";
            this.chkSimpleRegexView.UseVisualStyleBackColor = true;
            this.chkSimpleRegexView.CheckedChanged += new System.EventHandler(this.chkSimpleRegexView_CheckedChanged);
            // 
            // btnRegexDetails
            // 
            this.btnRegexDetails.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRegexDetails.Location = new System.Drawing.Point(1035, 611);
            this.btnRegexDetails.Name = "btnRegexDetails";
            this.btnRegexDetails.Size = new System.Drawing.Size(100, 74);
            this.btnRegexDetails.TabIndex = 1;
            this.btnRegexDetails.Text = "Regex Details...";
            this.btnRegexDetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegexDetails.UseVisualStyleBackColor = true;
            this.btnRegexDetails.Click += new System.EventHandler(this.btnRegexDetails_Click);
            // 
            // btnLogger
            // 
            this.btnLogger.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLogger.Location = new System.Drawing.Point(1033, 726);
            this.btnLogger.Name = "btnLogger";
            this.btnLogger.Size = new System.Drawing.Size(100, 40);
            this.btnLogger.TabIndex = 1;
            this.btnLogger.Text = "Logger...";
            this.btnLogger.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogger.UseVisualStyleBackColor = true;
            this.btnLogger.Click += new System.EventHandler(this.btnLogger_Click);
            // 
            // tabTest
            // 
            this.tabTest.Controls.Add(this.tabControl2);
            this.tabTest.Controls.Add(this.chkConsiderE2E1SameAsE1E2);
            this.tabTest.Controls.Add(this.chkTreatMultipleMatchAsCorrect);
            this.tabTest.Controls.Add(this.chkUseCurrentLearnedRegexes);
            this.tabTest.Controls.Add(this.btnApplyRegexes);
            this.tabTest.Controls.Add(this.label22);
            this.tabTest.Controls.Add(this.label23);
            this.tabTest.Controls.Add(this.label21);
            this.tabTest.Controls.Add(this.label24);
            this.tabTest.Controls.Add(this.label20);
            this.tabTest.Controls.Add(this.label19);
            this.tabTest.Controls.Add(this.label18);
            this.tabTest.Controls.Add(this.lblRecal);
            this.tabTest.Controls.Add(this.lblPrecision);
            this.tabTest.Controls.Add(this.lblTotalTestEntryCount);
            this.tabTest.Controls.Add(this.lblUnmatchCount);
            this.tabTest.Controls.Add(this.lblMisMatchCount);
            this.tabTest.Controls.Add(this.lblMultipleMatchCount);
            this.tabTest.Controls.Add(this.lblCorrectDetectionsCount);
            this.tabTest.Controls.Add(this.label16);
            this.tabTest.Controls.Add(this.label15);
            this.tabTest.Controls.Add(this.lsRealRelations);
            this.tabTest.Controls.Add(this.btnLoadOtherLearnedRegexes);
            this.tabTest.Controls.Add(this.btnGetSubtracts);
            this.tabTest.Controls.Add(this.btnExtractEqualLengthSamples);
            this.tabTest.Controls.Add(this.btnLoadTestFile);
            this.tabTest.Location = new System.Drawing.Point(4, 22);
            this.tabTest.Name = "tabTest";
            this.tabTest.Padding = new System.Windows.Forms.Padding(3);
            this.tabTest.Size = new System.Drawing.Size(1156, 774);
            this.tabTest.TabIndex = 1;
            this.tabTest.Text = "TEST";
            this.tabTest.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControl2.Location = new System.Drawing.Point(3, 287);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1150, 484);
            this.tabControl2.TabIndex = 15;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lsOutput);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1142, 458);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Text = "All Results";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lsOutput
            // 
            this.lsOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsOutput.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lsOutput.FormattingEnabled = true;
            this.lsOutput.HorizontalScrollbar = true;
            this.lsOutput.ItemHeight = 24;
            this.lsOutput.Location = new System.Drawing.Point(3, 3);
            this.lsOutput.Name = "lsOutput";
            this.lsOutput.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lsOutput.Size = new System.Drawing.Size(1136, 452);
            this.lsOutput.TabIndex = 12;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.lbCorrectDetected);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1142, 458);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Correct Detected (True Positives)";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // lbCorrectDetected
            // 
            this.lbCorrectDetected.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbCorrectDetected.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbCorrectDetected.FormattingEnabled = true;
            this.lbCorrectDetected.HorizontalScrollbar = true;
            this.lbCorrectDetected.ItemHeight = 24;
            this.lbCorrectDetected.Location = new System.Drawing.Point(3, 3);
            this.lbCorrectDetected.Name = "lbCorrectDetected";
            this.lbCorrectDetected.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbCorrectDetected.Size = new System.Drawing.Size(1136, 452);
            this.lbCorrectDetected.TabIndex = 13;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.lbMultipleMatches);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1142, 458);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "Multiple Matchs(False Positives)";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // lbMultipleMatches
            // 
            this.lbMultipleMatches.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbMultipleMatches.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbMultipleMatches.FormattingEnabled = true;
            this.lbMultipleMatches.HorizontalScrollbar = true;
            this.lbMultipleMatches.ItemHeight = 24;
            this.lbMultipleMatches.Location = new System.Drawing.Point(3, 3);
            this.lbMultipleMatches.Name = "lbMultipleMatches";
            this.lbMultipleMatches.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbMultipleMatches.Size = new System.Drawing.Size(1136, 452);
            this.lbMultipleMatches.TabIndex = 13;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.lbMisMatches);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1142, 458);
            this.tabPage6.TabIndex = 3;
            this.tabPage6.Text = "Mis-Matchs(False Positives)";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // lbMisMatches
            // 
            this.lbMisMatches.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbMisMatches.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbMisMatches.FormattingEnabled = true;
            this.lbMisMatches.HorizontalScrollbar = true;
            this.lbMisMatches.ItemHeight = 24;
            this.lbMisMatches.Location = new System.Drawing.Point(3, 3);
            this.lbMisMatches.Name = "lbMisMatches";
            this.lbMisMatches.Size = new System.Drawing.Size(1136, 452);
            this.lbMisMatches.TabIndex = 13;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.lbNoMatches);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1142, 458);
            this.tabPage7.TabIndex = 4;
            this.tabPage7.Text = "No Matches(False Negatives)";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // lbNoMatches
            // 
            this.lbNoMatches.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbNoMatches.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbNoMatches.FormattingEnabled = true;
            this.lbNoMatches.HorizontalScrollbar = true;
            this.lbNoMatches.ItemHeight = 24;
            this.lbNoMatches.Location = new System.Drawing.Point(3, 3);
            this.lbNoMatches.Name = "lbNoMatches";
            this.lbNoMatches.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbNoMatches.Size = new System.Drawing.Size(1136, 452);
            this.lbNoMatches.TabIndex = 13;
            // 
            // chkConsiderE2E1SameAsE1E2
            // 
            this.chkConsiderE2E1SameAsE1E2.AutoSize = true;
            this.chkConsiderE2E1SameAsE1E2.Checked = true;
            this.chkConsiderE2E1SameAsE1E2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkConsiderE2E1SameAsE1E2.Location = new System.Drawing.Point(413, 40);
            this.chkConsiderE2E1SameAsE1E2.Name = "chkConsiderE2E1SameAsE1E2";
            this.chkConsiderE2E1SameAsE1E2.Size = new System.Drawing.Size(173, 17);
            this.chkConsiderE2E1SameAsE1E2.TabIndex = 14;
            this.chkConsiderE2E1SameAsE1E2.Text = "Consider e1,e2 Same as e2,e1";
            this.chkConsiderE2E1SameAsE1E2.UseVisualStyleBackColor = true;
            this.chkConsiderE2E1SameAsE1E2.CheckedChanged += new System.EventHandler(this.chkConsiderE2E1SameAsE1E2_CheckedChanged);
            // 
            // chkTreatMultipleMatchAsCorrect
            // 
            this.chkTreatMultipleMatchAsCorrect.AutoSize = true;
            this.chkTreatMultipleMatchAsCorrect.Checked = true;
            this.chkTreatMultipleMatchAsCorrect.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkTreatMultipleMatchAsCorrect.Location = new System.Drawing.Point(413, 17);
            this.chkTreatMultipleMatchAsCorrect.Name = "chkTreatMultipleMatchAsCorrect";
            this.chkTreatMultipleMatchAsCorrect.Size = new System.Drawing.Size(231, 17);
            this.chkTreatMultipleMatchAsCorrect.TabIndex = 14;
            this.chkTreatMultipleMatchAsCorrect.Text = "Treat Multiple-Match Detections as Correct";
            this.chkTreatMultipleMatchAsCorrect.UseVisualStyleBackColor = true;
            this.chkTreatMultipleMatchAsCorrect.CheckedChanged += new System.EventHandler(this.chkTreatMultipleMatchAsCorrect_CheckedChanged);
            // 
            // chkUseCurrentLearnedRegexes
            // 
            this.chkUseCurrentLearnedRegexes.AutoSize = true;
            this.chkUseCurrentLearnedRegexes.Checked = true;
            this.chkUseCurrentLearnedRegexes.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkUseCurrentLearnedRegexes.Location = new System.Drawing.Point(860, 106);
            this.chkUseCurrentLearnedRegexes.Name = "chkUseCurrentLearnedRegexes";
            this.chkUseCurrentLearnedRegexes.Size = new System.Drawing.Size(223, 17);
            this.chkUseCurrentLearnedRegexes.TabIndex = 14;
            this.chkUseCurrentLearnedRegexes.Text = "Use Current Learned Regexes in Memory";
            this.chkUseCurrentLearnedRegexes.UseVisualStyleBackColor = true;
            this.chkUseCurrentLearnedRegexes.CheckedChanged += new System.EventHandler(this.chkUseCurrentLearnedRegexes_CheckedChanged);
            // 
            // btnApplyRegexes
            // 
            this.btnApplyRegexes.Enabled = false;
            this.btnApplyRegexes.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnApplyRegexes.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnApplyRegexes.Location = new System.Drawing.Point(860, 214);
            this.btnApplyRegexes.Name = "btnApplyRegexes";
            this.btnApplyRegexes.Size = new System.Drawing.Size(254, 73);
            this.btnApplyRegexes.TabIndex = 13;
            this.btnApplyRegexes.Text = "Evaluate";
            this.btnApplyRegexes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnApplyRegexes.UseVisualStyleBackColor = true;
            this.btnApplyRegexes.Click += new System.EventHandler(this.btnApplyRegexes_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label22.Location = new System.Drawing.Point(410, 266);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(45, 13);
            this.label22.TabIndex = 10;
            this.label22.Text = "RECAL:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label23.Location = new System.Drawing.Point(410, 218);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(238, 13);
            this.label23.TabIndex = 10;
            this.label23.Text = "_________________________________";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label21.Location = new System.Drawing.Point(410, 240);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 13);
            this.label21.TabIndex = 10;
            this.label21.Text = "PRECISION:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label24.Location = new System.Drawing.Point(410, 196);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(136, 13);
            this.label24.TabIndex = 10;
            this.label24.Text = "Total Test Entry Count:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label20.Location = new System.Drawing.Point(410, 167);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(97, 13);
            this.label20.TabIndex = 10;
            this.label20.Text = "Unmatch Count:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label19.Location = new System.Drawing.Point(410, 139);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(163, 13);
            this.label19.TabIndex = 10;
            this.label19.Text = "Mis-Match Detection Count:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label18.Location = new System.Drawing.Point(410, 104);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(189, 13);
            this.label18.TabIndex = 10;
            this.label18.Text = "Multiple-Match Detection Count:";
            // 
            // lblRecal
            // 
            this.lblRecal.AutoSize = true;
            this.lblRecal.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblRecal.ForeColor = System.Drawing.Color.DarkRed;
            this.lblRecal.Location = new System.Drawing.Point(618, 266);
            this.lblRecal.Name = "lblRecal";
            this.lblRecal.Size = new System.Drawing.Size(28, 13);
            this.lblRecal.TabIndex = 10;
            this.lblRecal.Text = "N/A";
            // 
            // lblPrecision
            // 
            this.lblPrecision.AutoSize = true;
            this.lblPrecision.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblPrecision.ForeColor = System.Drawing.Color.DarkRed;
            this.lblPrecision.Location = new System.Drawing.Point(618, 240);
            this.lblPrecision.Name = "lblPrecision";
            this.lblPrecision.Size = new System.Drawing.Size(28, 13);
            this.lblPrecision.TabIndex = 10;
            this.lblPrecision.Text = "N/A";
            // 
            // lblTotalTestEntryCount
            // 
            this.lblTotalTestEntryCount.AutoSize = true;
            this.lblTotalTestEntryCount.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTotalTestEntryCount.ForeColor = System.Drawing.Color.DarkRed;
            this.lblTotalTestEntryCount.Location = new System.Drawing.Point(618, 196);
            this.lblTotalTestEntryCount.Name = "lblTotalTestEntryCount";
            this.lblTotalTestEntryCount.Size = new System.Drawing.Size(28, 13);
            this.lblTotalTestEntryCount.TabIndex = 10;
            this.lblTotalTestEntryCount.Text = "N/A";
            // 
            // lblUnmatchCount
            // 
            this.lblUnmatchCount.AutoSize = true;
            this.lblUnmatchCount.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblUnmatchCount.ForeColor = System.Drawing.Color.DarkRed;
            this.lblUnmatchCount.Location = new System.Drawing.Point(618, 167);
            this.lblUnmatchCount.Name = "lblUnmatchCount";
            this.lblUnmatchCount.Size = new System.Drawing.Size(28, 13);
            this.lblUnmatchCount.TabIndex = 10;
            this.lblUnmatchCount.Text = "N/A";
            // 
            // lblMisMatchCount
            // 
            this.lblMisMatchCount.AutoSize = true;
            this.lblMisMatchCount.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblMisMatchCount.ForeColor = System.Drawing.Color.DarkRed;
            this.lblMisMatchCount.Location = new System.Drawing.Point(618, 139);
            this.lblMisMatchCount.Name = "lblMisMatchCount";
            this.lblMisMatchCount.Size = new System.Drawing.Size(28, 13);
            this.lblMisMatchCount.TabIndex = 10;
            this.lblMisMatchCount.Text = "N/A";
            this.lblMisMatchCount.Click += new System.EventHandler(this.lblMisMatchCount_Click);
            // 
            // lblMultipleMatchCount
            // 
            this.lblMultipleMatchCount.AutoSize = true;
            this.lblMultipleMatchCount.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblMultipleMatchCount.Location = new System.Drawing.Point(618, 104);
            this.lblMultipleMatchCount.Name = "lblMultipleMatchCount";
            this.lblMultipleMatchCount.Size = new System.Drawing.Size(28, 13);
            this.lblMultipleMatchCount.TabIndex = 10;
            this.lblMultipleMatchCount.Text = "N/A";
            // 
            // lblCorrectDetectionsCount
            // 
            this.lblCorrectDetectionsCount.AutoSize = true;
            this.lblCorrectDetectionsCount.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblCorrectDetectionsCount.Location = new System.Drawing.Point(618, 70);
            this.lblCorrectDetectionsCount.Name = "lblCorrectDetectionsCount";
            this.lblCorrectDetectionsCount.Size = new System.Drawing.Size(28, 13);
            this.lblCorrectDetectionsCount.TabIndex = 10;
            this.lblCorrectDetectionsCount.Text = "N/A";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label16.Location = new System.Drawing.Point(410, 70);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(146, 13);
            this.label16.TabIndex = 10;
            this.label16.Text = "Correct Detection Count:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label15.Location = new System.Drawing.Point(6, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 13);
            this.label15.TabIndex = 10;
            this.label15.Text = "Real Relations";
            // 
            // lsRealRelations
            // 
            this.lsRealRelations.FormattingEnabled = true;
            this.lsRealRelations.Location = new System.Drawing.Point(6, 17);
            this.lsRealRelations.Name = "lsRealRelations";
            this.lsRealRelations.Size = new System.Drawing.Size(366, 264);
            this.lsRealRelations.TabIndex = 9;
            // 
            // btnLoadOtherLearnedRegexes
            // 
            this.btnLoadOtherLearnedRegexes.Enabled = false;
            this.btnLoadOtherLearnedRegexes.Image = ((System.Drawing.Image)(resources.GetObject("btnLoadOtherLearnedRegexes.Image")));
            this.btnLoadOtherLearnedRegexes.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoadOtherLearnedRegexes.Location = new System.Drawing.Point(860, 138);
            this.btnLoadOtherLearnedRegexes.Name = "btnLoadOtherLearnedRegexes";
            this.btnLoadOtherLearnedRegexes.Size = new System.Drawing.Size(254, 47);
            this.btnLoadOtherLearnedRegexes.TabIndex = 2;
            this.btnLoadOtherLearnedRegexes.Text = "Load Other Learned Regexes File";
            this.btnLoadOtherLearnedRegexes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadOtherLearnedRegexes.UseVisualStyleBackColor = true;
            // 
            // btnExtractEqualLengthSamples
            // 
            this.btnExtractEqualLengthSamples.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExtractEqualLengthSamples.Location = new System.Drawing.Point(860, 65);
            this.btnExtractEqualLengthSamples.Name = "btnExtractEqualLengthSamples";
            this.btnExtractEqualLengthSamples.Size = new System.Drawing.Size(159, 30);
            this.btnExtractEqualLengthSamples.TabIndex = 2;
            this.btnExtractEqualLengthSamples.Text = "Extract Equal-Length Samples";
            this.btnExtractEqualLengthSamples.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExtractEqualLengthSamples.UseVisualStyleBackColor = true;
            this.btnExtractEqualLengthSamples.Click += new System.EventHandler(this.btnExtractEqualLengthSamples_Click);
            // 
            // btnLoadTestFile
            // 
            this.btnLoadTestFile.Image = ((System.Drawing.Image)(resources.GetObject("btnLoadTestFile.Image")));
            this.btnLoadTestFile.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoadTestFile.Location = new System.Drawing.Point(860, 7);
            this.btnLoadTestFile.Name = "btnLoadTestFile";
            this.btnLoadTestFile.Size = new System.Drawing.Size(254, 47);
            this.btnLoadTestFile.TabIndex = 2;
            this.btnLoadTestFile.Text = "Load Test File";
            this.btnLoadTestFile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadTestFile.UseVisualStyleBackColor = true;
            this.btnLoadTestFile.Click += new System.EventHandler(this.btnLoadTestFile_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.lbSuggestedTriples);
            this.tabPage3.Controls.Add(this.chkSuggestNonExistingTriples);
            this.tabPage3.Controls.Add(this.chkStemWordsOnSuggestedTriples);
            this.tabPage3.Controls.Add(this.chkStemWordsOnCompare);
            this.tabPage3.Controls.Add(this.btnExtractNewKnowledge);
            this.tabPage3.Controls.Add(this.btnExportSuggestedTriples);
            this.tabPage3.Controls.Add(this.btnLoadKnowledgeBade);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1156, 774);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "KNOWLEDGE EXTRACTION";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.chkUseInMemoryExtractedRelations);
            this.groupBox3.Controls.Add(this.btnLoadMoreRelations);
            this.groupBox3.Controls.Add(this.chkModeMerge);
            this.groupBox3.Location = new System.Drawing.Point(890, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(260, 143);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Relations";
            // 
            // chkUseInMemoryExtractedRelations
            // 
            this.chkUseInMemoryExtractedRelations.AutoSize = true;
            this.chkUseInMemoryExtractedRelations.Checked = true;
            this.chkUseInMemoryExtractedRelations.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkUseInMemoryExtractedRelations.Location = new System.Drawing.Point(35, 20);
            this.chkUseInMemoryExtractedRelations.Name = "chkUseInMemoryExtractedRelations";
            this.chkUseInMemoryExtractedRelations.Size = new System.Drawing.Size(196, 17);
            this.chkUseInMemoryExtractedRelations.TabIndex = 10;
            this.chkUseInMemoryExtractedRelations.Text = "Use In-Memory Extracted Relations";
            this.chkUseInMemoryExtractedRelations.UseVisualStyleBackColor = true;
            // 
            // btnLoadMoreRelations
            // 
            this.btnLoadMoreRelations.Image = ((System.Drawing.Image)(resources.GetObject("btnLoadMoreRelations.Image")));
            this.btnLoadMoreRelations.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoadMoreRelations.Location = new System.Drawing.Point(35, 47);
            this.btnLoadMoreRelations.Name = "btnLoadMoreRelations";
            this.btnLoadMoreRelations.Size = new System.Drawing.Size(196, 47);
            this.btnLoadMoreRelations.TabIndex = 2;
            this.btnLoadMoreRelations.Text = "Load More Relations";
            this.btnLoadMoreRelations.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadMoreRelations.UseVisualStyleBackColor = true;
            this.btnLoadMoreRelations.Click += new System.EventHandler(this.btnLoadMoreRelations_Click);
            // 
            // chkModeMerge
            // 
            this.chkModeMerge.AutoSize = true;
            this.chkModeMerge.Checked = true;
            this.chkModeMerge.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkModeMerge.Location = new System.Drawing.Point(35, 112);
            this.chkModeMerge.Name = "chkModeMerge";
            this.chkModeMerge.Size = new System.Drawing.Size(160, 17);
            this.chkModeMerge.TabIndex = 10;
            this.chkModeMerge.Text = "Merge Relations to Previous";
            this.chkModeMerge.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label17.Location = new System.Drawing.Point(8, 157);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 13);
            this.label17.TabIndex = 14;
            this.label17.Text = "Suggested Triples:";
            // 
            // lbSuggestedTriples
            // 
            this.lbSuggestedTriples.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbSuggestedTriples.Font = new System.Drawing.Font("Gandom", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbSuggestedTriples.FormattingEnabled = true;
            this.lbSuggestedTriples.HorizontalScrollbar = true;
            this.lbSuggestedTriples.ItemHeight = 24;
            this.lbSuggestedTriples.Location = new System.Drawing.Point(3, 191);
            this.lbSuggestedTriples.Name = "lbSuggestedTriples";
            this.lbSuggestedTriples.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbSuggestedTriples.Size = new System.Drawing.Size(1150, 580);
            this.lbSuggestedTriples.TabIndex = 13;
            // 
            // chkSuggestNonExistingTriples
            // 
            this.chkSuggestNonExistingTriples.AutoSize = true;
            this.chkSuggestNonExistingTriples.Checked = true;
            this.chkSuggestNonExistingTriples.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSuggestNonExistingTriples.Location = new System.Drawing.Point(358, 29);
            this.chkSuggestNonExistingTriples.Name = "chkSuggestNonExistingTriples";
            this.chkSuggestNonExistingTriples.Size = new System.Drawing.Size(294, 17);
            this.chkSuggestNonExistingTriples.TabIndex = 10;
            this.chkSuggestNonExistingTriples.Text = "Suggest Non-Existing Entities in Source Knowledge Base";
            this.chkSuggestNonExistingTriples.UseVisualStyleBackColor = true;
            // 
            // chkStemWordsOnSuggestedTriples
            // 
            this.chkStemWordsOnSuggestedTriples.AutoSize = true;
            this.chkStemWordsOnSuggestedTriples.Checked = true;
            this.chkStemWordsOnSuggestedTriples.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStemWordsOnSuggestedTriples.Location = new System.Drawing.Point(168, 29);
            this.chkStemWordsOnSuggestedTriples.Name = "chkStemWordsOnSuggestedTriples";
            this.chkStemWordsOnSuggestedTriples.Size = new System.Drawing.Size(187, 17);
            this.chkStemWordsOnSuggestedTriples.TabIndex = 10;
            this.chkStemWordsOnSuggestedTriples.Text = "Stem Words on Suggested Triples";
            this.chkStemWordsOnSuggestedTriples.UseVisualStyleBackColor = true;
            // 
            // chkStemWordsOnCompare
            // 
            this.chkStemWordsOnCompare.AutoSize = true;
            this.chkStemWordsOnCompare.Checked = true;
            this.chkStemWordsOnCompare.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStemWordsOnCompare.Location = new System.Drawing.Point(22, 29);
            this.chkStemWordsOnCompare.Name = "chkStemWordsOnCompare";
            this.chkStemWordsOnCompare.Size = new System.Drawing.Size(145, 17);
            this.chkStemWordsOnCompare.TabIndex = 10;
            this.chkStemWordsOnCompare.Text = "Stem Words on Compare";
            this.chkStemWordsOnCompare.UseVisualStyleBackColor = true;
            // 
            // btnExtractNewKnowledge
            // 
            this.btnExtractNewKnowledge.Enabled = false;
            this.btnExtractNewKnowledge.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnExtractNewKnowledge.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExtractNewKnowledge.Location = new System.Drawing.Point(308, 68);
            this.btnExtractNewKnowledge.Name = "btnExtractNewKnowledge";
            this.btnExtractNewKnowledge.Size = new System.Drawing.Size(257, 47);
            this.btnExtractNewKnowledge.TabIndex = 3;
            this.btnExtractNewKnowledge.Text = "Extract New Knowledge";
            this.btnExtractNewKnowledge.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExtractNewKnowledge.UseVisualStyleBackColor = true;
            this.btnExtractNewKnowledge.Click += new System.EventHandler(this.btnExtractNewKnowledge_Click);
            // 
            // btnExportSuggestedTriples
            // 
            this.btnExportSuggestedTriples.Enabled = false;
            this.btnExportSuggestedTriples.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExportSuggestedTriples.Location = new System.Drawing.Point(596, 68);
            this.btnExportSuggestedTriples.Name = "btnExportSuggestedTriples";
            this.btnExportSuggestedTriples.Size = new System.Drawing.Size(257, 47);
            this.btnExportSuggestedTriples.TabIndex = 2;
            this.btnExportSuggestedTriples.Text = "Export Suggested Triples";
            this.btnExportSuggestedTriples.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportSuggestedTriples.UseVisualStyleBackColor = true;
            this.btnExportSuggestedTriples.Click += new System.EventHandler(this.btnExportSuggestedTriples_Click);
            // 
            // btnLoadKnowledgeBade
            // 
            this.btnLoadKnowledgeBade.Image = ((System.Drawing.Image)(resources.GetObject("btnLoadKnowledgeBade.Image")));
            this.btnLoadKnowledgeBade.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoadKnowledgeBade.Location = new System.Drawing.Point(22, 68);
            this.btnLoadKnowledgeBade.Name = "btnLoadKnowledgeBade";
            this.btnLoadKnowledgeBade.Size = new System.Drawing.Size(257, 47);
            this.btnLoadKnowledgeBade.TabIndex = 2;
            this.btnLoadKnowledgeBade.Text = "Load Knowledge Base (For Compare Source)";
            this.btnLoadKnowledgeBade.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadKnowledgeBade.UseVisualStyleBackColor = true;
            this.btnLoadKnowledgeBade.Click += new System.EventHandler(this.btnLoadKnowledgeBade_Click);
            // 
            // btnGetSubtracts
            // 
            this.btnGetSubtracts.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGetSubtracts.Location = new System.Drawing.Point(1025, 65);
            this.btnGetSubtracts.Name = "btnGetSubtracts";
            this.btnGetSubtracts.Size = new System.Drawing.Size(89, 30);
            this.btnGetSubtracts.TabIndex = 2;
            this.btnGetSubtracts.Text = "Get Subtracts";
            this.btnGetSubtracts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetSubtracts.UseVisualStyleBackColor = true;
            this.btnGetSubtracts.Click += new System.EventHandler(this.btnGetSubtracts_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 813);
            this.Controls.Add(this.tcMain);
            this.Controls.Add(this.lblMessage);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Automatic Regex Learner for Relation Extraction- IUST Data Mining Lab";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudMinSubstringOccourance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxWordOccourance)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxSynonyms)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSentenceWordCountQualifiedScore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSentenceLengthQualifiedScore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxSentenceWordCountDiff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxSentenceLengthDiff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNonSameWordsQualified)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxNonSameWords)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCommonWordsQualifiedScore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinCommonWords)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinSimilarityPercent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tcMain.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPageRegexes.ResumeLayout(false);
            this.tabHighFrequencyRegexes.ResumeLayout(false);
            this.tabLowFreqRegexes.ResumeLayout(false);
            this.tabTest.ResumeLayout(false);
            this.tabTest.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstAnnotators;
        private System.Windows.Forms.Button btnAnalyze;
        private System.Windows.Forms.NumericUpDown nudMinSubstringOccourance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnOpenTrainFile;
        private System.Windows.Forms.OpenFileDialog ofdOpenTrainFile;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.TextBox txtPrepositions;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudMaxWordOccourance;
        private System.Windows.Forms.CheckBox chkIgnorePrepositions;
        private System.Windows.Forms.CheckBox chkStemWords;
        private System.Windows.Forms.ListBox lstStats;
        private System.Windows.Forms.Button btnDefinePivotWords;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkRightToLeftLayout;
        private System.Windows.Forms.ComboBox cmbLanguage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lsRegexes;
        private System.Windows.Forms.CheckBox chkExactMatchOfEntities;
        private System.Windows.Forms.CheckBox chkUseSynonyms;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown nudMinSimilarityPercent;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nudSentenceLengthQualifiedScore;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nudMaxSentenceLengthDiff;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nudMaxSentenceWordCountDiff;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nudSentenceWordCountQualifiedScore;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown nudMaxNonSameWords;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown nudCommonWordsQualifiedScore;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown nudMinCommonWords;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nudNonSameWordsQualified;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnSaveRegexes;
        private System.Windows.Forms.Button btnAddToLearnedRegexes;
        private System.Windows.Forms.CheckBox chkNoSynonymsWhenStemming;
        private System.Windows.Forms.NumericUpDown nudMaxSynonyms;
        private System.Windows.Forms.CheckBox chkMaxSynonyms;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnResetParametersToDefaults;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ListBox lsSimilarSentencesRegex;
        private System.Windows.Forms.Label lblRelations;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabControl tcMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabTest;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ListBox lsRealRelations;
        private System.Windows.Forms.Button btnLoadOtherLearnedRegexes;
        private System.Windows.Forms.Button btnLoadTestFile;
        private System.Windows.Forms.ListBox lsOutput;
        private System.Windows.Forms.Button btnApplyRegexes;
        private System.Windows.Forms.Button btnRegexDetails;
        private System.Windows.Forms.CheckBox chkSimpleRegexView;
        private System.Windows.Forms.CheckBox chkUseCurrentLearnedRegexes;
        private System.Windows.Forms.TabControl tabPageRegexes;
        private System.Windows.Forms.TabPage tabHighFrequencyRegexes;
        private System.Windows.Forms.TabPage tabLowFreqRegexes;
        private System.Windows.Forms.Button btnLogger;
        private System.Windows.Forms.CheckBox chkTreatMultipleMatchAsCorrect;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblUnmatchCount;
        private System.Windows.Forms.Label lblMisMatchCount;
        private System.Windows.Forms.Label lblMultipleMatchCount;
        private System.Windows.Forms.Label lblCorrectDetectionsCount;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblRecal;
        private System.Windows.Forms.Label lblPrecision;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblTotalTestEntryCount;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.ListBox lbCorrectDetected;
        private System.Windows.Forms.ListBox lbMultipleMatches;
        private System.Windows.Forms.ListBox lbMisMatches;
        private System.Windows.Forms.ListBox lbNoMatches;
        private System.Windows.Forms.CheckBox chkConsiderE2E1SameAsE1E2;
        private System.Windows.Forms.CheckBox chkLowFreqRegexGenerate;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnLoadKnowledgeBade;
        private System.Windows.Forms.Button btnExtractNewKnowledge;
        private System.Windows.Forms.CheckBox chkStemWordsOnCompare;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ListBox lbSuggestedTriples;
        private System.Windows.Forms.CheckBox chkStemWordsOnSuggestedTriples;
        private System.Windows.Forms.CheckBox chkSuggestNonExistingTriples;
        private System.Windows.Forms.Button btnExportSuggestedTriples;
        private System.Windows.Forms.CheckBox chkUseInMemoryExtractedRelations;
        private System.Windows.Forms.Button btnLoadMoreRelations;
        private System.Windows.Forms.CheckBox chkModeMerge;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnExtractEqualLengthSamples;
        private System.Windows.Forms.Button btnGetSubtracts;
    }
}

